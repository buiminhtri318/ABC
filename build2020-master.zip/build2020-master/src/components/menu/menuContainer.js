Vue.component('menu-container', {
  props: ['isHidden', 'onToggleEventName'],
  template: `
    <div class="menu-container">
      <slot></slot>
    </div>
  `
});
