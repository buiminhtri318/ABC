Vue.component('home-page', {
  template: `
    <div class="page-container home-page">
      <div class="home-page-content-container">
        <div class="home-page-head-line">
          Discover what’s possible on your property
        </div>
        <search-bar
          theme="page"
          v-bind:fontColors="['#5F74FE', 'white']"
          v-bind:backgroundColors="['#EFF1FF', '#5F74FE']"
          v-bind:icons="['resources/icons/search_active.png', 'resources/icons/search_dark.png']"
        ></search-bar>
      </div>
    </div>
  `,
});
