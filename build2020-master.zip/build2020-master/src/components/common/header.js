Vue.component('header-bar', {
  props: ['onIndex', 'pageComponent'],
  data: function () {
    return {
      headerLinks: [
        {
          title: 'Overview',
          componentList: ['property-info', 'property-accessory-dwelling'],
          onclick: () => { this.$emit('route', 'info'); },
        },
        {
          title: 'Design',
          componentList: ['property-marketplace'],
          onclick: () => { this.$emit('route', 'marketplace'); },
        },
        {
          title: 'Saved',
          componentList: ['property-saved-project'],
          onclick: () => { this.$emit('route', 'saved-project'); },
        },
      ],
      menuItems: [
        { text: 'Saved Properties', link: 'property_overview.html?page=saved-project', hasLine: true },
        { text: 'Knowledge Base', link: 'knowledge_base.html' },
        { text: 'Account', link: '#' },
        { text: 'Logout', link: '#' },
      ],
      showMenu: false,
    }
  },
  template: `
    <div class="header-container">
      <div class="right-header">
        <a href="index.html">
          <img src="resources/icons/logo.png" />
        </a>
      </div>
      <search-bar
        v-bind:fontColors="['#5F74FE', '#5F74FE']"
        v-bind:backgroundColors="['#EFF1FF', 'white']"
        v-bind:icons="['resources/icons/search_active.png', 'resources/icons/search_inactive.png']"
        v-if="!onIndex"
      ></search-bar>
      <div class="header-links" v-if="!onIndex">
        <div v-bind:class="['header-link']" v-for="headerLink in headerLinks">
          <div
            v-bind:class="[isActiveLink(headerLink) ? 'active' : '']"
            v-on:click="headerLink.onclick"
          >{{headerLink.title}}</div>
        </div>
      </div>
      <div class="left-header menu">
        <menu-container v-if="showMenu">
          <div v-for="item in menuItems">
            <div class="item">
              <a v-bind:href="item.link">
                {{item.text}}
              </a>
            </div>
            <seperate-line v-if="item.hasLine"></seperate-line>
          </div>
        </menu-container>
        <circle-shape
          title="P"
          v-bind:backgroundColor="menuCircleBackgroundColor"
          v-bind:color="menuCircleColor"
          v-bind:onclick="toggleMenu"
        ></cirlce-shape>
      </div>
    </div>
  `,
  methods: {
    toggleMenu: function () {
      this.showMenu = !this.showMenu;
    },
    isActiveLink: function(headerLink) {
      return headerLink.componentList.indexOf(this.pageComponent) > -1;
    },
  },
  computed: {
    menuCircleColor() {
      return this.showMenu ? '#5F74FE' : 'white'
    },
    menuCircleBackgroundColor() {
      return this.showMenu ? '#EFF1FF' : '#5F74FE'
    },

  },
});
