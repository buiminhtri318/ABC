Vue.component('header-bar', {
  template: `
    <div class="header-container">
      <div class="right-header">Symbium Build</div>
      <circle-shape
        title="P"
        background-color="#5F74FE"
      ></cirlce-shape>
    </div>
  `
});
