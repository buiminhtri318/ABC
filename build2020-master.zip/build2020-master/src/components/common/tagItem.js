Vue.component('tag-item', {
  props: {
    'title': String,
    'isActive': Boolean,
    'isNotAllowed': Boolean,
    'iconPath': String,
    'onclick': {
      type: Function,
      default: function () {},
    },
  },
  template: `
    <div v-on:click="onclick" v-bind:class="['tag', isActive ? 'active' : 'inactive', isNotAllowed ? 'not-allowed' : '']">
      <img v-if="isNotAllowed" src="resources/icons/not_allowed_white.png" />
      <img v-if="iconPath" v-bind:src="iconPath" />
      {{title}}
    </div>
  `,
});

Vue.component('tag-list', {
  props: ['tagList'],
  template: `
    <div class="tag-list">
      <tag-item v-for="tag in tagList" v-bind="tag"></tag-item>
    </div>
  `
});
