Vue.component('seperate-line', {
  template: `
    <div class="seperate-line"></div>
  `
});
