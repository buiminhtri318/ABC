Vue.component('progress-bar', {
  props: {
    value: String,
    klass: String,
    isDragable: Boolean,
    dragableBackgroundColor: {
      type: String,
      default: '#DBE0FF',
    },
    dragableSize: {
      type: Number,
      default: 16,
    },
    height: {
      type: Number,
      default: 8,
    }
  },
  template: `
    <div v-bind:class="['progress-bar', klass]">
      <div class="left" :style="left"></div>
      <div class="right" :style="right"></div>
      <div class="dragable" :style="dragable">
        <circle-shape v-bind:backgroundColor="dragableBackgroundColor" v-bind:size="dragableSize" v-if="isDragable"></circle-shape>
      </div>
    <div>
  `,
  computed: {
    left() {
      return {
        'flex-basis': (this.value * 100) + '%',
        height: this.height + 'px',
      }
    },
    right() {
      return {
        'flex-basis': ((1 - this.value) * 100) + '%',
        height: this.height + 'px',
      }
    },
    dragable() {
      return {
        top: '-' + ((this.dragableSize - this.height) / 2) + 'px',
        left: 'calc(' + (this.value * 100) + '% - ' + (this.height / 2) + 'px)',
      }
    },
  },
})
