var EVENT_BUS = new Vue();
