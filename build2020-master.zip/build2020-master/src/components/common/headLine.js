Vue.component('head-line', {
  props: ['title'],
  template: `
    <div class="head-line">
      {{title}}
    </div>
  `
});
