Vue.component('head-line', {
  props: ['title', 'klass'],
  template: `
    <div v-bind:class="['head-line', klass]">
      {{title}}
    </div>
  `
});
