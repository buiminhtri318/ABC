Vue.component('search-bar', {
  props: ['theme', 'backgroundColors', 'fontColors', 'icons'],
  data: function () {
    return {
      searchTerm: '',
      noSearchingInpgrogress: true,
      suggestList: [],
      hover: false,
      typing: false,
      placeholder: 'Search by Address',
    }
  },
  template: `
    <div class="search-bar">
      <div class="search-holder" :style="searchHolder" @mouseover="hover = true" @mouseleave="hover = false">
        <a :href="propertyLink">
          <img class="icon" v-bind:src="searchIcon">
        </a>
        <input
          :style="searchInput"
          v-model="searchTerm"
          @keyup="searchBarKeyUp"
          @focus="typing = true; placeholder = ''"
          @blur="typing = false; placeholder = 'Search by Address'"
          :placeholder="placeholder"
        />
      </div>
      <div class="suggest-container">
        <a href="property_overview.html?onMap=true" v-if="isPageTheme">
          <div
            v-show="noSearchingInpgrogress && suggestList.length == 0"
            class='search-on-map'
          >
            Search on Map
          </div>
        </a>
        <div
          v-for="word in suggestList"
          v-on:click="setSearchTerm"
          class="suggest-item"
          :style="searchHolder"
        >
          <div class="suggest-item-content">{{word}}</div>
        </div>
      </div>
    </div>
  `,
  computed: {
    isHeaderTheme () {
      return this.theme == 'header';
    },
    isPageTheme () {
      return this.theme == 'page';
    },
    searchIcon () {
      return this.isActive() ? this.icons[0] : this.icons[1];
    },
    searchHolder () {
      return {
        background: this.backgroundColor(),
        color: this.fontColor(),
      }
    },
    searchInput () {
      return {
        '--placeholder-color': this.fontColor(),
        color: this.fontColor(),
      }
    },
    propertyLink () {
      return 'property_overview.html?searchTerm=' + this.searchTerm;
    }
  },
  methods: {
    // Methods to control search logic
    searchBarKeyUp: _.debounce(function () {
      this.searchAddress();
    }, 500),
    searchAddress: function () {
      if (!this.searchTermIsNotEmpty()) {
        this.suggestList = [];
      }
      if (this.noSearchingInpgrogress && this.searchTermIsNotEmpty()) {
        this.noSearchingInpgrogress = false;
        axios({
          method: 'GET',
          url: "https://my-json-server.typicode.com/buiminhtri318/stub_address/db",
          params: { term: this.searchTerm },
        }).then(this.parseResponse);
      }
    },
    parseResponse: function (response) {
      this.noSearchingInpgrogress = true;
      var data = response.data;
      if (_.isObject(data) && _.isArray(data.addr)) {
        this.suggestList = response.data.addr;
      }
    },
    setSearchTerm: function (event) {
      this.searchTerm = event.target.innerText;
      this.suggestList = [];
    },
    searchTermIsNotEmpty: function () {
      return this.searchTerm.length > 0
    },
    isActive: function () {
      return this.hover || this.typing || this.searchTermIsNotEmpty()
    },
    fontColor: function () {
      return this.isActive() ? this.fontColors[0] : this.fontColors[1];
    },
    backgroundColor: function () {
      return this.isActive() ? this.backgroundColors[0] : this.backgroundColors[1];
    }
  }
});
