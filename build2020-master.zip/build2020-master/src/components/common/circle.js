Vue.component('circle-shape', {
  props: ['title', 'backgroundColor'],
  template: '<div :style="circleStyle">{{title}}</div>',
  computed: {
    circleStyle() {
      return {
        'background-color': this.backgroundColor,
        'border': 'white',
        'border-radius': '50%',
        'color': 'white',
        'font-size': '16px',
        'width': '30px',
        'height': '30px',
        'text-align': 'center',
        'line-height': '30px',
        'font-style': 'normal',
        'font-weight': 'bold',
      }
    }
  }
});
