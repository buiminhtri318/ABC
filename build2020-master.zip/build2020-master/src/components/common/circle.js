Vue.component('circle-shape', {
  props: {
    title: String,
    backgroundColor: String,
    color: String,
    onclick: {
      type: Function,
      default: () => {},
    },
    size: {
      type: String,
      default: '32',
    }
  },
  template: '<div :style="circleStyle" v-on:click="onclick" class="circle">{{title}}</div>',
  computed: {
    circleStyle() {
      return {
        'background-color': this.backgroundColor,
        color: this.color,
        width: this.size + 'px',
        height: this.size + 'px',
      }
    }
  }
});
