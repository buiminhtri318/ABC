Vue.component('help-article', {
  props: {
    title: {
      type: String,
      default: 'What’s an ADU?',
    },
    hasNoConent: {
      type: Boolean,
      default: false,
    }
  },
  data: function () {
    return {
      show: false,
    }
  },
  template: `
    <div class="help-article">
      <seperate-line></seperate-line>
      <div class="article-container" v-on:click="show = !show">
        <div class="title">{{title}}</div>
        <div class="icon">
          <img v-bind:src="imagePath"  align="center" />
        </div>
      </div>
      <div class="article-content" v-if="show">
        <p>Sample Here</p>
        <p>Need Modify Later</p>
        <p v-if="!hasNoConent">One way to finance an ADU is by borrowing against the value of your property.</p>

        <ul v-if="!hasNoConent">
          <li>
            <p>Home Equity Line of Credit (HELOC)</p>
            <p>A common way is to borrow from a home equity line of credit (HELOC). A HELOC functions similarly to a credit card, using your home as collateral. A HELOC allows a property owner to borrow what they need, up to the full amount approved. Interest is only paid on the amount that is withdrawn. Typically, a HELOC has a variable interest rate and can provide financing up to 80%-90% of the property’s value. The length of the HELOC term can vary, but they can often run for as long as 30 years. A HELOC may be a good option if you have at least 15%-20% equity in your existing house (determined by subtracting your current mortgage balance from your home value).</p>
          </li>
          <li>
            <p>Home Equity Line of Credit (HELOC)</p>
            <p>A common way is to borrow from a home equity line of credit (HELOC). A HELOC functions similarly to a credit card, using your home as collateral. A HELOC allows a property owner to borrow what they need, up to the full amount approved. Interest is only paid on the amount that is withdrawn. Typically, a HELOC has a variable interest rate and can provide financing up to 80%-90% of the property’s value. The length of the HELOC term can vary, but they can often run for as long as 30 years. A HELOC may be a good option if you have at least 15%-20% equity in your existing house (determined by subtracting your current mortgage balance from your home value).</p>
          </li>
          <li>
            <p>Home Equity Line of Credit (HELOC)</p>
            <p>A common way is to borrow from a home equity line of credit (HELOC). A HELOC functions similarly to a credit card, using your home as collateral. A HELOC allows a property owner to borrow what they need, up to the full amount approved. Interest is only paid on the amount that is withdrawn. Typically, a HELOC has a variable interest rate and can provide financing up to 80%-90% of the property’s value. The length of the HELOC term can vary, but they can often run for as long as 30 years. A HELOC may be a good option if you have at least 15%-20% equity in your existing house (determined by subtracting your current mortgage balance from your home value).</p>
          </li>
        </ul>

        <article-footer></article-footer>
      </div>
    </div>
  `,
  computed: {
    imagePath () {
      return 'resources/icons/' + (this.show ? 'up.png' : 'down.png');
    }
  }
});
