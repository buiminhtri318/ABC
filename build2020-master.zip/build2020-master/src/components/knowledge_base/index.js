Vue.component('knowledge-base', {
  template: `
    <div class="knowledge-base page-container">
      <div class="navigator">
        Knowledge Base
      </div>
      <seperate-line></seperate-line>
      <div class="knowledge-base-content">
        <div class="knowledge-base-content-right">
          Accessory Dwelling Units (ADUs)
        </div>
        <div class="knowledge-base-content-left">
          <help-article></help-article>
          <help-article></help-article>
          <help-article></help-article>
          <help-article></help-article>
          <help-article></help-article>
          <help-article></help-article>
          <help-article></help-article>
          <help-article></help-article>
          <seperate-line></seperate-line>
        </div>
      </div>
      <seperate-line></seperate-line>
      <div class="knowledge-base-content footer">
        <div class="knowledge-base-content-right">
        </div>
        <div class="knowledge-base-content-left">
          This information doesn't constitute an entitlement or legal advice. San Francisco has the final say with regards to the administration and enforcement of its Planning Code.
        </div>
      </div>
    </div>
  `
});
