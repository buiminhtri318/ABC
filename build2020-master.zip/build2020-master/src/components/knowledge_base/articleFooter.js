Vue.component('article-footer', {
  data: function () {
    return {
      tags: [
        { title: 'Yes' },
        { title: 'No' },
      ]
    }
  },
  template: `
    <div class="article-footer">
      <div class="share-images">
        <img src="resources/icons/twitter.png" />
        <img src="resources/icons/linkedin.png" />
        <img src="resources/icons/facebook.png" />
        <img src="resources/icons/share_active.png" />
      </div>
      <div class="helpful">
        Was this answer helpful?
        <tag-list v-bind:tagList="tags"></tag-list>
      </div>
    <div>
  `
});
