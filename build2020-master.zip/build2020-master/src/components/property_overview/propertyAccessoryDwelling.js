Vue.component('property-accessory-dwelling', {
  data: function () {
    return {
      options: [
        {
          title: 'Single-family residence',
          description: 'These are typically freestanding buildings. They are used by a family or group of people who share living spaces like kitchens and bathrooms.',
          onclick: this.updateSingleFamily,
          isActive: false,
          eligibile: true,
        },
        {
          title: 'Multi-family residence',
          description: 'These are typically larger buildings with several condos or apartments inside.',
          onclick: this.updateMutipleFamily,
          isActive: false,
          eligibile: true,
        },
        {
          title: 'No residence',
          onclick: this.updateNoResidence,
          isActive: false,
          eligibile: false,
        },
      ],
      isNotAllowedOption: {
        title: 'Unfortunately, accessory dwelling units are not allowed on properties without a single-family or multi-family residence.',
        onclick: function() {},
        isNotAllowed: true,
        klass: "not-allowed",
      },
      allowedInfoList: [
        { title: "Eligibility", data: { icon: 'resources/icons/allowed.png', text: 'Allowed', isRawText: true } },
        { title: "Number Allowed", text: "1" },
        { title: 'Do More', data: { icon: 'resources/icons/report.png', text: 'View Design Standards' } },
      ],
    };
  },
  template: `
    <div>
      <row-with-icon
        icon-path="resources/icons/left.png"
        text="Accessory Dwelling Unit Eligibility"
        v-bind:onclick="backToPropertyInfo"
        klass="navigator"
      ></row-with-icon>
      <seperate-line></seperate-line>

      <div class="section">
        <head-line title="Accessory Dwelling Units are complete and permanent homes located on the same piece of property as another home.  They’re also known as ADUs, second units, in-law units, granny flats, casitas, or backyard homes."></head-line>
      </div>
      <seperate-line></seperate-line>

      <div class="section">
        <head-line title="Let’s see if your property is eligibile for an accessory dwelling unit.  Is there an existing residence?"></head-line>
        <property-option v-for="option in options" v-bind="option"></property-option>
        <property-option v-if="options[2].isActive" v-bind="isNotAllowedOption"></property-option>
      </div>
      <seperate-line></seperate-line>

      <div class="section green" v-if="options[0].isActive || options[1].isActive">
        <head-line title="An Accessory Dwelling Unit should be allowed here!"></head-line>
        <div v-for="info in allowedInfoList">
          <property-row v-bind:info="info"></property-row>
          <seperate-line></seperate-line>
        </div>
      </div>

      <div class="section red" v-if="options[2].isActive">
        <head-line title="An Accessory Dwelling Unit is not allowed here."></head-line>
      </div>
      <seperate-line v-if="options[2].isActive"></seperate-line>
    </div>
  `,
  methods: {
    backToPropertyInfo: function () {
      this.$emit('route', 'info');
    },
    updateSingleFamily: function () {
      this.activeOptionWithIndex(0);
    },
    updateMutipleFamily: function () {
      this.activeOptionWithIndex(1);
    },
    updateNoResidence: function () {
      this.activeOptionWithIndex(2);
    },
    activeOptionWithIndex: function (index) {
      for (var i = 0; i < this.options.length; i++) {
        if (i == index) {
          this.$set(this.options[i], 'isActive', !this.options[i].isActive);
        } else {
          this.$set(this.options[i], 'isActive', false);
        }
      }
      this.$emit(
        'optionToggle',
        { eligibile: this.options[index].eligibile, optionPicked: this.options[index].isActive }
      );
    }
  }
})
