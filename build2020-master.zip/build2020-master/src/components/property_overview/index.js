Vue.component('property-page', {
  data: function () {
    return {
      currentPage: 'info',
      optionPicked: false,
      eligibile: false,
    };
  },
  template: `
    <div>
      <header-bar
        v-bind:pageComponent="currentPageComponent"
        v-on:route="updateCurrentPage"
      ></header-bar>
      <div class="page-container">
        <div v-bind:class="['info-container', currentPage]">
          <component
            v-bind:is="currentPageComponent"
            v-on:route="updateCurrentPage"
            v-on:optionToggle="optionToggle"
            v-bind:eligibile="eligibile"
            v-bind:optionPicked="optionPicked"
          ></component>
        </div>
        <div class="map-container" v-if="showMap">
          <property-map></property-map>
        <div>
      </div>
    </div>
  `,
  computed: {
    currentPageComponent () {
      return 'property-' + this.currentPage;
    },
    showMap () {
      return this.currentPage != 'report';
    },
  },
  methods: {
    updateCurrentPage: function (currentPage) {
      this.currentPage = currentPage;
      window.scrollTo(0,0);
    },
    optionToggle: function (data) {
      this.optionPicked = data.optionPicked;
      this.eligibile = data.eligibile;
    },
  },
  mounted: function() {
    EVENT_BUS.$on('route-property', (route) => this.updateCurrentPage(route));
  },
});
