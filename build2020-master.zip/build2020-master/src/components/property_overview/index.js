Vue.component('property-page', {
  data: function () {
    return {
      currentPage: 'saved-project',
      optionPicked: false,
      eligibile: false,
    };
  },
  template: `
    <div class="page-container">
      <div v-bind:class="['info-container', currentPage]">
        <component
          v-bind:is="currentPageComponent"
          v-on:route="updateCurrentPage"
          v-on:optionToggle="optionToggle"
          v-bind:eligibile="eligibile"
          v-bind:optionPicked="optionPicked"
        ></component>
      </div>
      <div class="map-container">
        <property-map></property-map>
      <div>
    </div>
  `,
  computed: {
    currentPageComponent () {
      return 'property-' + this.currentPage;
    }
  },
  methods: {
    updateCurrentPage: function (currentPage) {
      this.currentPage = currentPage;
    },
    optionToggle: function (data) {
      this.optionPicked = data.optionPicked;
      this.eligibile = data.eligibile;
    },
  }
});
