Vue.component('property-row', {
  props: ['info'],
  template: `
    <div v-bind:class="['row-container', info.klass]">
      <div class="row-title">
        {{info.title}}
        <img src="resources/icons/info_inactive.png" v-show="info.inactive" align="center">
      </div>
      <div class="row-data" v-if="info.text">
        {{info.text}}
      </div>
      <div class="row-data" v-if="info.data">
        <row-with-icon
          v-bind:icon-path="info.data.icon"
          v-bind:text="info.data.text"
          v-bind:isRawText="info.data.isRawText"
        ></row-with-icon>
      </div>
    </div>
  `,
});
