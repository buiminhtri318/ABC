Vue.component('property-info', {
  props: ['eligibile', 'optionPicked'],
  data: function () {
    return {
      infoList: [
        { title: "Address", text: "1039 Broderick St,  San Francisco, CA" },
        { title: "Block/Lot", text: "1130005", inactive: true },
        { title: "Lot Area", text: "2,769 sqft" },
        { title: "Building Area", text: "4,556 sqft" },
        { title: "Number of Units", text: "1" },
        { title: "Stories", text: "3" },
        { title: '', data: { icon: 'resources/icons/edit.png', text: 'Edit Information or Map' } },
      ],
      tagList: [
        { title: 'General', isActive: true, onclick: this.toggleGeneralTag },
        { title: 'Zoning'},
      ],
      extraInfoTagList: [
        { title: 'Accessory Dwelling Unit', onclick: this.showAccessoryDwelling, isNotAllowed: false, isActive: false },
        { title: 'Open a Business' },
        { title: 'More' },
      ],
      notEligibileInfo: {
        title: 'Eligibility',
        data: {
          icon: 'resources/icons/not_allowed.png',
          text: 'Unfortunately, accessory dwelling units are not allowed on properties without a single-family or multi-family residence.',
          isRawText: true,
        },
        klass: 'not-eligibile'
      },
      eligibileInfoList: [
        { title: "Eligibility", data: { icon: 'resources/icons/allowed.png', text: 'Allowed', isRawText: true } },
        { title: "Number Allowed", text: "1" },
      ],
      doMoreInfoList: [
        {
          title: 'Do More',
          data: { icon: 'resources/icons/report.png', text: 'View Design Standards' }
        },
        {
          title: '',
          data: { icon: 'resources/icons/right.png', text: 'Design' },
          onclick: this.showMarketplace
        },
        {
          title: '',
          data: { icon: 'resources/icons/right.png', text: 'See Saved Projects' },
          onclick: this.showSavedProjects
        },
      ],
      recheckEligibilityInfo: {
        title: '',
        onclick: this.showAccessoryDwelling,
        data: {
          icon: 'resources/icons/revert.png',
          text: 'Recheck eligibility',
        },
      },
    };
  },
  template: `
    <div>
      <head-line title="Property Overview"></head-line>
      <seperate-line></seperate-line>

      <tag-list v-bind:tagList="tagList"></tag-list>
      <seperate-line></seperate-line>

      <div v-for="info in infoList" v-if="tagList[0].isActive">
        <property-row v-bind:info="info"></property-row>
        <seperate-line></seperate-line>
      </div>

      <div class="extra-info">
        <head-line title="What’s possible on my property?"></head-line>
        <seperate-line></seperate-line>

        <tag-list v-bind:tagList="extraInfoTagList"></tag-list>
        <seperate-line></seperate-line>
      </div>

      <div v-if="optionPicked" class="show-option">
        <div class="description">
          Accessory Dwelling Units are complete and permanent homes located on the same piece of property as another home.  They’re also known as ADUs, second units, in-law units, granny flats, casitas, or backyard homes.
          <img src="resources/icons/info_inactive.png" align="center">
        </div>
        <seperate-line></seperate-line>

        <property-row v-bind:info="notEligibileInfo" v-if="!eligibile"></property-row>
        <seperate-line></seperate-line>

        <div v-for="info in eligibileInfoList" v-if="eligibile">
          <property-row v-bind:info="info"></property-row>
          <seperate-line></seperate-line>
        </div>
        <property-row v-for="info in doMoreInfoList" v-bind:info="info" v-if="eligibile" v-on:click.native="info.onclick"></property-row>
        <property-row v-bind:info="recheckEligibilityInfo" v-on:click.native="showAccessoryDwelling"></property-row>
        <seperate-line></seperate-line>
      </div>
    </div>
  `,
  methods: {
    showAccessoryDwelling: function () {
      this.$emit('route', 'accessory-dwelling');
    },
    showMarketplace: function () {
      this.$emit('route', 'marketplace');
    },
    showSavedProjects: function () {
      this.$emit('route', 'saved-project');
    },
    toggleGeneralTag: function () {
      this.$set(this.tagList[0], 'isActive', !this.tagList[0].isActive);
    },
  },
  mounted: function () {
    this.$set(this.tagList[0], 'isActive', !this.optionPicked);
    this.$set(this.extraInfoTagList[0], 'isNotAllowed', this.optionPicked);
    this.$set(this.extraInfoTagList[0], 'isActive', this.optionPicked);
  },
});
