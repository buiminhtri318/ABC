Vue.component('property-project-detail', {
  data: function () {
    return {
      headLineTagList: [
        {
          title: 'Share',
          iconPath: 'resources/icons/share.png',
        },
        {
          title: 'Saved',
          iconPath: 'resources/icons/heart_white.png',
          isActive: true,
        },
      ],
      detailTagList: [
        {
          title: 'Modify ADU Design',
          iconPath: 'resources/icons/modify.png',
        },
        {
          title: 'Demolish Structure',
          iconPath: 'resources/icons/trash.png',
        },
      ],
    }
  },
  template: `
    <div>
      <row-with-icon
        iconPath="resources/icons/left.png"
        klass="navigation-row"
        v-bind:onclick="() => { EVENT_BUS.$emit('route-property', 'saved-project') },"
      >
        <tag-list v-bind:tagList="headLineTagList"></tag-list>
      </row-with-icon>
      <seperate-line></seperate-line>

      <div class="project-detail-content">
        <div class="project-name">
          Untitled Extension ADU
        </div>
        <seperate-line></seperate-line>
        <div class="project-data">
          <div>900 sqft</div>
          <div>Studio</div>
          <div>1 Bath</div>
        </div>
        <seperate-line></seperate-line>
        <tag-list v-bind:tagList="detailTagList"></tag-list>

        <seperate-line></seperate-line>
        <head-line title="Overview"></head-line>
        <seperate-line></seperate-line>
        <div class="project-description">An extension accessory dwelling unit is connected to an existing single- or multi-family building.  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Dignissim cras tincidunt lobortis feugiat vivamus at augue. Orci sagittis eu volutpat odio facilisis mauris sit. Arcu felis bibendum ut tristique et egestas quis ipsum. Elit pellentesque habitant morbi tristique senectus et netus et. Purus ut faucibus pulvinar elementum integer enim neque. Vitae turpis massa sed elementum tempus egestas sed. Arcu risus quis varius quam quisque id diam vel quam. </div>

        <seperate-line></seperate-line>
        <head-line klass="specification-headline" title="Specifications"></head-line>
        <seperate-line></seperate-line>

        <div class="project-specification">
          <div class="project-specification-block">
            <head-line title ="Building Area" klass="small"></head-line>
            <div class="specification-number">900 sqft</div>
            <div class="specification-note">Max. Area: 1,200 sqft*</div>
            <progress-bar value="0.7"></progress-bar>
          </div>
          <div class="project-specification-block">
            <head-line title ="Building Height" klass="small"></head-line>
            <div class="specification-number">12 ft</div>
            <div class="specification-note">Max. Height:40 ft*</div>
            <progress-bar value="0.3" is-dragable="true"></progress-bar>
          </div>
        </div>
        <seperate-line></seperate-line>

        <div class="project-specification">
          <div class="project-specification-block">
            <head-line title ="Rooms" klass="small"></head-line>
          </div>
          <div class="project-rooms project-specification-block">
            <div class="rooms">
              Bed Rooms
              <div class="calculation">
                <img src="resources/icons/subtract.png" align="center" />
                0
                <img src="resources/icons/add.png" align="center" />
              </div>
            </div>
            <seperate-line></seperate-line>
            <div class="rooms">
              Bath Rooms
              <div class="calculation">
                <img src="resources/icons/subtract.png" align="center" />
                0
                <img src="resources/icons/add.png" align="center" />
              </div>
            </div>
            <seperate-line></seperate-line>
          </div>
        </div>
        <seperate-line></seperate-line>
        <div class="project-description mutiple-line">*Maximum allowed sizes of an Accessory Dwelling Unit according to your local Planning Code.</div>

        <seperate-line></seperate-line>
        <head-line title="Cost"></head-line>
        <div class="bold">Estimated Total Cost</div>
        <div>$480,000</div>
        <div class="project-cost">
          <div class="report-accessory-data">
            <div class="report-accessory-proposed">Building: $400,000</div>
            <div class="report-accessory-allowed">Site Work: $80,000*</div>
          </div>
          <progress-bar value="0.84" class="report-progress-bar"></progress-bar>
        </div>
        <help-article v-bind:hasNoConent="true" title="Estimated Cost Calculator"></help-article>
        <seperate-line></seperate-line>
        <div class="project-description mutiple-line">*This cost can vary greatly depending on the complexity of your site and the local building market.  Adjust the cost assumptions using the Estimated Cost Calculator.</div>

        <seperate-line></seperate-line>
        <head-line title="Do More"></head-line>
        <div
          v-on:click="() => { EVENT_BUS.$emit('route-property', 'report') }"
          class="project-do-more"
        >
          <img src="resources/icons/report_white.png" align="center" />
          <div class="project-do-more-text">See Full Report</div>
        </div>
      </div>
    </div>
  `
});
