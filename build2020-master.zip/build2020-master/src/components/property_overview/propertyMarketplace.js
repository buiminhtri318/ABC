Vue.component('property-marketplace', {
  data: function () {
    return {
      showMenu: false,
      tagList: [
        {
          title: 'Sketch an ADU',
          iconPath: 'resources/icons/edit.png',
        },
        {
          title: 'Demolish Structure',
          iconPath: 'resources/icons/trash.png',
        },
      ],
    }
  },
  template: `
    <div>
      <row-with-icon
        icon-path="resources/icons/adjust.png"
        text="Accessory Dwelling Unit Marketplace"
        klass="menu navigator"
        icon-on-right="true"
        v-bind:onIconClick="() => { this.showMenu = !this.showMenu }"
      >
        <menu-container v-if="!this.showMenu">
          <div>HI</div>
        </menu-container>
      </row-with-icon>
      <seperate-line></seperate-line>
      <tag-list v-bind:tagList="tagList"></tag-list>
      <seperate-line></seperate-line>

      <div class="design-container">
        <div class="design-picture">
          <img src="resources/icons/design.png">
          <div class="design-demo-container">
            <div class="design-demo"></div>
          </div>
        </div>
        <div class="design-info">
          <div class="design-description">
            <p>Wenglowski House</p>
            <p>Peter Forbes</p>
            <p>Pavilion-like · Floor-to-Ceiling Glazing</p>
          </div>
          <div class="design-stats">
            <p>$420k-$500k</p>
            <p>1,000 sqft</p>
            <p>2 Bed · 1 Bath</p>
          </div>
        </div>
      </div>
      <seperate-line></seperate-line>
    </div>
  `
});
