Vue.component('property-marketplace', {
  data: function () {
    return {
      showFiltersMenu: false,
      tagList: [
        {
          title: 'Sketch an ADU',
          iconPath: 'resources/icons/edit.png',
        },
        {
          title: 'Demolish Structure',
          iconPath: 'resources/icons/trash.png',
        },
      ],
      designList: [
        {
          image: 'resources/icons/design.png',
          name: 'Wenglowski House',
          descriptions: ['Peter Forbes', 'Pavilion-like · Floor-to-Ceiling Glazing'],
          data: ['$420k-$500k', '1,000 sqft', '2 Bed · 1 Bath']
        },
        {
          image: 'resources/icons/design.png',
          name: 'Wenglowski House',
          descriptions: ['Peter Forbes', 'Pavilion-like · Floor-to-Ceiling Glazing'],
          data: ['$420k-$500k', '1,000 sqft', '2 Bed · 1 Bath']
        },
      ],
    }
  },
  template: `
    <div>
      <row-with-icon
        v-bind:iconPath="menuIconPath"
        text="Accessory Dwelling Unit Marketplace"
        klass="menu navigator"
        icon-on-right="true"
        v-bind:onIconClick="toggleFiltersMenu"
      >
        <menu-container v-if="this.showFiltersMenu">
          <marketplace-menu></marketplace-menu>
        </menu-container>
      </row-with-icon>
      <seperate-line></seperate-line>
      <tag-list v-bind:tagList="tagList"></tag-list>
      <div v-for="design in designList">
        <seperate-line></seperate-line>
        <marketplace-design-container v-bind:design="design"></marketplace-design-container>
      </div>
    </div>
  `,
  computed: {
    menuIconPath () {
      return 'resources/icons/' + (this.showFiltersMenu ? 'filters.png' : 'adjust.png');
    }
  },
  methods: {
    toggleFiltersMenu: function () {
      this.showFiltersMenu = !this.showFiltersMenu;
    }
  },
  mounted: function () {
    EVENT_BUS.$on('toggle-filters-menu', this.toggleFiltersMenu);
  }
});
