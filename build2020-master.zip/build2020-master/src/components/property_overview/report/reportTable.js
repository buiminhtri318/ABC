Vue.component('report-table', {
  props: ['columns', 'rows', 'klass'],
  template: `
    <div v-bind:class="['report-table', klass]">
      <div class="table-header-row table-row-container">
        <div class="table-row first-row"></div>
        <div class="table-row header" v-for="column in columns">{{column}}</div>
      </div>
      <div class="table-row-container" v-for="row in rows">
        <div class="table-row header first-row">{{row.title}}</div>
        <div class="table-row data" v-for="data in row.data">{{data}}</div>
      </div>
    </div>
  `
})
