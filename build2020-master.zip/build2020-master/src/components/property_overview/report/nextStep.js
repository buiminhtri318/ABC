Vue.component('next-step', {
  props: ['text', 'stepNumber', 'klass'],
  template: `
    <div v-bind:class="['next-step', klass]">
      <circle-shape v-bind:title="stepNumber" background-color="#5F74FE" color="white"></circle-shape>
      <div class="next-step-text">
        {{text}}
      </div>
    </div>
  `
})
