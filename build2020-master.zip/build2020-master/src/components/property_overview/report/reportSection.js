Vue.component('report-section', {
  props: ['title', 'klass'],
  template: `
    <div v-bind:class="['report-section', klass]">
      <head-line v-bind:title="title" klass="report-right-section"></head-line>
      <div class="report-left-section">
        <slot></slot>
      </div>
    </div>
  `
})
