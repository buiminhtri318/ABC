Vue.component('property-option', {
  props: ['isActive', 'title', 'description', 'onclick', 'isNotAllowed', 'klass'],
  data: function() {
    return {
      hover: false,
    }
  },
  template: `
    <div v-on:click="optionClicked" v-bind:class="['option-container', klass]" @mouseover="hover = true" @mouseleave="hover = false">
      <div class="option-icon-title">
        <img v-bind:src="iconPath">
        <div class="option-title">{{title}}</div>
      </div>
      <div class="option-description">{{description}}</div>
    </div>
  `,
  computed: {
    iconPath () {
      var icon;
      if (!this.isActive && !this.hover) {
        icon = 'resources/icons/radio_inactive.png';
      } else if (!this.isActive && this.hover) {
        icon = 'resources/icons/radio_inactive_hover.png';
      } else if (this.isActive && !this.hover) {
        icon = 'resources/icons/radio_active.png';
      } else {
        icon = 'resources/icons/radio_active_hover.png';
      }

      if (this.isNotAllowed) {
        icon = 'resources/icons/not_allowed.png';
      }

      return icon;
    }
  },
  methods: {
    optionClicked: function () {
      this.onclick();
      this.hover = false;
    }
  },
});
