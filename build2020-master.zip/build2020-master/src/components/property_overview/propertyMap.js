Vue.component('property-map', {
  template: `
    <div>
      Map here
    </div>
  `,
});
