Vue.component('property-map', {
  template: `
    <div>

    </div>
  `,
});
