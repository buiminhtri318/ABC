Vue.component('saved-project-menu', {
  template: `
  <div class="marketplace-menu">
    <div class="bold raw-text marketplace-menu-item">Sort</div>
    <seperate-line></seperate-line>
    <div class="raw-text marketplace-menu-item">
      <div>Newest to Oldest</div>
    </div>
    <div class="raw-text marketplace-menu-item">
      <div>Oldest to Newest</div>
    </div>
  </div>
  `
})
