Vue.component('row-with-icon', {
  props: {
    'iconPath': String,
    'text': String,
    'klass': String,
    'isRawText': Boolean,
    'iconOnRight': Boolean,
    'onclick': {
      type: Function,
      default: function () {},
    },
    'onIconClick': {
      type: Function,
      default: function () {},
    },
  },
  template: `
    <div v-bind:class="['row-with-icon',isRawText ? 'raw-text' : 'with-link', klass]" v-on:click="onclick">
      <div class="row-with-icon-icon-container" v-if="!iconOnRight">
        <img v-bind:src="iconPath"  v-on:click="onIconClick">
      </div>
      <div>{{text}}</div>
      <div class="row-with-icon-icon-container" v-if="iconOnRight">
        <img v-bind:src="iconPath" v-on:click="onIconClick">
      </div>
      <slot></slot>
    </div>
  `,
});
