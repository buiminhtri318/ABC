Vue.component('row-with-icon', {
  props: {
    'iconPath': String,
    'text': String,
    'klass': String,
    'isRawText': Boolean,
    'iconOnRight': Boolean,
    'onclick': {
      type: Function,
      default: function () {},
    },
    'onIconClick': {
      type: Function,
      default: function () {},
    },
  },
  template: `
    <div v-bind:class="['row-with-icon',isRawText ? '' : 'with-link', klass]" v-on:click="onclick">
      <img v-bind:src="iconPath" align="center" v-if="!iconOnRight" v-on:click="onIconClick">
      {{text}}
      <img v-bind:src="iconPath" align="center" v-if="iconOnRight" v-on:click="onIconClick">
      <slot></slot>
    </div>
  `,
});
