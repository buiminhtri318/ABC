Vue.component('property-saved-project', {
  data: function () {
    return {
      tagList: [
        { title: 'Accessory Dwelling Unit', isActive: true },
        { title: 'Business'},
      ],
      savedProjectList: [
        {
          image: 'resources/icons/design.png',
          name: 'Wenglowski House',
          description: 'Lundgard + Tranberg',
          data: ['$420k-$500k', '1,000 sqft', '2 Bed', '2 Bath'],
          created_at: 'December 18, 2019'
        },
        {
          image: 'resources/icons/design.png',
          name: 'Untitled Extension ADU',
          description: 'Sketch',
          data: ['900 sqft', 'Studio', '1 Bath'],
          created_at: 'December 19, 2019'
        },
      ],
    }
  },
  template: `
    <div>
      <head-line title="Saved Projects" klass="big"></head-line>
      <seperate-line></seperate-line>
      <tag-list v-bind:tagList="tagList"></tag-list>
      <div v-for="project in savedProjectList">
        <seperate-line></seperate-line>
        <saved-project-container v-bind:project="project"></saved-project-container>
      </div>
    </div>
  `
});
