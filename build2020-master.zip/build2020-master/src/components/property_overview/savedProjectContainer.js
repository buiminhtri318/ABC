Vue.component('saved-project-container', {
  props: {
    project: Object,
  },
  data: function () {
    return {
      showMenu: false,
      showDelete: false,
      deleteTagList: [
        {
          title: 'Delete',
          iconPath: 'resources/icons/trash_red.png',
        },
        {
          title: 'Cancel',
          iconPath: 'resources/icons/close_red.png',
          onclick: this.hideDelete,
        },
      ],
      moreMenuItems: [
        {
          text: 'Project Details',
          iconPath: 'resources/icons/report.png',
          hasLine: true,
          onclick: () => { EVENT_BUS.$emit('route-property', 'project-detail') },
        },
        { text: 'Share', iconPath: 'resources/icons/share.png' },
        { text: 'Delete', iconPath: 'resources/icons/trash.png', onclick: this.showDelete },
      ]
    }
  },
  template: `
    <div class="saved-project-container">
      <img v-bind:src="project.image" class="project-cover">
      <div class="project-info" v-if="!showDelete">
        <div class="project-name">
          {{project.name}}
          <menu-container v-if="showMenu">
            <div v-for="item in moreMenuItems">
              <row-with-icon
                v-bind:iconPath="item.iconPath"
                v-bind:text="item.text"
                v-bind:onclick="item.onclick"
              ></row-with-icon>
              <seperate-line v-if="item.hasLine"></seperate-line>
            </div>
          </menu-container>
          <div class="more-icon">
            <img v-bind:src="moreIconPath" v-on:click="toggleMenu" align="center" />
          </div>
        </div>
        <p>{{project.description}}</p>
        <div class="project-data">
          <div v-for="data in project.data">{{data}}</div>
        </div>
        <div class="project-created-at">{{'Created ' + project.created_at}}</div>
      </div>
      <div class="project-info alert" v-if="showDelete">
        <div class="project-name">Delete this project?</div>
        <div class="project-created-at">
          <tag-list v-bind:tagList="deleteTagList"></tag-list>
        </div>
      </div>
    </div>
  `,
  computed: {
    moreIconPath() {
      return 'resources/icons/' + (this.showMenu ? 'more_active.png' : 'more_inactive.png');
    }
  },
  methods: {
    toggleMenu: function() {
      this.showMenu = !this.showMenu;
    },
    showDelete: function() {
      this.showDelete = true;
      this.showMenu = false;
    },
    hideDelete: function() {
      this.showDelete = false;
    },
  }
});
