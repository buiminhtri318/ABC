Vue.component('saved-project-container', {
  props: {
    project: Object,
  },
  template: `
    <div class="saved-project-container">
      <img v-bind:src="project.image">
      <div class="project-info">
        <div class="project-name">{{project.name}}</div>
        <p>{{project.description}}</p>
        <div class="project-data">
          <div v-for="data in project.data">{{data}}</div>
        </div>
        <div class="project-created-at">{{'Created ' + project.created_at}}</div>
      </div>
    </div>
  `
});
