Vue.component('marketplace-design-container', {
  props: {
    design: Object,
  },
  template: `
    <div class="design-container" v-on:click="() => { EVENT_BUS.$emit('route-property', 'design-detail') }">
      <div class="design-picture">
        <img v-bind:src="design.image">
        <div class="design-demo-container">
          <div class="design-demo"></div>
        </div>
      </div>
      <div class="design-info">
        <div class="design-description">
          <p class="design-name">{{design.name}}</p>
          <p v-for="description in design.descriptions">{{description}}</p>
        </div>
        <div class="design-stats">
          <p v-for="data in design.data">{{data}}</p>
        </div>
      </div>
    </div>
  `
});
