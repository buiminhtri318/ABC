Vue.component('property-report', {
  data: function () {
    return {
      headLineTagList: [
        {
          title: 'Share',
          iconPath: 'resources/icons/share.png',
        },
        {
          title: 'Download',
          iconPath: 'resources/icons/download.png',
        },
        {
          title: 'Saved',
          iconPath: 'resources/icons/heart_white.png',
          isActive: false,
          onclick: () => { this.headLineTagList[2].isActive = !this.headLineTagList[2].isActive }
        },
      ],
      infoList: [
        { title: "Address", text: "1039 Broderick St,  San Francisco, CA" },
        { title: "Block/Lot", text: "1130005", inactive: true },
        { title: "Lot Area", text: "2,769 sqft" },
        { title: "Building Area", text: "4,556 sqft" },
        { title: "Number of Units", text: "1" },
        { title: "Stories", text: "3" },
        { title: "Zoning District", text: "RM-1", inactive: true },
        { title: "Special Use District", text: "Within 1/4 Mile of an Existing Fringe Financial Service", inactive: true },
      ],
      summaryInfoList: [
        { title: "Project Description", text: "New 900 sqft, 2-level freestanding accessory dwelling unit to contain 2 bedrooms, 2 bathrooms, kitchen, and living room.", klass: "mutiple-line-row" },
        {
          title: "Project Data",
          inactive: true,
          klass: "mutiple-line-row",
          table: {
            columns: ['Existing', 'Proposed'],
            rows: [
              { title: 'Lot Area', data: ['2,769 sqft', '-'] },
              { title: 'Building Area', data: ['4,556 sqft', '5,456 sqft (900 sqft increase)'] },
              { title: 'ADU Height', data: ['-', '22 ft'] },
            ],
          }
        },
      ],
      accessoryInfoList: [
        { title: "Floor Area", klass: "mutiple-line-row" },
        { title: "Height", klass: "mutiple-line-row" },
        { title: "Open Space Requirement", klass: "mutiple-line-row", inactive: true },
        {
          title: "Setbacks",
          inactive: true,
          klass: "mutiple-line-row",
          table: {
            columns: ['Allowed', 'Proposed'],
            rows: [
              { title: 'Front', data: ['11.8 ft', '15 ft'] },
              { title: 'Side 1', data: ['3 ft', '6 ft'] },
              { title: 'Side 2', data: ['3 ft', '9 ft'] },
              { title: 'Rear', data: ['25.1 ft', '30 ft'] },
            ],
          }
        },
      ],
      siteChallenges: [
        "Steeply sloped property",
        "Some other environmental sensitivity",
      ],
      costDropdowns: [
        "ADU may be rented, but not for less than 30 days",
        "ADU can’t be sold separately from the main home",
        "If/because the ADU is 750 sq. ft. or larger, impact fees will be charged",
        "Fire sprinklers will be required if they were required for the main home",
        "The owner must live on the property (only for JADUs",
        "Tax liability will increase based on the added value the ADU brings to the property",
      ],
      nextSteps: [
        'Learn more about ADUs, in general',
        'Read the report below to learn about the rules that will apply',
        'Reach out to an architect',
        'Contact your local jurisdiction with any questions',
        'Then some other stuff should be done',
        'Then final things should be done',
      ]
    }
  },
  template: `
    <div>
      <row-with-icon
        iconPath="resources/icons/left.png"
        klass="navigation-row"
        v-bind:onIconClick="() => { EVENT_BUS.$emit('route-property', 'project-detail') },"
      >
        <tag-list v-bind:tagList="headLineTagList"></tag-list>
      </row-with-icon>
      <seperate-line></seperate-line>

      <report-section title="Development Standards Report">
        <img src="resources/icons/map.png">
      </report-section>

      <report-section title="Property Information">
        <seperate-line></seperate-line>
        <div v-for="info in infoList">
          <property-row v-bind:info="info"></property-row>
          <seperate-line></seperate-line>
        </div>
      </report-section>

      <report-section title="Project Summary">
        <seperate-line></seperate-line>

        <property-row v-bind:info="summaryInfoList[0]"></property-row>
        <seperate-line></seperate-line>

        <property-row v-bind:info="summaryInfoList[1]">
          <report-table
            v-bind:columns="summaryInfoList[1].table.columns"
            v-bind:rows="summaryInfoList[1].table.rows"
          ></report-table>
        </property-row>
        <seperate-line></seperate-line>
      </report-section>

      <report-section title="Accessory Dwelling Unit Design">
        <seperate-line></seperate-line>

        <property-row v-bind:info="accessoryInfoList[0]">
          <div>
            <div class="report-accessory-data">
              <div class="report-accessory-proposed">Proposed: 900 sqft</div>
              <div class="report-accessory-allowed">Allowed: 1,200 sqft</div>
            </div>
            <progress-bar value="0.75" class="report-progress-bar"></progress-bar>
          </div>
        </property-row>
        <seperate-line></seperate-line>

        <property-row v-bind:info="accessoryInfoList[1]">
          <div>
            <div class="report-accessory-data">
              <div class="report-accessory-proposed">Proposed: 25 ft</div>
              <div class="report-accessory-allowed">Allowed: 40 ft</div>
            </div>
            <progress-bar value="0.64" class="report-progress-bar"></progress-bar>
          </div>
        </property-row>
        <seperate-line></seperate-line>

        <property-row v-bind:info="accessoryInfoList[2]">
          <div>
            <div>Common Usable Open Space: 150 sqft</div>
            <div>Private Usable Open Space: 100 sqft</div>
          </div>
        </property-row>
        <seperate-line></seperate-line>

        <property-row v-bind:info="accessoryInfoList[3]">
          <report-table
            v-bind:columns="accessoryInfoList[3].table.columns"
            v-bind:rows="accessoryInfoList[3].table.rows"
          ></report-table>
        </property-row>
        <help-article title="Additional Requirements"></help-article>
        <seperate-line></seperate-line>
      </report-section>

      <report-section title="Site Challenges">
        <help-article v-for="text in siteChallenges" v-bind:title="text" v-bind:hasNoConent="true"></help-article>
        <seperate-line></seperate-line>
      </report-section>

      <report-section title="Cost">
        <help-article v-for="text in costDropdowns" v-bind:title="text" v-bind:hasNoConent="true"></help-article>
        <seperate-line></seperate-line>
      </report-section>


      <report-section title="Next Steps" klass="report-section-last">
        <seperate-line></seperate-line>
        <div v-for="step in nextSteps">
          <next-step v-bind:text="step" v-bind:stepNumber="1 + nextSteps.indexOf(step)"></next-step>
          <seperate-line></seperate-line>
        </div>
      </report-section>

      <seperate-line></seperate-line>
      <report-section title="" klass="footer-section">
        <div>This information doesn't constitute an entitlement or legal advice. San Francisco has the final say with regards to the administration and enforcement of its Planning Code.</div>
      </report-section>
    </div>
  `,
});
