Vue.component('marketplace-menu', {
  template: `
    <div class="marketplace-menu">
      <div class="bold raw-text marketplace-menu-item">Filters</div>
      <seperate-line></seperate-line>
      <div class="raw-text marketplace-menu-item">
        <div>Price: Any Price</div>
        <progress-bar value="1" is-dragable="true" height="2" dragable-background-color="#5F74FE"></progress-bar>
      </div>
      <seperate-line></seperate-line>
      <div class="raw-text marketplace-menu-item">
        <div>Size: Any Size</div>
        <progress-bar value="1" is-dragable="true" height="2" dragable-background-color="#5F74FE"></progress-bar>
      </div>
    </div>
  `,
});
