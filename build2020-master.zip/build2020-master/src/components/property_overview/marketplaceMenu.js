Vue.component('marketplace-menu', {
  template: `
    <div>
      <row-with-icon
        icon-path="resources/icons/close.png"
        text="Filters"
        is-raw-text="true"
        icon-on-right="true"
        v-bind:onIconClick="function() { EVENT_BUS.$emit('toggle-filters-menu') }"
      ></row-with-icon>
      <seperate-line></seperate-line>
      <div class="raw-text">Price: Any Price</div>
      <seperate-line></seperate-line>
      <div class="raw-text">Size: Any Size</div>
    </div>
  `,
});
