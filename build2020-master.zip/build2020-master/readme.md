There is no setup require to run this project. You just need to open index.html file in any browser
