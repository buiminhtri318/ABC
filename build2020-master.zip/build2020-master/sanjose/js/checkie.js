function checkIE()
{
  var ua = window.navigator.userAgent;
  if (/MSIE|Trident/.test(ua))
  {
    fullreact(seq('click','openiewarning'));
  }
}