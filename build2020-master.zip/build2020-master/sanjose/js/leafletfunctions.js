//addmark -> addmapboxmark
//fit parcel to map
function createparcel()
{
  if (_leaflayers['parcel'] && _leaflayers['parcel'] != null) 
    _leaflets['maplayer'].removeLayer(_leaflayers['parcel']); 

  _leaflayers['parcel'] = L.geoJSON(_geometry,{style: {fillColor: 'white', color: 'black', fillOpacity: 0.5, weight: 2, dashArray:[13,5,3,5]}});
  _leaflayers['parcel'].on("click",function(){if (_leaflets.maplayer._zoom < 19) _leaflets.maplayer.fitBounds(_leaflayers.parcel.getBounds().pad(0.25));});

  _leaflayers['parcel'].addTo(_leaflets['maplayer']);
  _leaflets['maplayer'].invalidateSize();
  _leaflets['maplayer'].fitBounds(_leaflayers['parcel'].getBounds().pad(0.25));
}
function initializeTransit()
{
  if (_leaflayers['carsharetransit'])
  {
    if (_leaflets.maplayer.hasLayer(_leaflayers['carsharetransit']))
      _leaflets.maplayer.removeLayer(_leaflayers['carsharetransit']);
  }
  //Create Layer  
  _leaflayers['carsharetransit'] = L.markerClusterGroup(
    {
      showCoverageOnHover: false,
      disableClusteringAtZoom: 16,
      spiderfyOnMaxZoom: false
    }
  );
  //Bind Popups
  _leaflayers['carsharetransit'].bindPopup(
    function(layer)
    {
      if (layer.feature.properties.description)
          return "<b>Zip Car</b><hr>Location: " + layer.feature.properties.description;
      else if (layer.feature.properties.stop_name)
          return "<b>" + layer.feature.properties.stop_type + "</b><hr>Name: " + layer.feature.properties.stop_name;
      else
          return "Area within &frac12; mile of your propety";
    }
  );

  //Add zipcars.
  var url = _datapath + 'zipcar.geojson',
      zp = JSON.parse(posteval(url)),
      zipcars = turf.featureCollection([zp]);
  _leaflayers['carshare'] = L.geoJson(zipcars,
  {
    pointToLayer: function(feature, latlng)
    {
      var smallIcon = L.icon(
      {
        iconSize: [20, 27],
        iconAnchor: [12, 27],
        iconRetinaUrl: '../lib/img/carshare.png',
        iconUrl: '../lib/img/carshare.png'
      });
      return L.marker(latlng, {icon: smallIcon});
    }
  });
  _leaflayers['carsharetransit'].addLayer(_leaflayers['carshare']);

  //Add Transit.
  var transit = _cache[_apn].report.transitstops.map(i => {var x = {"type": "Feature", "geometry": i[2], "properties": {"stop_name": i[0], "stop_type": i[1]}}; return x});
  if (transit)
  {
    _leaflayers['transit'] = L.geoJson(transit,
      {
        pointToLayer: function(feature, latlng)
        {
          var smallIcon = L.icon(
          {
            iconSize: [20, 27],
            iconAnchor: [12, 27],
            iconRetinaUrl: '../lib/img/transit.png',
            iconUrl: '../lib/img/transit.png'
          });
          return L.marker(latlng, {icon: smallIcon});
        }
      }
    );
    _leaflayers['carsharetransit'].addLayer(_leaflayers['transit']);
  }

  //Add 1/2 mile buffer
  _leaflayers['transitbuffer'] = L.geoJson(turfAM.buffer(_geometry,0.5,{units:'miles'}),{style: {weight: 1, dashArray: [3,3], color: '#4ab3d0', fillColor: '#d1ecf3', fillOpacity: 0.1}});
  _leaflayers['carsharetransit'].addLayer(_leaflayers['transitbuffer']);
}
function resetbuildings()
{
  var l = _leaflayers.draw._layers, footprint = 0, buildingpresent = false;
  for (var i in l)
  {
    if (l[i] instanceof L.Polygon && l[i].options.className && l[i].options.className.indexOf('building') != -1)
    {
      _leaflayers.draw.removeLayer(l[i]);
    }
  } 
}
function ensuredrawlayer()
{
  if (!_leaflets['maplayer'].hasLayer(_leaflayers['draw']))
  {
    _leaflets['maplayer'].addLayer(_leaflayers['draw']);
    _leaflets['maplayer'].addControl(_leafcontrols['draw']);
  }
}
function addBuildings()
{
  ensuredrawlayer();
  resetbuildings();
  var buildings = _cache[_apn].report.footprint;
  var groundfloorarea = 0;
  for (var i = 0; i < buildings.length; i++)
  {
    initializeBuilding(buildings[i]);
  }
  return;
}
function initializeBuilding(building)
{
  var g = building;
  g = L.polygon(L.geoJson(building).getLayers()[0].getLatLngs(), {transform: {rotation: true, scaling: false}, editing: true, draggable: true});
  g.setStyle(
    {
      color: '#222',
      weight: 2,
      opacity: 1,
      fillColor: '#AAA',
      fillOpacity: 0.4,
      className: 'building'
    }
  );
  addBuildingHandlers(g);
  g.addTo(_leaflayers['draw']);
  g.bindPopup(getPopupContent(g));
}

function addBuildingHandlers(g)
{
  enablerotatehandler(g);
  g.transform.setOptions({rotateHandleOptions:{color:'#222'}, boundsOptions:{color:'#222'}});
  g.on('drag',
    function()
    {
      checklayers();
      if (this.transform && this.transform.enabled())       
      {
        this.transform._rect.setLatLngs(L.geoJson(turf.bboxPolygon(turf.bbox(L.polygon(this.getLatLngs()).toGeoJSON(13)))).getLayers()[0].getLatLngs()); 
        this.transform._updateHandlers();
      }
      this.editing.disable();
      disablerotate();
      syncmeasurements(this);
    }
  );

  g.on('dragend',
    function()
    {
      if (this.transform)
      {
        checklayers();
        syncmeasurements(this);
      }
      if (!this.dragging.enabled())
        this.dragging.enable();
      
      recomputebackyardarea();
    }
  ); 

  g.on('click',
    function()
    {
      this.bindPopup(getPopupContent(this));
    }
  );
}
function fittoparcel()
{
  _leaflets['maplayer'].invalidateSize();
  _leaflets['maplayer'].fitBounds(_leaflayers['parcel'].getBounds().pad(0.1));
}
function fittotransit()
{
  _leaflets['maplayer'].invalidateSize();
  if (_leaflayers['transitbuffer'])
    _leaflets['maplayer'].fitBounds(_leaflayers['transitbuffer'].getBounds().pad(0.1));
}
//Zoom message - add, update text on events
function addzoomMessage()
{
  _leaflets.maplayer._controlCorners.topcenter =  L.DomUtil.create('div', 'leaflet-top leaflet-center', _leaflets.maplayer._controlContainer);
  _leafcontrols.zoomMessage = L.control({position: 'topcenter'});
  _leafcontrols.zoomMessage.onAdd = 
    function()
    {
      var d = document.createElement("span");
      d.setAttribute("class","zoomMessage");
      d.innerHTML = "Zoom in to select a parcel";
      return d;
    };
  _leaflets.maplayer.addControl(_leafcontrols.zoomMessage);
  _leaflets.maplayer.on("zoom",
    function()
    {
      checkzoomtext();
    }
  );
}
function checkzoomtext()
{
  var zoom = _leaflets.maplayer._zoom;
  if (zoom >= 16.5)
  {
    _leafcontrols.zoomMessage.getContainer().innerHTML = "Click on the map to select a parcel";
  }
  else
  {
    _leafcontrols.zoomMessage.getContainer().innerHTML = "Zoom in to select a parcel";
  }
}
//Boundary layer - bind / unbind clicks.
function boundaryaddclick()
{
  _leaflayers['boundary'].on('click',
    function(e)
    {
      _leaflayers['boundary'].unbindPopup();
      sf_geom = null, _apn = null, _infoset = false;
      _leafcoord = {
        y: e.latlng.lat,
        x: e.latlng.lng
      };
      if (_leaflets.maplayer._zoom >= 16.5)
      {
        if (_leaflets.maplayer.isFullscreen())
        {
          _leaflets.maplayer._disablePseudoFullscreen(_leaflets.maplayer._container);
        }
        getparcellatlng();
      }
    }
  );
}
function boundaryunbindclick()
{
  _leaflayers.boundary.removeEventListener('click');
}

/*Legend*/
function addLegend(id)
{
  _legend = L.control(
    {
      position: 'bottomright'
    }
  );

  _legend.onAdd = function(map)
  {
    var div = L.DomUtil.create('div', 'info legend');

    divinner = document.createElement("div");
    divinner.innerHTML += '<div id="hidelegendcontainer"><a href="javascript:void(0);" id="hidelegend" onclick="modbutton(this); dontPropagateLegendGesture(event);"><span class="fas fa-window-minimize"></span></a></div>';
    divinner.innerHTML += ['<div style="text-align: left; padding: 0px 0px 0px 10px; margin: 0px;" id="legend(adu)">',
    '<div class="legend-header">Understand regulations:</div>',
    '<box id="zonelegend"><label style="margin-bottom: 0px; display: block; margin-bottom: 0rem; padding-left: 10px;"><input type="checkbox" onchange="modcheck(this); dontPropagateLegendGesture(event);" name="layer" value="adu"> Zoning Clearance</label><span style="color:#F03434; margin-bottom: 0px; padding-left: 10px;" class="legend"><i class="fas fa-square"></i> Not allowed</span><span style="color:#26C281; padding-left: 10px;" class="legend"><i class="fas fa-square"></i> Allowed</span></box>',
    '<label id="legend(setback)" style="display: block; margin-bottom: 0rem; padding-left: 10px;"><input type="checkbox" onchange="modcheck(this); dontPropagateLegendGesture(event);" name="layer" value="setback"> Setbacks</label>',
    '</div>'].join('');

    divinner.innerHTML += '<div style="text-align: left; padding: 10px 0px 0px 10px;" id="legend(draw)"> <div class="legend-header">Sketch a Site Plan: </div> <container id="drawcontainer" style="padding-left: 10px;"><highlight style="display: none;"></highlight><a href="javascript:void(0)" id="drawbuilding" onclick="startdrawing(this.parentNode)" style="display: block;"> <img src="../lib/img/polygon.png" alt="Draw building" style="width: 12px; height: 12px;"/> Draw building </a> <span class="drawcontrol"> <img src="../lib/img/polygon.png" alt="Draw building" style="width: 12px; height: 12px; visibility: hidden;"/> <a href="javascript:void(0)" onclick="undodrawmeasure()" class="action-btn undo">undo</a> <a href="javascript:void(0)" onclick="enddrawing()" class="action-btn" style="margin-left: 5px">cancel</a> </span></container> <container style="padding-left: 10px;"><highlight style="display: none;"></highlight><a href="javascript:void(0)" id="measure" onclick="startmeasure(this.parentNode)" style="display: block;"> <img src="../lib/img/line.png" alt="Measure" style="width: 12px; height: 12px;"/> Measure </a> <span class="measurecontrol"> <img src="../lib/img/line.png" alt="Measure" style="width: 12px; height: 12px; visibility: hidden;"/> <a href="javascript:void(0)" onclick="undodrawmeasure()" class="action-btn undo">undo</a> <a href="javascript:void(0)" onclick="endmeasure()" class="action-btn" style="margin-left: 5px">cancel</a> </span></container> <container style="padding-left: 10px;"><a href="javascript:void(0)" id="help(instructions)" onclick="modbutton(this)" style="display: block;"> <img src="../lib/img/help.png" alt="Drawing instructions" style="width: 12px; height: 12px; vertical-align: text-top;"/> How to...? </a></container></div>';
    divinner.innerHTML += '<div style="text-align: left; padding: 10px 0px 0px 10px;" id="legend(site)"> <div class="legend-header">About your property:</div> <label style="display: block; margin-bottom: 0rem; padding-left: 10px;"> <input type="checkbox" onchange="modcheck(this); doneediting(); dontPropagateLegendGesture(event);" name="layer" value="measurement"> Dimensions </label> <label style="display: block; margin-bottom: 0rem; padding-left: 10px;" id="legend(carsharetransit)"> <input type="checkbox" onchange="modcheck(this); dontPropagateLegendGesture(event); if (_leaflets.maplayer.hasLayer(_leaflayers.carsharetransit)) fittotransit(); else fittoparcel();" name="layer" value="carsharetransit"> Car Share and Public Transit </label> <br><a href="javascript:void(0)" onclick="doneediting(); addBuildings(); populatesheet(); recomputebackyardarea();" style="padding-left: 10px;">Re-import building footprints</a> </div>';

    divinner.innerHTML += '<div class="attribution"> <a href="https://www.mapbox.com/about/maps/" target="_blank">&copy; Mapbox</a> | <a href="http://www.openstreetmap.org/about/" target="_blank">&copy; OpenStreetMap</a> | <a href="https://www.mapbox.com/map-feedback/#/-74.5/40/10" target="_blank">Improve this map</a> </div>';

    divinner.setAttribute("id", "mainlegend");

    divmenu = document.createElement("div");
    divmenu.setAttribute("id", "legendmenu");
    divmenu.style.cursor = "pointer";
    divmenu.setAttribute("title", "View Legend and Map Layers");
    divmenu.setAttribute("onclick", "modbutton(this); dontPropagateLegendGesture(event);")
    divmenu.innerHTML = '<i class="fas fa-bars"></i>';
    divmenu.style.display = 'none';

    div.appendChild(divmenu);
    div.appendChild(divinner);

    div.style.padding = "10px";
    div.style['background-color'] = 'white';
    div.style['font-weight'] = 'bold';
    div.style['margin'] = '0px';
    div.style['border'] = '2px solid lightgrey';
    div.style['border-radius'] = '4px';
    div.setAttribute("id", "legendcontainer");
    div.setAttribute("onclick", "dontPropagateLegendGesture(event);");
    L.DomEvent.on(div, 'mousewheel', L.DomEvent.stopPropagation);
    return div;
  };

  _legend.addTo(_leaflets[id]);
  if (!L.Browser.touch)
    L.DomEvent.disableClickPropagation(_legend._container).disableScrollPropagation(_legend._container);
  else
    L.DomEvent.disableClickPropagation(_legend._container);
  _legend._container.parentNode.style.margin = "5px";
}

//stop bubbling gestures on map legend
function dontPropagateLegendGesture(e)
{
  if (!e)
    e = window.event;
  if (e.stopPropagation)
    e.stopPropagation();
  else
    e.cancelBubble = true;
}


//Controls - Fullscreen and Satellite
L.Control.Fullscreen = L.Control.extend(
  {
    options:
    {
      position: "topleft",
      title:
      {
          "false": "View Fullscreen",
          "true": "Exit Fullscreen"
      }
    },
    onAdd: function(map)
    {
      var container = L.DomUtil.create("div", "leaflet-control-fullscreen leaflet-bar leaflet-control");
      this.link = L.DomUtil.create("a", "leaflet-control-fullscreen-button leaflet-bar-part", container);
      this.link.href = "javascript:void(0)";
      this._map = map;
      this._map.on("fullscreenchange", this._toggleTitle, this);
      this._toggleTitle();
      L.DomEvent.on(this.link, "click", this._click, this);
      return container;
    },
    _click: function(e)
    {
      L.DomEvent.stopPropagation(e);
      L.DomEvent.preventDefault(e);
      this._map.toggleFullscreen(this.options);
    },
    _toggleTitle: function()
    {
      this.link.setAttribute("datatitle", this.options.title[this._map.isFullscreen()]);
    }
  }
);
L.Control.satellite = L.Control.extend(
  {
    options:
    {
      position: "topleft",
      title:
      {
        "false": "Satellite View",
        "true": "Map View"
      }
    },
    onAdd: function(map)
    {
      var container = L.DomUtil.create("div", "leaflet-control-fullscreen leaflet-bar leaflet-control");
      this.link = L.DomUtil.create("a", "leaflet-bar-part", container);
      this.link.href = "javascript:void(0);";
      this._toggleTitle();
      L.DomEvent.on(this.link, "click", this._click, this);
      return container;
    },
    _click: function(e)
    {
      L.DomEvent.stopPropagation(e);
      L.DomEvent.preventDefault(e);
      fullreact('togglemapview');
      this._toggleTitle();
    },
    _toggleTitle: function()
    {
      var isSatellite = compfindx("satellite", ["tile", "satellite"], lambda, library);
      this.link.setAttribute("datatitle", this.options.title[isSatellite ? true : false]);
      if (!isSatellite)
      {
        this.link.style.backgroundSize = "22px";
        this.link.style.backgroundImage = "url(../lib/img/satellite.png)";
        this.link.style.backgroundRepeat = "no-repeat";
        if (_leafcontrols.zoomMessage)
          _leafcontrols.zoomMessage.getContainer().style.backgroundColor = "rgba(255,255,255,0.5)";
      }
      else
      {
        this.link.style.backgroundSize = "18px";
        this.link.style.backgroundImage = "url(../lib/img/map.png)";
        this.link.style.backgroundRepeat = "no-repeat";
        if (_leafcontrols.zoomMessage)
          _leafcontrols.zoomMessage.getContainer().style.backgroundColor = "rgba(255,255,255,0.8)";
      }
    }
  }
);
//Add mapbox mark
function addmapboxmark()
{
  var l = L.control({position: 'topright'});
  l.onAdd = function(map)
  {
    var d = document.createElement("div");
    d.innerHTML = '<a href="https://www.mapbox.com/about/maps/" target="_blank" style="background-image: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz48c3ZnIHZlcnNpb249IjEuMSIgaWQ9IkxheWVyXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB2aWV3Qm94PSIwIDAgODAuNDcgMjAuMDIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDgwLjQ3IDIwLjAyOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PHN0eWxlIHR5cGU9InRleHQvY3NzIj4uc3Qwe29wYWNpdHk6MC42O2ZpbGw6I0ZGRkZGRjtlbmFibGUtYmFja2dyb3VuZDpuZXcgICAgO30uc3Qxe29wYWNpdHk6MC42O2VuYWJsZS1iYWNrZ3JvdW5kOm5ldyAgICA7fTwvc3R5bGU+PGc+PHBhdGggY2xhc3M9InN0MCIgZD0iTTc5LjI5LDEzLjYxYzAsMC4xMS0wLjA5LDAuMi0wLjIsMC4yaC0xLjUzYy0wLjEyLDAtMC4yMy0wLjA2LTAuMjktMC4xNmwtMS4zNy0yLjI4bC0xLjM3LDIuMjhjLTAuMDYsMC4xLTAuMTcsMC4xNi0wLjI5LDAuMTZoLTEuNTNjLTAuMDQsMC0wLjA4LTAuMDEtMC4xMS0wLjAzYy0wLjA5LTAuMDYtMC4xMi0wLjE4LTAuMDYtMC4yN2MwLDAsMCwwLDAsMGwyLjMxLTMuNWwtMi4yOC0zLjQ3Yy0wLjAyLTAuMDMtMC4wMy0wLjA3LTAuMDMtMC4xMWMwLTAuMTEsMC4wOS0wLjIsMC4yLTAuMmgxLjUzYzAuMTIsMCwwLjIzLDAuMDYsMC4yOSwwLjE2bDEuMzQsMi4yNWwxLjMzLTIuMjRjMC4wNi0wLjEsMC4xNy0wLjE2LDAuMjktMC4xNmgxLjUzYzAuMDQsMCwwLjA4LDAuMDEsMC4xMSwwLjAzYzAuMDksMC4wNiwwLjEyLDAuMTgsMC4wNiwwLjI3YzAsMCwwLDAsMCwwTDc2Ljk2LDEwbDIuMzEsMy41Qzc5LjI4LDEzLjUzLDc5LjI5LDEzLjU3LDc5LjI5LDEzLjYxeiIvPjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik02My4wOSw5LjE2Yy0wLjM3LTEuNzktMS44Ny0zLjEyLTMuNjYtMy4xMmMtMC45OCwwLTEuOTMsMC40LTIuNiwxLjEyVjMuMzdjMC0wLjEyLTAuMS0wLjIyLTAuMjItMC4yMmgtMS4zM2MtMC4xMiwwLTAuMjIsMC4xLTAuMjIsMC4yMnYxMC4yMWMwLDAuMTIsMC4xLDAuMjIsMC4yMiwwLjIyaDEuMzNjMC4xMiwwLDAuMjItMC4xLDAuMjItMC4yMnYtMC43YzAuNjgsMC43MSwxLjYyLDEuMTIsMi42LDEuMTJjMS43OSwwLDMuMjktMS4zNCwzLjY2LTMuMTNDNjMuMjEsMTAuMyw2My4yMSw5LjcyLDYzLjA5LDkuMTZMNjMuMDksOS4xNnogTTU5LjEyLDEyLjQxYy0xLjI2LDAtMi4yOC0xLjA2LTIuMy0yLjM2VjkuOTljMC4wMi0xLjMxLDEuMDQtMi4zNiwyLjMtMi4zNnMyLjMsMS4wNywyLjMsMi4zOVM2MC4zOSwxMi40MSw1OS4xMiwxMi40MXoiLz48cGF0aCBjbGFzcz0ic3QwIiBkPSJNNjguMjYsNi4wNGMtMS44OS0wLjAxLTMuNTQsMS4yOS0zLjk2LDMuMTNjLTAuMTIsMC41Ni0wLjEyLDEuMTMsMCwxLjY5YzAuNDIsMS44NSwyLjA3LDMuMTYsMy45NywzLjE0YzIuMjQsMCw0LjA2LTEuNzgsNC4wNi0zLjk5UzcwLjUxLDYuMDQsNjguMjYsNi4wNHogTTY4LjI0LDEyLjQyYy0xLjI3LDAtMi4zLTEuMDctMi4zLTIuMzlzMS4wMy0yLjQsMi4zLTIuNHMyLjMsMS4wNywyLjMsMi4zOVM2OS41MSwxMi40MSw2OC4yNCwxMi40Mkw2OC4yNCwxMi40MnoiLz48cGF0aCBjbGFzcz0ic3QxIiBkPSJNNTkuMTIsNy42M2MtMS4yNiwwLTIuMjgsMS4wNi0yLjMsMi4zNnYwLjA2YzAuMDIsMS4zMSwxLjA0LDIuMzYsMi4zLDIuMzZzMi4zLTEuMDcsMi4zLTIuMzlTNjAuMzksNy42Myw1OS4xMiw3LjYzeiBNNTkuMTIsMTEuMjNjLTAuNiwwLTEuMDktMC41My0xLjExLTEuMTlWMTBjMC4wMS0wLjY2LDAuNTEtMS4xOSwxLjExLTEuMTlzMS4xMSwwLjU0LDEuMTEsMS4yMVM1OS43NCwxMS4yMyw1OS4xMiwxMS4yM3oiLz48cGF0aCBjbGFzcz0ic3QxIiBkPSJNNjguMjQsNy42M2MtMS4yNywwLTIuMywxLjA3LTIuMywyLjM5czEuMDMsMi4zOSwyLjMsMi4zOXMyLjMtMS4wNywyLjMtMi4zOVM2OS41MSw3LjYzLDY4LjI0LDcuNjN6IE02OC4yNCwxMS4yM2MtMC42MSwwLTEuMTEtMC41NC0xLjExLTEuMjFzMC41LTEuMiwxLjExLTEuMnMxLjExLDAuNTQsMS4xMSwxLjIxUzY4Ljg1LDExLjIzLDY4LjI0LDExLjIzeiIvPjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik00My41Niw2LjI0aC0xLjMzYy0wLjEyLDAtMC4yMiwwLjEtMC4yMiwwLjIydjAuN2MtMC42OC0wLjcxLTEuNjItMS4xMi0yLjYtMS4xMmMtMi4wNywwLTMuNzUsMS43OC0zLjc1LDMuOTlzMS42OSwzLjk5LDMuNzUsMy45OWMwLjk5LDAsMS45My0wLjQxLDIuNi0xLjEzdjAuN2MwLDAuMTIsMC4xLDAuMjIsMC4yMiwwLjIyaDEuMzNjMC4xMiwwLDAuMjItMC4xLDAuMjItMC4yMlY2LjQ0YzAtMC4xMS0wLjA5LTAuMjEtMC4yMS0wLjIxQzQzLjU3LDYuMjQsNDMuNTcsNi4yNCw0My41Niw2LjI0eiBNNDIuMDIsMTAuMDVjLTAuMDEsMS4zMS0xLjA0LDIuMzYtMi4zLDIuMzZzLTIuMy0xLjA3LTIuMy0yLjM5czEuMDMtMi40LDIuMjktMi40YzEuMjcsMCwyLjI4LDEuMDYsMi4zLDIuMzZMNDIuMDIsMTAuMDV6Ii8+PHBhdGggY2xhc3M9InN0MSIgZD0iTTM5LjcyLDcuNjNjLTEuMjcsMC0yLjMsMS4wNy0yLjMsMi4zOXMxLjAzLDIuMzksMi4zLDIuMzlzMi4yOC0xLjA2LDIuMy0yLjM2VjkuOTlDNDIsOC42OCw0MC45OCw3LjYzLDM5LjcyLDcuNjN6IE0zOC42MiwxMC4wMmMwLTAuNjcsMC41LTEuMjEsMS4xMS0xLjIxYzAuNjEsMCwxLjA5LDAuNTMsMS4xMSwxLjE5djAuMDRjLTAuMDEsMC42NS0wLjUsMS4xOC0xLjExLDEuMThTMzguNjIsMTAuNjgsMzguNjIsMTAuMDJ6Ii8+PHBhdGggY2xhc3M9InN0MCIgZD0iTTQ5LjkxLDYuMDRjLTAuOTgsMC0xLjkzLDAuNC0yLjYsMS4xMlY2LjQ1YzAtMC4xMi0wLjEtMC4yMi0wLjIyLTAuMjJoLTEuMzNjLTAuMTIsMC0wLjIyLDAuMS0wLjIyLDAuMjJ2MTAuMjFjMCwwLjEyLDAuMSwwLjIyLDAuMjIsMC4yMmgxLjMzYzAuMTIsMCwwLjIyLTAuMSwwLjIyLTAuMjJ2LTMuNzhjMC42OCwwLjcxLDEuNjIsMS4xMiwyLjYxLDEuMTJjMi4wNywwLDMuNzUtMS43OCwzLjc1LTMuOTlTNTEuOTgsNi4wNCw0OS45MSw2LjA0eiBNNDkuNiwxMi40MmMtMS4yNiwwLTIuMjgtMS4wNi0yLjMtMi4zNlY5Ljk5YzAuMDItMS4zMSwxLjA0LTIuMzcsMi4yOS0yLjM3YzEuMjYsMCwyLjMsMS4wNywyLjMsMi4zOVM1MC44NiwxMi40MSw0OS42LDEyLjQyTDQ5LjYsMTIuNDJ6Ii8+PHBhdGggY2xhc3M9InN0MSIgZD0iTTQ5LjYsNy42M2MtMS4yNiwwLTIuMjgsMS4wNi0yLjMsMi4zNnYwLjA2YzAuMDIsMS4zMSwxLjA0LDIuMzYsMi4zLDIuMzZzMi4zLTEuMDcsMi4zLTIuMzlTNTAuODYsNy42Myw0OS42LDcuNjN6IE00OS42LDExLjIzYy0wLjYsMC0xLjA5LTAuNTMtMS4xMS0xLjE5VjEwQzQ4LjUsOS4zNCw0OSw4LjgxLDQ5LjYsOC44MWMwLjYsMCwxLjExLDAuNTUsMS4xMSwxLjIxUzUwLjIxLDExLjIzLDQ5LjYsMTEuMjN6Ii8+PHBhdGggY2xhc3M9InN0MCIgZD0iTTM0LjM2LDEzLjU5YzAsMC4xMi0wLjEsMC4yMi0wLjIyLDAuMjJoLTEuMzRjLTAuMTIsMC0wLjIyLTAuMS0wLjIyLTAuMjJWOS4yNGMwLTAuOTMtMC43LTEuNjMtMS41NC0xLjYzYy0wLjc2LDAtMS4zOSwwLjY3LTEuNTEsMS41NGwwLjAxLDQuNDRjMCwwLjEyLTAuMSwwLjIyLTAuMjIsMC4yMmgtMS4zNGMtMC4xMiwwLTAuMjItMC4xLTAuMjItMC4yMlY5LjI0YzAtMC45My0wLjctMS42My0xLjU0LTEuNjNjLTAuODEsMC0xLjQ3LDAuNzUtMS41MiwxLjcxdjQuMjdjMCwwLjEyLTAuMSwwLjIyLTAuMjIsMC4yMmgtMS4zM2MtMC4xMiwwLTAuMjItMC4xLTAuMjItMC4yMlY2LjQ0YzAuMDEtMC4xMiwwLjEtMC4yMSwwLjIyLTAuMjFoMS4zM2MwLjEyLDAsMC4yMSwwLjEsMC4yMiwwLjIxdjAuNjNjMC40OC0wLjY1LDEuMjQtMS4wNCwyLjA2LTEuMDVoMC4wM2MxLjA0LDAsMS45OSwwLjU3LDIuNDgsMS40OGMwLjQzLTAuOSwxLjMzLTEuNDgsMi4zMi0xLjQ5YzEuNTQsMCwyLjc5LDEuMTksMi43NiwyLjY1TDM0LjM2LDEzLjU5eiIvPjxwYXRoIGNsYXNzPSJzdDEiIGQ9Ik04MC4zMiwxMi45N2wtMC4wNy0wLjEyTDc4LjM4LDEwbDEuODUtMi44MWMwLjQyLTAuNjQsMC4yNS0xLjQ5LTAuMzktMS45MmMtMC4wMS0wLjAxLTAuMDItMC4wMS0wLjAzLTAuMDJjLTAuMjItMC4xNC0wLjQ4LTAuMjEtMC43NC0wLjIxaC0xLjUzYy0wLjUzLDAtMS4wMywwLjI4LTEuMywwLjc0bC0wLjMyLDAuNTNsLTAuMzItMC41M2MtMC4yOC0wLjQ2LTAuNzctMC43NC0xLjMxLTAuNzRoLTEuNTNjLTAuNTcsMC0xLjA4LDAuMzUtMS4yOSwwLjg4Yy0yLjA5LTEuNTgtNS4wMy0xLjQtNi45MSwwLjQzYy0wLjMzLDAuMzItMC42MiwwLjY5LTAuODUsMS4wOWMtMC44NS0xLjU1LTIuNDUtMi42LTQuMjgtMi42Yy0wLjQ4LDAtMC45NiwwLjA3LTEuNDEsMC4yMlYzLjM3YzAtMC43OC0wLjYzLTEuNDEtMS40LTEuNDFoLTEuMzNjLTAuNzcsMC0xLjQsMC42My0xLjQsMS40djMuNTdjLTAuOS0xLjMtMi4zOC0yLjA4LTMuOTctMi4wOWMtMC43LDAtMS4zOSwwLjE1LTIuMDIsMC40NWMtMC4yMy0wLjE2LTAuNTEtMC4yNS0wLjgtMC4yNWgtMS4zM2MtMC40MywwLTAuODMsMC4yLTEuMSwwLjUzYy0wLjAyLTAuMDMtMC4wNC0wLjA1LTAuMDctMC4wOGMtMC4yNy0wLjI5LTAuNjUtMC40NS0xLjA0LTAuNDVoLTEuMzJjLTAuMjksMC0wLjU3LDAuMDktMC44LDAuMjVDNDAuOCw1LDQwLjEyLDQuODUsMzkuNDIsNC44NWMtMS43NCwwLTMuMjcsMC45NS00LjE2LDIuMzhjLTAuMTktMC40NC0wLjQ2LTAuODUtMC43OS0xLjE5Yy0wLjc2LTAuNzctMS44LTEuMTktMi44OC0xLjE5aC0wLjAxYy0wLjg1LDAuMDEtMS42NywwLjMxLTIuMzQsMC44NGMtMC43LTAuNTQtMS41Ni0wLjg0LTIuNDUtMC44NGgtMC4wM2MtMC4yOCwwLTAuNTUsMC4wMy0wLjgyLDAuMWMtMC4yNywwLjA2LTAuNTMsMC4xNS0wLjc4LDAuMjdjLTAuMi0wLjExLTAuNDMtMC4xNy0wLjY3LTAuMTdoLTEuMzNjLTAuNzgsMC0xLjQsMC42My0xLjQsMS40djcuMTRjMCwwLjc4LDAuNjMsMS40LDEuNCwxLjRoMS4zM2MwLjc4LDAsMS40MS0wLjYzLDEuNDEtMS40MWMwLDAsMCwwLDAsMFY5LjM1YzAuMDMtMC4zNCwwLjIyLTAuNTYsMC4zNC0wLjU2YzAuMTcsMCwwLjM2LDAuMTcsMC4zNiwwLjQ1djQuMzVjMCwwLjc4LDAuNjMsMS40LDEuNCwxLjRoMS4zNGMwLjc4LDAsMS40LTAuNjMsMS40LTEuNGwtMC4wMS00LjM1YzAuMDYtMC4zLDAuMjQtMC40NSwwLjMzLTAuNDVjMC4xNywwLDAuMzYsMC4xNywwLjM2LDAuNDV2NC4zNWMwLDAuNzgsMC42MywxLjQsMS40LDEuNGgxLjM0YzAuNzgsMCwxLjQtMC42MywxLjQtMS40di0wLjM2YzAuOTEsMS4yMywyLjM0LDEuOTYsMy44NywxLjk2YzAuNywwLDEuMzktMC4xNSwyLjAyLTAuNDVjMC4yMywwLjE2LDAuNTEsMC4yNSwwLjgsMC4yNWgxLjMyYzAuMjksMCwwLjU3LTAuMDksMC44LTAuMjV2MS45MWMwLDAuNzgsMC42MywxLjQsMS40LDEuNGgxLjMzYzAuNzgsMCwxLjQtMC42MywxLjQtMS40di0xLjY5YzAuNDYsMC4xNCwwLjk0LDAuMjIsMS40MiwwLjIxYzEuNjIsMCwzLjA3LTAuODMsMy45Ny0yLjF2MC41YzAsMC43OCwwLjYzLDEuNCwxLjQsMS40aDEuMzNjMC4yOSwwLDAuNTctMC4wOSwwLjgtMC4yNWMwLjYzLDAuMywxLjMyLDAuNDUsMi4wMiwwLjQ1YzEuODMsMCwzLjQzLTEuMDUsNC4yOC0yLjZjMS40NywyLjUyLDQuNzEsMy4zNiw3LjIyLDEuODljMC4xNy0wLjEsMC4zNC0wLjIxLDAuNS0wLjM0YzAuMjEsMC41MiwwLjcyLDAuODcsMS4yOSwwLjg2aDEuNTNjMC41MywwLDEuMDMtMC4yOCwxLjMtMC43NGwwLjM1LTAuNThsMC4zNSwwLjU4YzAuMjgsMC40NiwwLjc3LDAuNzQsMS4zMSwwLjc0aDEuNTJjMC43NywwLDEuMzktMC42MywxLjM4LTEuMzlDODAuNDcsMTMuMzgsODAuNDIsMTMuMTcsODAuMzIsMTIuOTdMODAuMzIsMTIuOTd6IE0zNC4xNSwxMy44MWgtMS4zNGMtMC4xMiwwLTAuMjItMC4xLTAuMjItMC4yMlY5LjI0YzAtMC45My0wLjctMS42My0xLjU0LTEuNjNjLTAuNzYsMC0xLjM5LDAuNjctMS41MSwxLjU0bDAuMDEsNC40NGMwLDAuMTItMC4xLDAuMjItMC4yMiwwLjIyaC0xLjM0Yy0wLjEyLDAtMC4yMi0wLjEtMC4yMi0wLjIyVjkuMjRjMC0wLjkzLTAuNy0xLjYzLTEuNTQtMS42M2MtMC44MSwwLTEuNDcsMC43NS0xLjUyLDEuNzF2NC4yN2MwLDAuMTItMC4xLDAuMjItMC4yMiwwLjIyaC0xLjMzYy0wLjEyLDAtMC4yMi0wLjEtMC4yMi0wLjIyVjYuNDRjMC4wMS0wLjEyLDAuMS0wLjIxLDAuMjItMC4yMWgxLjMzYzAuMTIsMCwwLjIxLDAuMSwwLjIyLDAuMjF2MC42M2MwLjQ4LTAuNjUsMS4yNC0xLjA0LDIuMDYtMS4wNWgwLjAzYzEuMDQsMCwxLjk5LDAuNTcsMi40OCwxLjQ4YzAuNDMtMC45LDEuMzMtMS40OCwyLjMyLTEuNDljMS41NCwwLDIuNzksMS4xOSwyLjc2LDIuNjVsMC4wMSw0LjkxQzM0LjM3LDEzLjcsMzQuMjcsMTMuOCwzNC4xNSwxMy44MUMzNC4xNSwxMy44MSwzNC4xNSwxMy44MSwzNC4xNSwxMy44MXogTTQzLjc4LDEzLjU5YzAsMC4xMi0wLjEsMC4yMi0wLjIyLDAuMjJoLTEuMzNjLTAuMTIsMC0wLjIyLTAuMS0wLjIyLTAuMjJ2LTAuNzFDNDEuMzQsMTMuNiw0MC40LDE0LDM5LjQyLDE0Yy0yLjA3LDAtMy43NS0xLjc4LTMuNzUtMy45OXMxLjY5LTMuOTksMy43NS0zLjk5YzAuOTgsMCwxLjkyLDAuNDEsMi42LDEuMTJ2LTAuN2MwLTAuMTIsMC4xLTAuMjIsMC4yMi0wLjIyaDEuMzNjMC4xMS0wLjAxLDAuMjEsMC4wOCwwLjIyLDAuMmMwLDAuMDEsMCwwLjAxLDAsMC4wMlYxMy41OXogTTQ5LjkxLDE0Yy0wLjk4LDAtMS45Mi0wLjQxLTIuNi0xLjEydjMuNzhjMCwwLjEyLTAuMSwwLjIyLTAuMjIsMC4yMmgtMS4zM2MtMC4xMiwwLTAuMjItMC4xLTAuMjItMC4yMlY2LjQ1YzAtMC4xMiwwLjEtMC4yMSwwLjIyLTAuMjFoMS4zM2MwLjEyLDAsMC4yMiwwLjEsMC4yMiwwLjIydjAuN2MwLjY4LTAuNzIsMS42Mi0xLjEyLDIuNi0xLjEyYzIuMDcsMCwzLjc1LDEuNzcsMy43NSwzLjk4UzUxLjk4LDE0LDQ5LjkxLDE0eiBNNjMuMDksMTAuODdDNjIuNzIsMTIuNjUsNjEuMjIsMTQsNTkuNDMsMTRjLTAuOTgsMC0xLjkyLTAuNDEtMi42LTEuMTJ2MC43YzAsMC4xMi0wLjEsMC4yMi0wLjIyLDAuMjJoLTEuMzNjLTAuMTIsMC0wLjIyLTAuMS0wLjIyLTAuMjJWMy4zN2MwLTAuMTIsMC4xLTAuMjIsMC4yMi0wLjIyaDEuMzNjMC4xMiwwLDAuMjIsMC4xLDAuMjIsMC4yMnYzLjc4YzAuNjgtMC43MSwxLjYyLTEuMTIsMi42LTEuMTFjMS43OSwwLDMuMjksMS4zMywzLjY2LDMuMTJDNjMuMjEsOS43Myw2My4yMSwxMC4zMSw2My4wOSwxMC44N0w2My4wOSwxMC44N0w2My4wOSwxMC44N3ogTTY4LjI2LDE0LjAxYy0xLjksMC4wMS0zLjU1LTEuMjktMy45Ny0zLjE0Yy0wLjEyLTAuNTYtMC4xMi0xLjEzLDAtMS42OWMwLjQyLTEuODUsMi4wNy0zLjE1LDMuOTctMy4xNGMyLjI1LDAsNC4wNiwxLjc4LDQuMDYsMy45OVM3MC41LDE0LjAxLDY4LjI2LDE0LjAxTDY4LjI2LDE0LjAxeiBNNzkuMDksMTMuODFoLTEuNTNjLTAuMTIsMC0wLjIzLTAuMDYtMC4yOS0wLjE2bC0xLjM3LTIuMjhsLTEuMzcsMi4yOGMtMC4wNiwwLjEtMC4xNywwLjE2LTAuMjksMC4xNmgtMS41M2MtMC4wNCwwLTAuMDgtMC4wMS0wLjExLTAuMDNjLTAuMDktMC4wNi0wLjEyLTAuMTgtMC4wNi0wLjI3YzAsMCwwLDAsMCwwbDIuMzEtMy41bC0yLjI4LTMuNDdjLTAuMDItMC4wMy0wLjAzLTAuMDctMC4wMy0wLjExYzAtMC4xMSwwLjA5LTAuMiwwLjItMC4yaDEuNTNjMC4xMiwwLDAuMjMsMC4wNiwwLjI5LDAuMTZsMS4zNCwyLjI1bDEuMzQtMi4yNWMwLjA2LTAuMSwwLjE3LTAuMTYsMC4yOS0wLjE2aDEuNTNjMC4wNCwwLDAuMDgsMC4wMSwwLjExLDAuMDNjMC4wOSwwLjA2LDAuMTIsMC4xOCwwLjA2LDAuMjdjMCwwLDAsMCwwLDBMNzYuOTYsMTBsMi4zMSwzLjVjMC4wMiwwLjAzLDAuMDMsMC4wNywwLjAzLDAuMTFDNzkuMjksMTMuNzIsNzkuMiwxMy44MSw3OS4wOSwxMy44MUM3OS4wOSwxMy44MSw3OS4wOSwxMy44MSw3OS4wOSwxMy44MUw3OS4wOSwxMy44MXoiLz48cGF0aCBjbGFzcz0ic3QwIiBkPSJNMTAsMS4yMWMtNC44NywwLTguODEsMy45NS04LjgxLDguODFzMy45NSw4LjgxLDguODEsOC44MXM4LjgxLTMuOTUsOC44MS04LjgxQzE4LjgxLDUuMTUsMTQuODcsMS4yMSwxMCwxLjIxeiBNMTQuMTgsMTIuMTljLTEuODQsMS44NC00LjU1LDIuMi02LjM4LDIuMmMtMC42NywwLTEuMzQtMC4wNS0yLTAuMTVjMCwwLTAuOTctNS4zNywyLjA0LTguMzljMC43OS0wLjc5LDEuODYtMS4yMiwyLjk4LTEuMjJjMS4yMSwwLDIuMzcsMC40OSwzLjIzLDEuMzVDMTUuOCw3LjczLDE1Ljg1LDEwLjUsMTQuMTgsMTIuMTl6Ii8+PHBhdGggY2xhc3M9InN0MSIgZD0iTTEwLDAuMDJjLTUuNTIsMC0xMCw0LjQ4LTEwLDEwczQuNDgsMTAsMTAsMTBzMTAtNC40OCwxMC0xMEMxOS45OSw0LjUsMTUuNTIsMC4wMiwxMCwwLjAyeiBNMTAsMTguODNjLTQuODcsMC04LjgxLTMuOTUtOC44MS04LjgxUzUuMTMsMS4yLDEwLDEuMnM4LjgxLDMuOTUsOC44MSw4LjgxQzE4LjgxLDE0Ljg5LDE0Ljg3LDE4LjgzLDEwLDE4LjgzeiIvPjxwYXRoIGNsYXNzPSJzdDEiIGQ9Ik0xNC4wNCw1Ljk4Yy0xLjc1LTEuNzUtNC41My0xLjgxLTYuMi0wLjE0QzQuODMsOC44Niw1LjgsMTQuMjMsNS44LDE0LjIzczUuMzcsMC45Nyw4LjM5LTIuMDRDMTUuODUsMTAuNSwxNS44LDcuNzMsMTQuMDQsNS45OHogTTExLjg4LDkuODdsLTAuODcsMS43OGwtMC44Ni0xLjc4TDguMzgsOS4wMWwxLjc3LTAuODZsMC44Ni0xLjc4bDAuODcsMS43OGwxLjc3LDAuODZMMTEuODgsOS44N3oiLz48cG9seWdvbiBjbGFzcz0ic3QwIiBwb2ludHM9IjEzLjY1LDkuMDEgMTEuODgsOS44NyAxMS4wMSwxMS42NSAxMC4xNSw5Ljg3IDguMzgsOS4wMSAxMC4xNSw4LjE1IDExLjAxLDYuMzcgMTEuODgsOC4xNSAiLz48L2c+PC9zdmc+);width: 65px;height: 20px;display: inline-block;background-size: contain;background-repeat: no-repeat;background-position: center center;"></a>';
    return d;
  }
  l.addTo(_leaflets.maplayer);
  l._container.style.marginTop = "5px";
  l._container.style.marginRight = "5px";
}
//popup content of building
function getPopupContent(layer)
{
  if (layer instanceof L.Polygon)
  {
    var area;
    try
    {
      area = commaseparate(roundify(turf.area(layer.toGeoJSON(13)) * turf.areaFactors.feet, 1)) + " sq. ft.";
    }
    catch (e)
    {
      var latlngs = layer._defaultShape ? layer._defaultShape() : layer.getLatLngs();
      area = L.GeometryUtil.geodesicArea(latlngs);
      area = L.GeometryUtil.readableArea(commaseparate(roundify(area, 1)), false);
    }
    var edit = layer.editing.enabled() ? "<a href='javascript:void(0)' onclick='doneediting();'><span class='fas fa-check'></span> Done Editing</a>" : "<a href='javascript:void(0)' onclick='editbuilding();'>Edit building</a>";
    return "<b>Footprint:</b> " + area + "<p style='margin: 20px 0px 0px'>" + edit + "</p><p style='margin: 5px 0px 0px'><a href='javascript:void(0)' onclick='deletebuilding();'>Delete building</a></p>";
  }
  else if (layer instanceof L.Polyline)
  {
    var latlngs = layer._defaultShape ? layer._defaultShape() : layer.getLatLngs(),
        distance = 0;
    if (latlngs.length < 2)
    {
      return "<b>Distance:</b> N/A";
    }
    else
    {
      for (var i = 0; i < latlngs.length - 1; i++)
      {
        distance += latlngs[i].distanceTo(latlngs[i + 1]);
      }
      return "<b>Distance:</b> " + roundify(distance * 3.28084, 1) + " ft" + "<p style='margin: 5px 0px 0px'><a href='javascript:void(0)' onclick='deletemeasurement();'>Delete measurement</a></p>";
    }
  }
  return null;
}
//close popup
function closepopup()
{
  _leaflets.maplayer.closePopup();
}
