function _afterbegin()
{
  removePrintElement();
  checkIE(); 
  initloc(); 
  populatesheet(); 
  focusonsearch();
}

/*backyardarea*/
builtins.push('backyardarea');
_backyardarea = null;
function backyardarea()
{
  var backyardareapoly = backyardareapolygon();
  return backyardareapoly? turf.area(backyardareapoly) * turf.areaFactors.feet + "": false;
}
function recomputebackyardarea()
{
  _backyardarea = null;
  _backyardarea = backyardareapolygon();
  populatesheet();
}

function hasbackyardcoverexceeded()
{
  try
  {
    var area = backyardareapolygon(),
        backyardareapoly = JSON.parse(JSON.stringify(area)),
        structures = getallstructures();
    for (var i = 0; i < structures.length; i++)
      area = turf.difference(area,structures[i]);
    return roundify((1 - turf.area(area) / turf.area(backyardareapoly)) * 100,0) > 40;
  }
  catch(e)
  {
    return false;
  }
}

function issideyardlarger()
{
  try
  {
    var adu = getadu(),
        side = _lotlines[_apn].side;
    return roundify(side.map(i=>polygontolinedistance(adu,i)).reduce((m,i)=>Math.min(i,m)),1) >= 4;
  }
  catch(e)
  {
    return false;
  }
}

function remainingarea()
{
  try
  {
    var area = backyardareapolygon(),
        structures = getallstructures();
    for (var i = 0; i < structures.length; i++)
      area = turf.difference(area,structures[i]);
    return area;
  }
  catch(e)
  {
    return false;
  }
}
function backyardareapolygon()
{
  if (!_geometry)
    return false;
  if (_backyardarea != null)
    return _backyardarea;
  try
  {
    var lines = getlotlines(getprimary()),
        lotlines = _lotlines[_apn];
    lines = [...lines[0],...lines[1]].sort(
      function(a,b)
      {
        var d1 = mean(turf.explode(a).features.map(i=>reardistance(i))),
            d2 = mean(turf.explode(b).features.map(i=>reardistance(i)));
        return d1 - d2;
      }
    );

    var sides = [...lotlines.side,...lotlines.streetside];

    var pts = turf.explode(lines[0]).features,
        p11 = turf.nearestPointOnLine(sides[0],pts[0]),
        p12 = turf.nearestPointOnLine(sides[1],pts[0]),
        p21 = turf.nearestPointOnLine(sides[0],pts[pts.length-1]),
        p22 = turf.nearestPointOnLine(sides[1],pts[pts.length-1]),
        p1,p2;

    if (p11.properties.dist < p12.properties.dist)
    {
      p1 = p11;
      p2 = p22;
    }
    else
    {
      p1 = p12;
      p2 = p21;
    }
    p1 = turf.rhumbDestination(pts[0],turf.rhumbDistance(pts[0],p1) * 10,turf.rhumbBearing(pts[0],p1));
    p2 = turf.rhumbDestination(pts[pts.length-1],turf.rhumbDistance(pts[pts.length-1],p2) * 10,turf.rhumbBearing(pts[pts.length-1],p2));
    pts = [p1].concat(pts).concat([p2]);

    var bpts1 = pts.concat(turf.explode(lotlines.rear).features).concat([p1]),
        bpts2 = pts.concat(turf.explode(lotlines.rear).features.reverse()).concat([p1]),
        polygon1 = turf.polygon([bpts1.map(i=>turf.coordAll(i)[0])]),
        polygon2 = turf.polygon([bpts2.map(i=>turf.coordAll(i)[0])]);

    _backyardarea = intersect(turf.kinks(polygon1).features.length? polygon2: polygon1,_geometry);
  }
  catch(e)
  {
    _backyardarea = false;
  }
  return _backyardarea;
}
function reardistance(a)
{
  return turf.pointToLineDistance(a,_lotlines[_apn].rear);
}

function secondstory()
{
  if (_lotlines[_apn])
  {
    var s = ["rear","side","streetside"], requiredyards = [];
    for (var i = 0; i < s.length; i++)
    {
      var lotline = _lotlines[_apn][s[i]];
      if (lotline)
      {
        if (Array.isArray(lotline))
        {
          for (var j = 0; j < lotline.length; j++)
          {
            requiredyards.push(turfAM.buffer(lotline[j],4,{units:'feet'}));
          }
        }
        else requiredyards.push(turfAM.buffer(lotline,4,{units:'feet'}));
      }
    }
    var parcel = standardizefeature(_geometry);
    for (var i = 0; i < requiredyards.length; i++)
    {
      parcel = turf.difference(parcel,requiredyards[i]);
    }
    return parcel;
  }
}

function inforeport(result)
{
  result = result[0];
  _apn = result[0];
  _geometry = standardizefeature(JSON.parse(result[3]));
  
  //Simplify larger parcels (Optional) before getting info
  var geom = turf.area(_geometry) * turf.areaFactors.feet > 50000? cleanupgon(turf.simplify(turf.feature(_geometry),{highQuality: true, tolerance: 0.0000001}),1).geometry: _geometry;
  
  var report = parcelinfo(geom) || {};
  report.footprint = report.footprint.map(i => JSON.parse(i));
  report.transitstops = report.transitstops.map(i => [i[0],i[1],JSON.parse(i[2])]);
  report.zone = report.zone.map(i => [i[0],JSON.parse(i[1])]);
  report.generalplan = report.generalplan.map(i => [i[0],JSON.parse(i[1])]);

  /*Use the following if Assessor's data about parcel or city's data about parcel does not reflect lot area.*/
  report['lotarea'] = roundify(turf.area(_geometry) * turf.areaFactors['feet'],1);

  report['apn'] = result[0];
  report['address'] = result[1] && result[1].length? result[1] + ", CA - " + result[2]: "";

  setinfo(report);
  return report;
}

function parcelinfo(geom)
{
  var url = _path + "info.php";
  var params = {
    "apn": _apn,
    "geom": JSON.stringify(geom),
    "zonebuffer": JSON.stringify(turfAM.buffer(geom,-16,{units:'inches'})),
    "halfmilebuffer": JSON.stringify(turfAM.buffer(geom,0.5,{units:'miles'}))
  };
  return JSON.parse(postvalues(url,params));
}

function setinfo(report)
{
  if (_infoset) return;

  var baseaddress = report.address.split(', CA')[0];
  if (baseaddress.length)
    _cache[baseaddress] = {apn: _apn, geom: _geometry, report: report};
  _cache[report.apn] = {apn: _apn, geom: _geometry, report: report};

  //var report = _cache[_apn].report;

  var address = quotify(report.address.replace(/"/g,"'"));
  insertfact(['address',address],lambda);

  var apn = quotify(report.apn);
  insertfact(['apn',apn],lambda);

  var lotarea = report.lotarea + "";
  insertfact(['lotarea',lotarea],lambda);

  var zone = vniquify(JSON.parse(JSON.stringify(report.zone)).map(i=>i[0])); //create layer*
  for (var i = 0; i < zone.length; i++)
  {
    insertfact(['zone',quotify(stripquotes(zone[i]))],lambda);
  }
  
  var transitstops = report.transitstops;

  if (transitstops.length) //create layer*
  {
  	insertfact('publictransit',lambda);
  }

  var historic = report.historic;
  if (historic.ishistoric)
  {
    insertfact("historic",lambda);
    if (historic.cr)
      insertfact("ca_register_of_historic_places",lambda);
    if (historic.cld)
      insertfact("landmarkdistrict",lambda);
    if (historic.cls)
      insertfact("landmarksite",lambda);
  }

  if (report.floodzone)
    insertfact("floodzone",lambda);

  var geohazard = report.geohazard;
  if (geohazard.length)
  {
    for (var i = 0; i < geohazard.length; i++)
    insertfact(["geohazard",quotify(stripquotes(geohazard[i]))],lambda);
  }

  var generalplan = report.generalplan;
  if (generalplan.length)
  {
    for (var i = 0; i < generalplan.length; i++)
    insertfact(["generalplan",quotify(stripquotes(generalplan[i][0]))],lambda);
  }

  //Determine lot lines...
  lotlines();
  if (!_lotlines[_apn])
  {
  	insertfact("couldntcomputelotlines",lambda);
  }

  //Compute lot dimensions using bounding box;
  var bbox = getBBoxAM(_geometry),
  		bboxlinelength = turf.lineSegment(getBBoxAM(_geometry)).features.map(i=>turf.length(i,{units:'feet'}));
  bboxlinelength.sort();
  var lotwidth = bboxlinelength[0], lotdepth = bboxlinelength[2];
  if (_lotlines[_apn])
  {
  	var frontpts = turf.explode(_lotlines[_apn].front).features,
  			frontlength = turf.distance(frontpts[0],frontpts[frontpts.length-1],{units:'feet'});
  	if (Math.abs(frontlength - lotdepth) < Math.abs(frontlength - lotwidth))
  	{
  		lotwidth = lotwidth + lotdepth;
  		lotdepth = lotwidth - lotdepth;
  		lotwidth = lotwidth - lotdepth;
  	}
  }
  //lotdepth = report.lotarea / lotwidth; //uncomment this code to have lot depth be determined by lot area instead of bbox.
  lotwidth = roundify(lotwidth,1) + "";
	lotdepth = roundify(lotdepth,1) + "";
  insertfact(['lotdepth',lotdepth],lambda);  
  insertfact(['lotwidth',lotwidth],lambda);  

  addBuildings();
  var areaestimates = getAreaEstimates().map(i=>roundify(i,1));
  insertfact(['existingfootprint',areaestimates[0]+""],lambda);
  insertfact(['primaryarea',areaestimates[1] + ""],lambda);
  insertfact(['otherarea',(areaestimates[0] - areaestimates[1]) + ""],lambda);
  _infoset = true;
  return;
}

function loadleaflet(id)
{
  var url = _datapath + "boundary.geojson";
  var request = new XMLHttpRequest();
  request.open("GET", url, false);
  request.send();
  var boundary = JSON.parse(request.responseText);

  var satellite = new L.Control.satellite();
  satellite.addTo(_leaflets.maplayer)

  _leaflayers['boundary'] = L.geoJson(boundary,
    {
      style:
      {
        color: 'grey',
        fillOpacity: 0.1,
        weight: 1
      }
    }
  ).addTo(_leaflets['maplayer']);

  boundaryaddclick();
  addzoomMessage();

  _leaflets[id].invalidateSize();
  _leaflets[id].fitBounds(_leaflayers['boundary'].getBounds());
  _topolayer.addTo(_leaflets[id]);
}

//UI reset function for new search
//UI reset function
function clearall(resetzoom)
{
  closeallcollapsibles();
  resetzoom = typeof resetzoom == "undefined"? true: resetzoom;
  var bounds = _leaflayers.parcel.getBounds().pad(0.25);
  _backyardarea = null;
  react(['deselect','layer','adu']);
  react(['deselect','layer','carsharetransit']);
  react(['deselect','layer','draw']);
  react(['deselect','layer','measurement']);
  react(['deselect','layer','setback']);

  disablerotate();
  _leaflayers.draw.clearLayers();
 
  _leafcontrols.zoomMessage.addTo(_leaflets.maplayer);
  checkzoomtext();

  var getstarted = document.getElementById("collapse(getstarted)");
  if (getstarted)
  	getstarted.style.height = "initial";
  
  _geometry = null, _apn = null, _infoset = false;

  if (_leaflets.maplayer.hasLayer(_leaflayers.zone)) _leaflayers.zone.removeFrom(_leaflets.maplayer);
  if (_leaflets.maplayer.hasLayer(_leaflayers.carsharetransit)) _leaflayers.carsharetransit.removeFrom(_leaflets.maplayer);
  _leaflayers['zone'] = null;
  _leaflayers['carsharetransit'] = null;
 
 	_lotlines = {};
  if (resetzoom)
  {
    setTimeout(
      function()
      { 
        _leaflets['maplayer'].invalidateSize();
        _leaflets['maplayer'].fitBounds(_leaflayers['boundary'].getBounds());
        closeAllLists();
      }, 
      200
    );
  }
  else
  {
    closeAllLists();
    setTimeout(
      function()
      {
        _leaflets.maplayer.invalidateSize();
        _leaflets['maplayer'].fitBounds(bounds.pad(4));
      },
      200
    );
  }
}

/*printing*/

var printelement = null;

//prepare report to be printed
function preparetoprint()
{
  document.querySelector(".loadingscreen").style['background-color'] = 'rgba(0,0,0,1)';
  document.querySelector(".loadingscreen").style['display'] = '';

  var e = document.querySelector("#maplayer");
  var h = 480,
      aspectratio = 16/9;
      w = h * aspectratio;
  e.style.width = w + 'px';
  e.style.height = h + 'px';

  var bounds = _leaflayers.parcel.getBounds();
  if (_leaflets.maplayer.hasLayer(_leaflayers.setback))
    bounds.extend(_leaflayers.setback.getBounds());
  if (_leaflets.maplayer.hasLayer(_leaflayers.draw))
    bounds.extend(_leaflayers.draw.getBounds());

  _leaflets.maplayer.invalidateSize();
  _leaflets.maplayer.fitBounds(bounds.pad(0.1));

  document.querySelector(".leaflet-control-container").style.display = "none";

  setTimeout(function(){domtoimage.toPng(document.querySelector('#map'), {width: w, height: 480}).then(
    function (dataUrl) 
    {
      addBackPrintElement(true);
      printfromtemplate();
      var img = document.querySelector("#printimg");
      img.src = "";
      img.onload = function()
      {
        document.querySelector("#printoverlay").style.display = "";
        document.body.style.overflow = "hidden";
        restoremap(e,bounds);
      }
      img.src = dataUrl;
    }
  );},400);
}

function printreport()
{
  document.querySelector(".loadingscreen").style['background-color'] = 'rgba(0,0,0,1)';
  document.querySelector(".loadingscreen").style['display'] = '';
  removePrintElement();
  document.querySelector("#printoverlay").style.display = "none";
  addBackPrintElement();
  document.querySelector(".noprint").setAttribute("onclick","resetprint()");
  window.print();
  restoremap(false,false);
  printelement.style.display = "none";
  document.body.style.overflow = "";
}

function closeprint()
{
  removePrintElement();
  document.querySelector("#printoverlay").style.display = "none";
  document.body.style.overflow = "";
}

function removePrintElement()
{
  printelement = document.querySelector(".print");
  if (printelement)
    printelement.parentNode.removeChild(printelement);
}

function addBackPrintElement(flag)
{
  printelement.style.display = "";
  flag = typeof flag == "undefined"? false: flag;
  var parent = document.querySelector(flag? "#inserthere": "#pagebody");
  if (flag)
  {
    parent.innerHTML = "";
    parent.appendChild(printelement);
  }
  else parent.appendChild(printelement);
  populatesheet();
}

function resetprint()
{ 
  removePrintElement(); 
  document.querySelector(".noprint").removeAttribute('onclick');
}

function restoremap(e,bounds)
{
  setTimeout(
    function()
    {
      if (e && bounds)
      {
        e.style.width = '100%';
        e.style.height = '100%';
        _leaflets.maplayer.invalidateSize();
        _leaflets.maplayer.fitBounds(bounds);
        document.querySelector(".leaflet-control-container").style.display = "";
      }
      document.querySelector(".loadingscreen").style['background-color'] = 'rgba(0,0,0,0.6)';
      document.querySelector(".loadingscreen").style['display'] = 'none';
    }, 
    400
  );
}

/*Pull out collapsible content*/
/**Print from Template - to handle the flex notes**/
function printfromtemplate()
{
  document.querySelector(".currentdate").innerHTML = (new Date()).toLocaleDateString();
  var collapsibles = ['number','area','setback','parking'];
  for (var j = 0; j < collapsibles.length; j++)
  {
    var collapse = document.getElementById("print(collapse("+collapsibles[j]+"))");
    var li = document.getElementById("collapse("+collapsibles[j]+")").querySelectorAll(".flexnotecontent li");
    var ul = document.createElement("ul");
    ul.setAttribute("class","iconlist");
    for (var i = 0; i < li.length; i++)
    {
      ul.innerHTML += li[i].outerHTML;
    }
    var a = ul.querySelectorAll("a[id^='help']");
    for (var i = a.length - 1; i >= 0; i--)
    {
      var clickhere = a[i].innerHTML.indexOf("Click here") != -1;
      if (clickhere)
      {
        a[i].parentNode.removeChild(a[i]);
      }
      else
      {
        var span = document.createElement("span");
        span.innerHTML = a[i].innerHTML;
        a[i].parentNode.replaceChild(span,a[i]);
      }
    }
    var a = ul.querySelectorAll("[id],[onclick]");
    for (var i = 0; i < a.length; i++)
    {
      a[i].removeAttribute("id");
      a[i].removeAttribute("onclick");
    }
    collapse.innerHTML = ul.outerHTML;
  }
}