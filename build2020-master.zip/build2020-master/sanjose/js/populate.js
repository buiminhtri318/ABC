/*Leaflet Populator*/
populators['LEAFLET'] = function (widget)
{
  return populateleafletasync(widget);
}
//populate function for LEAFLET widget
function populateleafletasync(widget)
{
  populateattributes(widget);
  populatestyles(widget);
  var id = widget.getAttribute("id");

  if (_leaflets[id] == null)
  {
    _leaflets[id] = L.map(id,
      {
        zoomSnap: 0,
        zoomDelta: 0.8,
        attributionControl: true,
        scrollWheelZoom: true,
        fullscreenControl: {
          pseudoFullscreen: true
        }
      }
    );
    loadleaflet(id);
    addmapboxmark();
    addLegend(id);
    initializedrawing();

    _leaflets.maplayer.boxZoom.disable();
    var maplinks = document.querySelectorAll(".leaflet-bar a[title]");
    for (var i = 0; i < maplinks.length; i++)
    {
      var title = maplinks[i].getAttribute('title');
      maplinks[i].setAttribute('datatitle', title);
      maplinks[i].removeAttribute('title');
    }

    _leaflets[id].on('fullscreenchange',
      function()
      {
        if (!_leaflets[id].isFullscreen())
        {
          if (_leaflayers.parcel)
            fittoparcel();
        }
      }
    );
    return;
  }

  //Update styles based on background tile
  var tile = compfindx("satellite", ["tile", "satellite"], lambda, library);
  if (!tile)
  {
    _leaflets[id].removeLayer(_satellitelayer);
    _leaflayers['boundary'].setStyle(
      {
        fillColor: 'grey',
        fillOpacity: 0.1
      }
    );
    if (_leaflayers['parcel'])
      _leaflayers['parcel'].setStyle(
        {
          fillColor: 'white',
          fillOpacity: 0
        }
      );
    if (_leaflayers['transitbuffer'])
      _leaflayers['transitbuffer'].setStyle(
        {
          fillOpacity: 0.1
        }
      );
    _topolayer.addTo(_leaflets[id]);
  }
  else
  {
    _leaflets[id].removeLayer(_topolayer);
    _leaflayers['boundary'].setStyle(
      {
        fillColor: 'white',
        fillOpacity: 0.1
      }
    );
    if (_leaflayers['parcel'])
      _leaflayers['parcel'].setStyle(
        {
          fillColor: 'white',
          fillOpacity: 0.5
        }
      );
    if (_leaflayers['transitbuffer'])
      _leaflayers['transitbuffer'].setStyle(
        {
          fillOpacity: 0.4
        }
      );
    _satellitelayer.addTo(_leaflets[id]);
  }

  var resultpage = compfindx('resultpage', 'resultpage', lambda, library);
  var locationsearched = compfindx('locationtextsearch', 'locationtextsearch', lambda, library);
  
  if (resultpage && _leafcontrols.zoomMessage._map)
  {
    _leaflets.maplayer.removeControl(_leafcontrols.zoomMessage);
  }

  if (locationsearched && resultpage)
  {
    if (_leaflayers.parcel && _leaflets.maplayer.hasLayer(_leaflayers.parcel))
    {
      _leaflets.maplayer.setZoom(_leaflets.maplayer._zoom + 0.05);
      fittoparcel();
    }
  }
  if (locationsearched || resultpage)
  {
    boundaryunbindclick();
  }
  else if (!resultpage)
  {
    _geometry = null;
    if (_leaflayers['parcel'] && _leaflayers['parcel'] != null)
      _leaflets['maplayer'].removeLayer(_leaflayers['parcel']);
    boundaryaddclick();
  }

  var transitlayer = compfindx("carsharetransit", ["layer", "carsharetransit"], lambda, library);
  toggletransit(transitlayer);

  if (_leaflayers.parcel && _leaflets.maplayer.hasLayer(_leaflayers.parcel))
    _leaflayers.parcel.bringToFront();

  var adulayer = compfindx("adu", ["layer", "adu"], lambda, library);
  toggleadulayer(adulayer);

  visualizebacks();
  if (_leaflets[id].hasLayer(_leaflayers['draw']))
  {
    _leaflayers['draw'].bringToFront();
  }

  return;
}
/*Visualize Setbacks*/

function visualizebacks()
{
  var resultpage = compfindx("resultpage","resultpage",lambda,library),
      interiorconversion = compfindx("interioradus","interioradus",lambda,library)
  
  if (_leaflets['maplayer'].hasLayer(_leaflayers['setback']))
      _leaflets['maplayer'].removeLayer(_leaflayers['setback']);

  if (!_apn || !resultpage || interiorconversion || !_lotlines[_apn])
  {
    checklayers();
    return;
  }

  try
  {
    var buildablearea = computebuildablearea();

    var detached = compfindx('detachedadu','detachedadu',lambda,library);
    if (detached)
    {
      try
      {
        buildablearea = turf.union(buildablearea,computebuildablerearyard());
      }
      catch(e)
      {

      }
    }
    var q = read('adusetback(X,Y) & setbacktypestyle(X,Z)'),
        setbackpopup = compfinds(["Z","Y"],q,lambda,library).map(i=>stripquotes(i[0]) + roundify(i[1],1) + " ft.").join("<br>");

    _leaflayers['setback'] = L.geoJson(buildablearea, {style: {color: 'black', fillColor: '#26C281', opacity: 1, fillOpacity: 0.8, weight: 0, dashArray: [3,3]}});
    _leaflayers['setback'].bindPopup(setbackpopup);

    if (compfindx("setback",["layer","setback"],lambda,library))
      _leaflayers['setback'].addTo(_leaflets['maplayer']);
    else if (_leaflets['maplayer'].hasLayer(_leaflayers['setback']))
      _leaflets['maplayer'].removeLayer(_leaflayers['setback']);
  } 
  catch(e)
  {
    if (!compfindx('cannotvisualizesetbacks','cannotvisualizesetbacks',lambda,library))
      insertfact('cannotvisualizesetbacks',lambda);
  }
  checklayers();
}


/*General Additions / Fixes to Worksheets v1.*/
function modnumber(widget)
{
  var item = read(widget.id);
  var value = widget.value.toLowerCase().replace(/,/g,'');
  
  if (isNaN(numberize(value)))
  {
    populatesheet();
    return true;
  }

  value = read(value);
  var action = seq('select',item,value);
  react(action);
  if (autostorage)
    modvalue(item,value);
  populatesheet();
  if (broadcast) 
    autosavedata(folder);
  return true;
}

function populate(widget)
{
  if (widget.hasAttribute('number')) return populatenumber(widget);
  if (widget.type==='text' && !widget.hasAttribute('autoquote')) return populatetext(widget);
  if (widget.type==='text' && widget.hasAttribute('autoquote')) return populatestring(widget);
  if (widget.type==='textarea') return populatetextarea(widget);
  if (widget.type==='range') return populaterange(widget);
  if (widget.type==='select-one') return populateselector(widget);
  if (widget.type==='select-multiple') return populatemenu(widget);
  var handler = populators[widget.tagName];
  if (handler) return handler.call(null,widget);
  populateattributes(widget);
  populatestyles(widget);
  return false;
}

function populaterange(widget)
{
  var id = read(widget.id);
  var value = findvalue(id);
  value = !value? '': grind(value);
  populateattributes(widget);
  populatestyles(widget);
  widget.value = value;
  return true;
}

function populatenumber(widget)
{
  var id = read(widget.id);
  var value = findvalue(id);
  if (!value) {value = ''} else {value = grind(value)};
  if (document.activeElement!==widget && value) 
    widget.value = numberize(value).toLocaleString('en-US',{useGrouping:true});
  populateattributes(widget);
  populatestyles(widget);
  return true;
}

var _updatehandlers = ['updatecontents','updatetables'];
_updatehandlers.splice(0,0,'updateflexnotes');
function populatesheet()
{
  for (var i = 0; i < _updatehandlers.length; i++)
  {
    window[_updatehandlers[i]]();
  }
  var widgets = document.querySelectorAll('[id]');
  for (var i=0; i<widgets.length; i++) populate(widgets[i]);
  var widgets = document.querySelectorAll('[name]');
  var names = [];
  for (var i=0; i<widgets.length; i++)
  {
    var name = widgets[i].getAttribute('name');
    if (!findq(name,names)) 
    {
      names.push(name); 
      populatespread(widgets[i]);
    }
  }
  reposition();
  return true;
}

/*Flex Notes*/
function updateflexnotes()
{
  var flexnotes = document.querySelectorAll('flexnote[id]');
  for (var i = 0; i < flexnotes.length; i++)
  {
    var widget = flexnotes[i];
    updateflexnote(widget);
  }
  return true;
}

function updateflexnote(widget)
{
  var relation = widget.getAttribute("id");

  if (!relation)
  {
    widget.innerHTML = "";
    return;
  }

  var arity = getarity(relation,library);
  var pattern = makepattern(relation,arity);
  var data = compfinds(pattern,pattern,lambda,library);

  var headerstyle = widget.getAttribute("headerstyle");
  var contentstyle = widget.getAttribute("contentstyle");

  var inline = widget.getAttribute("inline");
  inline = inline && inline == "true";

  var headers = [], content = {};
  for (var i = 0; i < data.length; i++)
  {
    var h = data[i][1];
    var c = display(data[i][2],contentstyle);
    if (!(h in content))
    {
      content[h] = [];
      headers.push(h);
    }
    content[h].push(c);
  }
  if (!headers.length)
  {
    widget.innerHTML = "";
    return;
  }

  var showheader = !inline && (!widget.getAttribute("showheader") || widget.getAttribute("showheader") != "false");
  var title = widget.getAttribute("placeholder");
  title = title? display(quotify(title),headerstyle): "";

  var icontype = widget.getAttribute("icontype");
  var icon = null;
  icon = stripquotes(compfindx("X",[icontype,"X"],lambda,library));
  if (icon) icon += " ";
  
  var widgetcontent = "";

  var items = [];
  for (var i = 0; i < headers.length; i++)
  {
    var headerline = display(headers[i],headerstyle);
    var item = (inline? icon: "") + headerline;
    var sublist = content[headers[i]];
    if (sublist.length == 1 || !stripquotes(headers[i]).trim().length)
    {
      var contentlist = content[headers[i]];
      for (var j = 0; j < contentlist.length; j++)
      {
        var subitem = item + ' ' + display(contentlist[j],contentstyle);
        subitem = subitem.trim();
        items.push(subitem);
      }
    }
    else if (headerline.length)
    {
      item += '<ul>' + sublist.map(i => '<li>' + i + '</li>').join("") + '</ul>';
      items.push(item);
    }
  }

  if (showheader)
  {
    if (items.length == 1)
    {
      widgetcontent += '<div class="flexnoteheader flexnotecontent">' + (icon||"") + items[0] + '</div>';
    }
    else
    {
      widgetcontent += '<div class="flexnoteheader">' + (icon||"") + (title) + '</div>';
      widgetcontent += '<div class="flexnotecontent"><ul>' + items.map(i => '<li>' + i + '</li>').join("") + '</ul></div>';
    }
  }
  else
  {
    if (inline)
    {
      widgetcontent += '<div class="flexnotecontent"><ul>' + items.map(i => '<li>' + i + '</li>').join("") + '</ul></div>';
    }
    else if (items.length == 1)
    {
      widgetcontent += '<div class="flexnotecontent">' + items[0] + '</div>';
    }
    else
    {
      widgetcontent += '<div class="flexnotecontent"><ul>' + items.map(i => '<li>' + i + '</li>').join("") + '</ul></div>';
    }
  }
  widget.innerHTML = widgetcontent;
  var c = widget.parentNode;
  if (c && c.style.height && c.style.height != "0px")
  {
    c.style.height = "initial";
  }
}

/*Collapsibles - resizing*/
var oldresize = window.onresize;
window.onresize = function()
{
  oldresize();
  resizeallcollapsibles();
}
function collapsible(w)
{
  var id = w.getAttribute('collapsible'),
      c = document.getElementById(id);
  if (c)
  {
    if (c.style.height && c.style.height != '0px')
    {
      if (c.style.height == "initial")
      {
        c.style.height = c.scrollHeight + "px";
      }
      setTimeout(function(){c.style.height = "0px"},10);
    }
    else
    {
      c.style.height = c.scrollHeight + "px";
    }
  }
}
function resizeallcollapsibles()
{
  var w = document.querySelectorAll(".expand[collapsible]");
  for (var i = 0; i < w.length; i++)
  {
    var c = w[i].getAttribute('collapsible');
    c = document.getElementById(c);
    if (c && c.style.height && c.style.height != "0px")
    {
      c.style.height = "initial";
      //c.style.height = c.scrollHeight + "px";
    }
  }
}
function closeallcollapsibles()
{
  var w = document.querySelectorAll(".expand[collapsible]");
  for (var i = 0; i < w.length; i++)
  {
    var c = w[i].getAttribute('collapsible');
    c = document.getElementById(c);

    if (c && c.style.height && c.style.height != "0px")
    {
      c.style.height = "0px";
      var e = c.querySelector("[id^='icon\(']");
      if (e)
      {
        e.setAttribute("class","fas fa-plus");
      }
    }
  }
}

function toggletransit(flag)
{
  if (!_apn || !compfindx("resultpage","resultpage",lambda,library))
  {
    if (_leaflets['maplayer'].hasLayer(_leaflayers['carsharetransit']))
      _leaflets['maplayer'].removeLayer(_leaflayers['carsharetransit']);
    return;
  }
  //initialize transit if not created
  if (!_leaflayers['carsharetransit'])
  {
    initializeTransit();
  }
  //toggle trasnit
  if (!flag && _leaflets['maplayer'].hasLayer(_leaflayers['carsharetransit']))
    _leaflets['maplayer'].removeLayer(_leaflayers['carsharetransit']);
  else if (flag && !_leaflets['maplayer'].hasLayer(_leaflayers['carsharetransit']))
    _leaflets['maplayer'].addLayer(_leaflayers['carsharetransit']);
}

function toggleadulayer(flag)
{
  if (!_apn || !compfindx("resultpage","resultpage",lambda,library))
  {
    if (_leaflets['maplayer'].hasLayer(_leaflayers['zone']))
      _leaflets['maplayer'].removeLayer(_leaflayers['zone']);
    return;
  }

  if (flag)
  {
    var q = 'permittedadu';
    var r = compfindx(q,q,lambda,library);
    if (_leaflayers['parcel'])
      _leaflayers['parcel'].setStyle({fillColor: r? '#26C281': '#F03434', fillOpacity: 0.45});
    if (r)
    {
      getZoningPolygons();
    }
    else
    {
      if (_leaflets['maplayer'].hasLayer(_leaflayers['zone']))
        _leaflets['maplayer'].removeLayer(_leaflayers['zone']);
    }
  }
  else
  {
    if (_leaflayers['parcel'])
    {
      if (compfindx("satellite",["tile","satellite"],lambda,library))
        _leaflayers['parcel'].setStyle({fillColor: 'white', fillOpacity: 0.5});
      else
        _leaflayers['parcel'].setStyle({fillColor: 'white', fillOpacity: 0});
    }
    if (_leaflets['maplayer'].hasLayer(_leaflayers['zone']))
      _leaflets['maplayer'].removeLayer(_leaflayers['zone']);
  }
}

function getZoningPolygons()
{
  if (_leaflayers['zone'])
  {
    if (!_leaflets['maplayer'].hasLayer(_leaflayers['zone']))
      _leaflayers['zone'].addTo(_leaflets['maplayer']);
    else 
      _leaflayers['zone'].bringToFront();     
    return;
  }

  var zone = _cache[_apn].report.zone,
      generalplan = _cache[_apn].report.generalplan.filter(i=>["Residential Neighborhood", "Transit Residential", "Urban Residential", "Mixed Use Commercial", "Mixed Use Residential", "Rural Residential", "Downtown"].indexOf(i[0]) != -1);

  var zd = turf.featureCollection(zone.map(i => {var x = {"type": "Feature", "geometry": i[1], "properties": {"description": i[0]}}; return x;}));
  _leaflayers['zone'] = L.geoJSON(zd,
    {
      style: function(feature)
      {
        var color = "transparent";
        var zone = quotify(feature.properties['description']);
        var query = ['allowedzone',zone];
        if (!compfindx(query,query,lambda,library))
        {
          if (!generalplan.filter(i=>!turf.booleanDisjoint(i[1],feature)).length)
          {
            color = '#F03434';
            savefact('somenotallowed',lambda);
          }
        }
        return {fillColor: color, fillOpacity: 0.45, weight: 1, color: '#444', dashArray: [3,3], stroke: true};
      }
    }
  ).bindPopup(
    function (layer) 
    {
      return layer.feature.properties.description;
    }
  ).addTo(_leaflets['maplayer']);
  _leaflayers['zone'].on("click",function(){if (_leaflets.maplayer._zoom < 19) _leaflets.maplayer.fitBounds(_leaflayers.parcel.getBounds());});
}