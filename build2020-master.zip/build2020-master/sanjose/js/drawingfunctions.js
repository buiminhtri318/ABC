//Toggle drawing functionality
function toggledraw()
{
  if (_leafcontrols.draw._map)
    _leaflets.maplayer.removeControl(_leafcontrols['draw']);
  else
    _leaflets.maplayer.addControl(_leafcontrols['draw']);
}
function activatesetbacks()
{
  if (compfindx("setback",["layer","setback"],lambda,library))
    return;
  fullreact(["select","layer","setback"]);
}

/*Drawing legend actions*/
function startdrawing(w)
{
  document.querySelector('.leaflet-draw-draw-polygon').click();
  w.querySelector("highlight").style.display = "block";
  document.querySelector('.drawcontrol').style.height = "18px";
}

function enddrawing()
{
  exitdrawmeasure();
  document.querySelector('.measurecontrol').style.height = "0px";
}

function startmeasure(w)
{
  document.querySelector('.leaflet-draw-draw-polyline').click();
  w.querySelector("highlight").style.display = "block";
  document.querySelector('.measurecontrol').style.height = "18px";
}

function endmeasure()
{
  exitdrawmeasure();
  document.querySelector('.measurecontrol').style.height = "0px";
}

function undodrawmeasure()
{
  if (_leafcontrols.draw._toolbars.draw._actionButtons.length)
    _leafcontrols.draw._toolbars.draw._actionButtons[0].button.click();
}

function exitdrawmeasure()
{
  if (_leafcontrols.draw._toolbars.draw._actionButtons.length > 1)
    _leafcontrols.draw._toolbars.draw._actionButtons[1].button.click();
}

function toggleaduMeasurements()
{
  if (!compfindx("measurement",["layer","measurement"],lambda,library))
    return;
  var adulayers = _leaflayers.draw.getLayers().filter(i => i.options.className.indexOf("adu") != -1);
  for (var i = 0; i < adulayers.length; i++)
    if (adulayers[i]._measurementLayer)
      adulayers[i].hideMeasurements();
    else
      adulayers[i].showMeasurements();
}
/*Rotation - Handling*/
function iseditenabled()
{
  var l = _leaflayers.draw._layers;
  var flag = false;

  for (var i in l)
  {
    if (l[i].editing && l[i].editing.enabled())
      return true;
  }

  return flag;
}
function enablerotate()
{
  var l = _leaflayers.draw._layers;
  for (var i in l)
  {
    if (l[i].transform)
    {
      if (l[i].transform.enabled())
      {
        l[i].transform.reset();
        l[i].transform.disable();
      }
      l[i].transform.enable({rotation: true, scaling: false});
    }
  } 
}
function disablerotate()
{
  var l = _leaflayers.draw._layers;
  for (var i in l)
  {
    if (l[i].transform)
    {
      l[i].transform.disable();
    }
  } 
}
function updaterotatehandlers()
{
  var l = _leaflayers.draw._layers;
  for (var i in l)
  {
    if (l[i].transform)
    {
      l[i].transform._rect.setLatLngs(L.geoJson(turf.bboxPolygon(turf.bbox(L.polygon(l[i].getLatLngs()).toGeoJSON(13)))).getLayers()[0].getLatLngs()); 
      l[i].transform._updateHandlers();
    }
  } 
}
function enablerotatehandler(layer)
{
  layer.on('rotate',
    function(d)
    {
      var angle = d.rotation; 
      if (this.editing.enabled()) 
      {
        this.editing.disable();
        this.stopmeasurement = true;
      }
      checklayers(angle);
    }
  );
  layer.on('rotateend',
    function(d)
    {
      this.editing.enable();
      delete this.stopmeasurement;
      checklayers();
    }
  );
}

function initializedrawing()
{
  var map = _leaflets.maplayer;
  _leaflayers['draw'] = L.featureGroup();
  _leafcontrols['draw'] = new L.Control.Draw(
    {
      draw:
      {
        polygon:
        {
          allowIntersection: false,
          precision: 1,
          metric: false,
          feet: true,
          nautic: false,
          guidelineDistance: 8,
          shapeOptions:
          {
            color: '#222',
            weight: 2,
            opacity: 1,
            fillColor: 'white',
            fillOpacity: 0.4,
          },
          repeatMode: false
        },
        polyline:
        {
          showLength: true,
          metric: false,
          feet: true,
          nautic: false,
          guidelineDistance: 8,
          shapeOptions:
          {
              color: '#222',
              weight: 2,
              opacity: 1,
              dashArray: '1,3'
          },
          repeatMode: false
        },
        marker: false,
        circle: false,
        circlemarker: false,
        rectangle: false
      },
    }
  );

  // Object created - bind popup to layer, add to feature group
  map.on("draw:drawstop",
  function(e)
  {
    exitdrawmeasure();
    document.querySelectorAll('highlight')[0].style.display = "none";
    document.querySelectorAll('highlight')[1].style.display = "none";
    document.querySelector('.measurecontrol').style.height = "0px";
    document.querySelector('.drawcontrol').style.height = "0px";
  }
  );

  map.on("draw:created",
    function(event)
    {
      var content = getPopupContent(event.layer);
      var layer;

      if (event.layer instanceof L.Polygon)
      {
        layer = L.polygon(event.layer.getLatLngs(), {
          transform: {
              rotation: true,
              scaling: false
          },
          editing: true,
          draggable: true
        });
        enablerotatehandler(layer);
        layer.setStyle(
          {
            opacity: 1,
            fillOpacity: 0.4,
            color: "#222",
            fillColor: "white",
            weight: 2,
            className: 'adu',
          }
        );
      }
      else
      {
        layer = L.polyline(event.layer.getLatLngs(),
          {
            draggable: true,
            opacity: 1,
            color: "#007bff",
            weight: 2,
            className: 'line-measure',
            dashArray: [2, 3]
          }
        );
      }
      if (content !== null)
        layer.bindPopup(content,
          {
            maxWidth: 220
          }
        );

      _leaflayers['draw'].addLayer(layer);
      modlayer(layer);
      layer.openPopup();

      layer.on('drag',
        function()
        {
          if (this.transform && this.transform.enabled())
          {
            this.transform._rect.setLatLngs(L.geoJson(turf.bboxPolygon(turf.bbox(L.polygon(this.getLatLngs()).toGeoJSON(13)))).getLayers()[0].getLatLngs());
            this.transform._updateHandlers();
          }
          this.editing.disable();
          disablerotate();
          modlayer(this);
        }
      );

      layer.on('dragend',
        function()
        {
          modlayer(this);
          if (!this.dragging.enabled())
            this.dragging.enable();
          if (layer.options.className && layer.options.className.indexOf('adu') != -1 && !layer.isPopupOpen())
            layer.openPopup();
        }
      );

      layer.on('click',
        function()
        {
          var content = this.getPopup()._content;
          if (layer.editing.enabled() && content.indexOf("Edit building") != -1)
            content = content.replace("<a href='javascript:void(0)' onclick='editbuilding();'>Edit building</a>", "<a href='javascript:void(0)' onclick='doneediting();'><span class='fas fa-check'></span> Done Editing</a>");
          else if (!layer.editing.enabled() && content.indexOf("Edit building") == -1)
            content = content.replace("<a href='javascript:void(0)' onclick='doneediting();'><span class='fas fa-check'></span> Done Editing</a>", "<a href='javascript:void(0)' onclick='editbuilding();'>Edit building</a>");
          this.bindPopup(content);
        }
      );
    }
  );

  // Object(s) edited - update popups
  map.on("draw:edited",
    function(event)
    {
      var layers = event.layers,
          content = null;
      layers.eachLayer(
        function(layer)
        {
          content = getPopupContent(layer);
          if (content !== null)
            layer.setPopupContent(content);
          if (!(layer.options.className && layer.options.className.indexOf('building') != -1))
          {
            modlayer(layer);
          }
        }
      );
    }
  );

  map.on("draw:editstop",
    function()
    {
      checklayers();
    }
  );
  map.on("draw:deletestop",
    function()
    {
      checklayers();
    }
  );

  map.on("draw:deleted",
    function()
    {
      checklayers();
    }
  );

  map.on("draw:editvertex",
    function(event)
    {
      var poly = event.poly;
      if (poly)
      {
        poly.transform._rect.setLatLngs(L.geoJson(turf.bboxPolygon(turf.bbox(L.polygon(poly.getLatLngs()).toGeoJSON(13)))).getLayers()[0].getLatLngs());
        poly.transform._updateHandlers();
      }
      else
        updaterotatehandlers();
      checklayers();
      recomputebackyardarea();
    }
  );

  map.on("draw:editstart",
    function(event)
    {
      updaterotatehandlers();
    }
  );

  map.on("draw:toolbarclosed",
    function(event)
    {
      disablerotate();
    }
  );

  _leaflets.maplayer.on('click',
    function(e)
    {
      if (!_leaflayers.draw || !_leaflets.maplayer.hasLayer(_leaflayers.draw))
        return;
      var line = closestLineSegment(e);
      if (line)
      {
        line[0].getPopup().setLatLng(line[1]).openOn(_leaflets.maplayer);
      }
    }
  );
}
function closestLineSegment(e)
{
  var l = e.latlng;
  var pt = turf.point([l.lng,l.lat]);
  var ptpix = _leaflets.maplayer.latLngToLayerPoint(l);
  var tolerance = 12; //in pixels
  var linesegments = _leaflayers.draw.getLayers().filter(i => i.options && i.options.className && i.options.className.indexOf('line-measure') != -1);
  var mind = tolerance * tolerance;
  var linelayer = null, latlng = [];
  for (var i = 0; i < linesegments.length; i++)
  {
    var line = linesegments[i].toGeoJSON();
    var pt1 = turf.nearestPointOnLine(line,pt);
    var pt1pix = _leaflets.maplayer.latLngToLayerPoint({lat: pt1.geometry.coordinates[1], lng: pt1.geometry.coordinates[0]});
    var d = Math.pow(pt1pix.x - ptpix.x,2) + Math.pow(pt1pix.y - ptpix.y,2);
    if (d < mind)
    {
      mind = d;
      linelayer = linesegments[i];
      latlng = {lat: pt1.geometry.coordinates[1], lng: pt1.geometry.coordinates[0]};
    }
  }
  return linelayer? [linelayer,latlng]: null;
}
/*Drawing,Editing,Measurements*/
function sketchadu()
{
  if (!_leaflets.maplayer.isFullscreen())
  {
    _leaflets.maplayer._enablePseudoFullscreen(_leaflets.maplayer._container);
    fittoparcel();
  }
  startdrawing(document.querySelector('#drawbuilding').parentNode);
}
function deletebuilding(layer)
{
  if (!layer && !_leaflets.maplayer._popup)
    return;
  layer = typeof layer == "undefined" ? _leaflets.maplayer._popup._source : layer;
  if (layer.transform.enabled())
    layer.transform.disable();
  if (layer.editing.enabled())
    layer.editing.disable();
  if (layer.dragging.enabled())
    layer.dragging.disable();
  disablerotate();
  _leaflayers.draw.removeLayer(layer);
  checklayers();
  recomputebackyardarea();
}

function editbuilding(layer)
{
  if (!layer && !_leaflets.maplayer._popup)
    return;
  layer = typeof layer == "undefined" ? _leaflets.maplayer._popup._source : layer;
  _leaflets.maplayer.closePopup();
  doneediting();
  if (!layer.editing.enabled())
  {
    disablerotate();
    layer.transform.enable({
      rotation: true,
      scaling: false
    });
    layer.transform._rect.setLatLngs(L.geoJson(turf.bboxPolygon(turf.bbox(L.polygon(layer.getLatLngs()).toGeoJSON(13)))).getLayers()[0].getLatLngs());
    layer.transform._updateHandlers();
    layer.editing.enable();
  }
}
function doneediting(layer)
{
  if (!layer && !_leaflets.maplayer._popup)
  {
    for (var l in _leaflayers.draw._layers)
    {
      doneediting(_leaflayers.draw._layers[l]);
    }
    return;
  }
  layer = typeof layer == "undefined" ? _leaflets.maplayer._popup._source : layer;
  if (layer.editing && layer.editing.enabled())
  {
    layer.transform.reset();
    layer.transform.disable();
    layer.editing.disable();
  }
  disablerotate();
  if (layer.dragging && !layer.dragging.enabled())
    layer.dragging.enable();
  _leaflets.maplayer.closePopup();
}
function deletemeasurement(layer)
{
  if (!layer && !_leaflets.maplayer._popup)
    return;
  layer = typeof layer == "undefined" ? _leaflets.maplayer._popup._source : layer;
  if (layer.transform && layer.transform.enabled())
    layer.transform.disable();
  if (layer.editing && layer.editing.enabled())
    layer.editing.disable();
  if (layer.dragging && layer.dragging.enabled())
    layer.dragging.disable();
  disablerotate();
  _leaflayers.draw.removeLayer(layer);
}
function syncmeasurements(widget)
{
  if (!widget.stopmeasurement && compfindx('measurement',['layer','measurement'],lambda,library))
  {
    if (widget._measurementLayer)
    {
      widget.showMeasurements();
      widget.updateMeasurements();
    }
    else
      widget.showMeasurements();
  }
  else
  {
    widget.hideMeasurements();
  }
}