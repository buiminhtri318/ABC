/*
Usage: 
getlotlines(<geometry>) to return lotlines, or
getlotlines(<geometry>,{"RotatingCallipers"|"Rectangle"}) to return lotlines using a specific method.

Usage:
displaylotlines(lotlines(<geometry>)) to display on map.


LOt Lines (LOL) algorithm:
Input: parcel
1. C = convex hull of parcel
2. bearings x and y.
3. B = bearing of edge e in C (x if x >= 0 else 180 + x)
4. Find 2 longest lines that are similar in slope to x.
5. Clean up to accommodate for concave regions in parcel.
Output: Lotlines

Lemma: Assignment array in lotline will have at least 3 value changes (if first and value are NOT the same) and at most 4 value changes (if first and value are the same)

Conjectured property: cleanupgon may be redundant, depending on how good min. oriented bbox algorithm is.

Conjectured bad cases: trapezoid with really long sides, or really skinny lots or really large internal angles - close to 180.
*/

function getlotlines(lot,method)
{
  method = typeof method == "undefined"? "getBBoxAM": {"RotatingCallipers":"getBBoxRC","Rectangle":"getBBoxAM"}[method];
  var parcel = turf.convex(lot),
      parcelLine = turf.lineSegment(parcel).features,
      parcelBearing = parcelLine.map(i => turf.rhumbBearing(i.geometry.coordinates[0],i.geometry.coordinates[1])).map(i => i >= 0? i: 180 + i),
      bbox = window[method].apply(null,[lot]),
      bboxLine = turf.lineSegment(bbox).features,
      bboxBearing = bboxLine.map(i => turf.rhumbBearing(i.geometry.coordinates[0],i.geometry.coordinates[1])).map(i => i >= 0? i: 180 + i).slice(0,2),
      assignment = parcelBearing.map(i => assignbearing(i,bboxBearing));
  /*special case of lots whose convex hull is 4 sided.*/
  if (parcelLine.length <= 3) return false;
  var geom = cleanupgon(turf.simplify(parcel,{highQuality: true, tolerance: 0.0000001}),1).geometry;
  if (geom.coordinates[0].length == 5 && geom.coordinates[0][0][0] === geom.coordinates[0][4][0])
  {
    parcel = geom;
    parcelLine = turf.lineSegment(parcel).features;
    parcelBearing = parcelLine.map(i => turf.rhumbBearing(i.geometry.coordinates[0],i.geometry.coordinates[1])).map(i => i >= 0? i: 180 + i);
    bbox = window[method].apply(null,[lot]);
    bboxLine = turf.lineSegment(bbox).features;
    bboxBearing = bboxLine.map(i => turf.rhumbBearing(i.geometry.coordinates[0],i.geometry.coordinates[1])).map(i => i >= 0? i: 180 + i).slice(0,2);
    var x = assignbearing(parcelBearing[0],bboxBearing);
    assignment = [x,1-x,x,1-x];
  }
  return extractLines(parcelLine,assignment).map(i => i.map(j => concavify(j,lot)));
}

function displaylotlines(lines,color)
{
  if (!lines.length)
  {
    //alert("I Sorries");
    return [];
  }
  color = typeof color == "undefined" || color.length < 2? ["hotpink","blue"]: color;
  var x = lines.map((i,k) => i.map(j => L.geoJSON(j,{style: {color: color[k]}}).addTo(_leaflets.maplayer))); 
  return x;
}

/*Captures the points between two endpoints in the polygon 'lot'*/
function concavify(line,lot)
{
  var pts = turf.coordAll(line),
      start = pts[0],
      end = pts[pts.length-1],
      lotPoint = turf.coordAll(lot).slice(0,-1),
      doubleLotPoint = lotPoint.concat(lotPoint),
      l1 = [],
      l2 = [],
      i;

  for (i = 0; i < doubleLotPoint.length && !(doubleLotPoint[i][0] == start[0] && doubleLotPoint[i][1] == start[1]); i++);
  for (; i < doubleLotPoint.length && !(doubleLotPoint[i][0] == end[0] && doubleLotPoint[i][1] == end[1]); i++)
  {
    l1.push(doubleLotPoint[i]);
  }
  l1.push(doubleLotPoint[i]);

  for (i = 0; i < doubleLotPoint.length && !(doubleLotPoint[i][0] == end[0] && doubleLotPoint[i][1] == end[1]); i++);
  for (; i < doubleLotPoint.length && !(doubleLotPoint[i][0] == start[0] && doubleLotPoint[i][1] == start[1]); i++)
  {
    l2.push(doubleLotPoint[i]);
  }
  l2.push(doubleLotPoint[i]);

  l1 = turf.lineString(l1);
  l2 = turf.lineString(l2);

  return turf.length(l1) <= turf.length(l2)? l1: l2;
}

/*Extracts lines corresponding to assignments 0 and 1*/
function extractLines(parcelLine,assignment)
{
  while (assignment[0] == assignment[assignment.length - 1])
  {
    parcelLine = [parcelLine[parcelLine.length - 1]].concat(parcelLine.slice(0,-1));
    assignment = [assignment[assignment.length - 1]].concat(assignment.slice(0,-1));
  }

  var valuechanges = 0;
  for (var i = 1; i < assignment.length; i++)
  {
    if (assignment[i] != assignment[i - 1])
    {
      valuechanges++;
    }
  }
  if (valuechanges < 3) return [];

  var doubleLine = parcelLine.concat(parcelLine),
      doubleAssignment = assignment.concat(assignment),
      lotline = [[], []],
      i = null, 
      line = null;

  /*Case 0*/
  //Loop fromm start till we reach an assignment of 0
  for (i = 0; doubleAssignment[i] && i < doubleAssignment.length; i++);
  //Capture linesegment till we reach an assigment of 1
  for (line = []; !doubleAssignment[i] && i < doubleAssignment.length; i++)
  {
    line.push(doubleLine[i]);
  } 
  line = line.map(i => i.geometry.coordinates[0]).concat([line[line.length - 1].geometry.coordinates[1]]);
  lotline[0].push(turf.lineString(line));
  /*Do eet again*/
  for (; doubleAssignment[i] && i < doubleAssignment.length; i++);
  for (line = []; !doubleAssignment[i] && i < doubleAssignment.length; i++)
  {
    line.push(doubleLine[i]);
  } 
  line = line.map(i => i.geometry.coordinates[0]).concat([line[line.length - 1].geometry.coordinates[1]]);
  lotline[0].push(turf.lineString(line));

  /*Case 1*/
  //Loop fromm start till we reach an assignment of 1
  for (i = 0; !doubleAssignment[i] && i < doubleAssignment.length; i++);
  //Capture linesegment till we reach an assigment of 0
  for (line = []; doubleAssignment[i] && i < doubleAssignment.length; i++)
  {
    line.push(doubleLine[i]);
  } 
  line = line.map(i => i.geometry.coordinates[0]).concat([line[line.length - 1].geometry.coordinates[1]]);
  lotline[1].push(turf.lineString(line));
  /*Do eet again*/
  for (; !doubleAssignment[i] && i < doubleAssignment.length; i++);
  for (line = []; doubleAssignment[i] && i < doubleAssignment.length; i++)
  {
    line.push(doubleLine[i]);
  } 
  line = line.map(i => i.geometry.coordinates[0]).concat([line[line.length - 1].geometry.coordinates[1]]);
  lotline[1].push(turf.lineString(line));

  return lotline;
}

/*bearing is an array of bearings of size 2. */
function assignbearing(bearing,reference)
{
  var m1 = Math.min(Math.abs(reference[0] - bearing), bearing <= reference[0]? (180 - reference[0]) + bearing: (180 - bearing) + reference[0]),
      m2 = Math.min(Math.abs(reference[1] - bearing), bearing <= reference[1]? (180 - reference[1]) + bearing: (180 - bearing) + reference[1]);
  return m1 <= m2? 0: 1;
}

/*Returns Min. Area BBox based on Rotated Callipers - this seems to get better results
*/

function getBBoxRC(lot)
{
  var pts = turf.coordAll(lot).slice(0,-1),
      rc = new RotatingCalipers(pts),
      bboxVertices = rc.minAreaEnclosingRectangle().vertices;
  return turf.polygon([bboxVertices.concat([bboxVertices[0]])]);
}

function getBBoxAM(lot)
{
  try
  {
    return boundingbox(lot);
  }
  catch(e)
  {
    try
    {
      return getBBoxRC(lot);
    }
    catch(e)
    {
      return turf.bboxPolygon(turf.bbox(lot));
    }
  }
}

// Rotating Callipers
(function()
{
  var __slice = [].slice;
  window.RotatingCalipers = (function()
  {
    /* PRIVATE
     */
    var _distance, _inputVertices, _quickHull;
    RotatingCalipers.name = 'RotatingCalipers';
    _inputVertices = null;
    /*
      #._distance
      @sign Number _distance(Array start, Array end, Array point)
      @param start - the start point forming the dividing line.
      @param end - the end point forming the dividing line.
      @param point - the point from which the distance to the line is calculated.
      Find the distance between a point and a line formed by a start and end points.
      All params have first index as the x and second index as y coordinate.
    
      The real distance value could be calculated as follows:
    
      Calculate the 2D Pseudo crossproduct of the line vector (start 
      to end) and the start to point vector. 
      ((y2*x1) - (x2*y1))
      The result of this is the area of the parallelogram created by the 
      two given vectors. The Area formula can be written as follows:
      A = |start->end| h
      Therefore the distance or height is the Area divided by the length 
      of the first vector. This division is not done here for performance 
      reasons. The length of the line does not change for each of the 
      comparison cycles, therefore the resulting value can be used to 
      finde the point with the maximal distance without performing the 
      division.
    
      Because the result is not returned as an absolute value its 
      algebraic sign indicates of the point is right or left of the given 
      line
    */
    _distance = function(start, end, point)
    {
      return (point[1] - start[1]) * (end[0] - start[0]) - (point[0] - start[0]) * (end[1] - start[1]);
    };
    /*
      #._quickHull
      @sign Array _quickHull(Array vertices, Array start, Array end)
      @param vertices - Contains the set of points to calculate the hull for.
                        Each point is an array with the form [x, y].
      @param start - The start point of the line, in the form [x, y].
      @param end - The end point of the line, in the form [x, y].
      @return set of points forming the convex hull, in clockwise order.
      Execute a QuickHull run on the given set of points, using the provided 
      line as delimiter of the search space.
    */
    _quickHull = function(vertices, start, end)
    {
      var d, maxDistance, maxPoint, newPoints, vertex, _i, _len;
      maxPoint = null;
      maxDistance = 0;
      newPoints = [];
      for (_i = 0, _len = vertices.length; _i < _len; _i++)
      {
        vertex = vertices[_i];
        if (!((d = _distance(start, end, vertex)) > 0))
        {
          continue;
        }
        newPoints.push(vertex);
        if (d < maxDistance)
        {
          continue;
        }
        maxDistance = d;
        maxPoint = vertex;
      }
      /*
          The current delimiter line is the only one left and therefore a 
          segment of the convex hull. Only the end of the line is returned 
          to not have points multiple times in the result set.
      */
      if (!(maxPoint != null))
      {
        return [end];
      }
      /*
          The new maximal point creates a triangle together with start and 
          end, Everything inside this trianlge can be ignored. Everything 
          else needs to handled recursively. Because the quickHull invocation 
          only handles points left of the line we can simply call it for the 
          different line segements to process the right kind of points.
      */
      return _quickHull(newPoints, start, maxPoint).concat(_quickHull(newPoints, maxPoint, end));
    };
    /* PUBLIC
     */
    /*
      #RotatingCalipers.constructor
      @sign void constructor(Array vertices)
      @sign void RotatingCalipers(Array vertex, Array vertex, Array vertex[, Array vertex...])
      @param vertices - An array contains vertices in form of an array. Can also take 
                        each vertex as arguments
    */
    function RotatingCalipers(verticesOrFirst)
    {
      var rest, vertex, vertex1, vertex2, vertex3, _i, _len;
      if (!(verticesOrFirst != null))
      {
        throw new Error("Argument required");
      }
      if (!(verticesOrFirst instanceof Array) || verticesOrFirst.length < 3)
      {
        throw new Error("Array of vertices required");
      }
      vertex1 = verticesOrFirst[0], vertex2 = verticesOrFirst[1], vertex3 = verticesOrFirst[2], rest = 4 <= verticesOrFirst.length ? __slice.call(verticesOrFirst, 3) : [];
      for (_i = 0, _len = verticesOrFirst.length; _i < _len; _i++)
      {
        vertex = verticesOrFirst[_i];
        if (!(vertex instanceof Array) || vertex.length < 2)
        {
          throw new Error("Invalid vertex");
        }
        if (isNaN(vertex[0]) || isNaN(vertex[1]))
        {
          throw new Error("Invalid vertex");
        }
      }
      _inputVertices = verticesOrFirst;
    }
    /*
      RotatingCalipers.convexHull
      @sign Array convexHull(void)
      @return an Array of the points forming the minimal convex set containing all
              input vertices.
      Calculates the convex hull of the arbitrary vertices defined in constructor.
    */
    RotatingCalipers.prototype.convexHull = function()
    {
      var extremeX, finder;
      finder = function(arr)
      {
        var el, ret, _i, _len;
        ret = {};
        ret.min = ret.max = arr[0];
        for (_i = 0, _len = arr.length; _i < _len; _i++)
        {
          el = arr[_i];
          if (el[0] < ret.min[0])
          {
            ret.min = el;
          }
          if (el[0] > ret.max[0])
          {
            ret.max = el;
          }
        }
        return ret;
      };
      extremeX = finder(_inputVertices);
      return _quickHull(_inputVertices, extremeX.min, extremeX.max).concat(_quickHull(_inputVertices, extremeX.max, extremeX.min));
    };
    /*
      RotatingCalipers.angleBetweenVectors
      @sign Number angleBetweenVectors(Array vector1, Array vector2)
      @param vector1 - the first vector
      @param vector2 - the second vector
      @return the angle between them, in radian
      Calculate the angle between two vectors.
    */
    RotatingCalipers.prototype.angleBetweenVectors = function(vector1, vector2)
    {
      var dotProduct, magnitude1, magnitude2;
      dotProduct = vector1[0] * vector2[0] + vector1[1] * vector2[1];
      magnitude1 = Math.sqrt(vector1[0] * vector1[0] + vector1[1] * vector1[1]);
      magnitude2 = Math.sqrt(vector2[0] * vector2[0] + vector2[1] * vector2[1]);
      return Math.acos(dotProduct / (magnitude1 * magnitude2));
    };
    /*
      RotatingCalipers.rotateVector
      @sign Array rotateVector(Array vector, Number angle)
      @param vector - the vector to rotate
      @param angle - the angle to rotate to, in radian
      @return the rotated vector as an array
      Rotate a vector to an angle and return the rotated vector.
    */
    RotatingCalipers.prototype.rotateVector = function(vector, angle)
    {
      var rotated;
      rotated = [];
      rotated[0] = vector[0] * Math.cos(angle) - vector[1] * Math.sin(angle);
      rotated[1] = vector[0] * Math.sin(angle) + vector[1] * Math.cos(angle);
      return rotated;
    };
    /*
      RotatingCalipers.shortestDistance
      @sign Number shortestDistance(Array p, Array t, Array v)
      @param p - the point to which the shortest distance is calculated
      @param t - the point through which the vector extends
      @param v - the vector extended to t to form a line
      Calculate the shortest distance from point p to the line formed by extending
      the vector v through point t
    */
    RotatingCalipers.prototype.shortestDistance = function(p, t, v)
    {
      var a, c;
      if (v[0] === 0)
      {
        return Math.abs(p[0] - t[0]);
      }
      a = v[1] / v[0];
      c = t[1] - a * t[0];
      return Math.abs(p[1] - c - a * p[0]) / Math.sqrt(a * a + 1);
    };
    /*
      RotatingCalipers.intersection
      @sign Array intersection(Array point1, Array vector1, Array point2, Array vector2)
      @param point1 - the point through which the first vector passing
      @param vector1 - the vector passing through point1
      @param point2 - the point through which the second vector passing
      @param vector2 - the vector passing through point2
      @return the intersecting point between two vectors
      Finds the intersection of the lines formed by vector1 passing through
      point1 and vector2 passing through point2
    */
    RotatingCalipers.prototype.intersection = function(point1, vector1, point2, vector2)
    {
      var b1, b2, m1, m2, point;
      if (vector1[0] === 0 && vector2[0] === 0)
      {
        return false;
      }
      if (vector1[0] !== 0)
      {
        m1 = vector1[1] / vector1[0];
        b1 = point1[1] - m1 * point1[0];
      }
      if (vector2[0] !== 0)
      {
        m2 = vector2[1] / vector2[0];
        b2 = point2[1] - m2 * point2[0];
      }
      if (vector1[0] === 0)
      {
        return [point1[0], m2 * point1[0] + b2];
      }
      if (vector2[0] === 0)
      {
        return [point2[0], m1 * point2[0] + b1];
      }
      if (m1 === m2)
      {
        return false;
      }
      point = [];
      point[0] = (b2 - b1) / (m1 - m2);
      point[1] = m1 * point[0] + b1;
      return point;
    };
    /*
      RotatingCalipers.minAreaEnclosingRectangle
      @sign Object minAreaEnclosingRectangle(void)
      @return an object containing the vertices, width, height and area of the
      enclosing rectangle that has the minimum area.
      Calculate the mimimum area enclosing retangle for a convex polygon with n
      vertices given in clockwise order.
      The algorithm is based on Godfried Toussaint's 1983 whitepaper on "Solving
      geometric problems with the rotating calipers" and the Wikipedia page for 
      "Rotating Calipers". More info at http://cgm.cs.mcgill.ca/~orm/maer.html.
      Ported from Geoffrey Cox's PHP port (github.com/brainbook/BbsRotatingCalipers).
      Adapted for CoffeeScript by Son Tran.
      The general guidelines for the algorithm is as followed:
      1. Compute all four extreme points, and call them xminP, xmaxP, yminP ymaxP.
      2. Construct four lines of support for P through all four points. 
        These determine two sets of "calipers".
      3. If one (or more) lines coincide with an edge, then compute the area of the
        rectangle determined by the four lines, and keep as minimum. Otherwise, 
        consider the current minimum area to be infinite.
      4. Rotate the lines clockwise until one of them coincides with an edge.
      5. Compute area of new rectangle, and compare it to the current minimum area. 
        Update the minimum if necessary, keeping track of the rectangle determining the minimum. 
      6. Repeat steps 4 and 5, until the lines have been rotated an angle greater than 90 degrees.
      7. Output the minimum area enclosing rectangle.
    */
    RotatingCalipers.prototype.minAreaEnclosingRectangle = function()
    {
      var angles, area, caliper, calipers, getEdge, getItem, height, hull, i, idx, minAngle, minArea, minHeight, minPairs, minWidth, point, rotatedAngle, vertices, width, xIndices, _i, _len;
      hull = this.convexHull().reverse();
      xIndices = [0, 0, 0, 0];
      getItem = function(idxOfExtremePointInHull)
      {
        return hull[idxOfExtremePointInHull % hull.length];
      };
      getEdge = function(idxOfExtremePointInHull)
      {
        var pointA, pointB;
        pointA = getItem(idxOfExtremePointInHull + 1);
        pointB = getItem(idxOfExtremePointInHull);
        return [pointA[0] - pointB[0], pointA[1] - pointB[1]];
      };
      /*
          Compute all four extreme points for the polygon, store their indices.
      */
      for (idx = _i = 0, _len = hull.length; _i < _len; idx = ++_i)
      {
        point = hull[idx];
        if (point[1] < hull[xIndices[0]][1])
        {
          xIndices[0] = idx;
        }
        if (point[1] > hull[xIndices[1]][1])
        {
          xIndices[1] = idx;
        }
        if (point[0] < hull[xIndices[2]][0])
        {
          xIndices[2] = idx;
        }
        if (point[0] > hull[xIndices[3]][0])
        {
          xIndices[3] = idx;
        }
      }
      rotatedAngle = 0;
      minArea = minWidth = minHeight = null;
      calipers = [
        [1, 0],
        [-1, 0],
        [0, -1],
        [0, 1]
      ];
      /*
          Repeat computing, until the lines have been rotated an angle greater than 90 degrees.
      */
      while (rotatedAngle < Math.PI * 2)
      {
        /*
              Calculate the angle between the edge next adjacent to each extreme point
              and its caliper. The minimum of those angles indicates the angle needed
              to rotate all calipers to coincide with the nearest edge.
        */
        angles = (function()
        {
          var _j, _len1, _results;
          _results = [];
          for (i = _j = 0, _len1 = xIndices.length; _j < _len1; i = ++_j)
          {
            idx = xIndices[i];
            _results.push(this.angleBetweenVectors(getEdge(idx), calipers[i]));
          }
          return _results;
        }).call(this);
        minAngle = Math.min.apply(Math, angles);
        /*
              Then rotate all calipers to that minimum angle.
        */
        calipers = (function()
        {
          var _j, _len1, _results;
          _results = [];
          for (_j = 0, _len1 = calipers.length; _j < _len1; _j++)
          {
            caliper = calipers[_j];
            _results.push(this.rotateVector(caliper, minAngle));
          }
          return _results;
        }).call(this);
        idx = angles.indexOf(minAngle);
        /* 
        Compute the area of the new rectangle
        */
        switch (idx)
        {
          case 0:
          case 2:
            width = this.shortestDistance(getItem(xIndices[1]), getItem(xIndices[0]), calipers[0]);
            height = this.shortestDistance(getItem(xIndices[3]), getItem(xIndices[2]), calipers[2]);
            break;
          case 1:
            width = this.shortestDistance(getItem(xIndices[0]), getItem(xIndices[1]), calipers[1]);
            height = this.shortestDistance(getItem(xIndices[3]), getItem(xIndices[2]), calipers[2]);
            break;
          case 3:
            width = this.shortestDistance(getItem(xIndices[1]), getItem(xIndices[0]), calipers[0]);
            height = this.shortestDistance(getItem(xIndices[2]), getItem(xIndices[3]), calipers[3]);
        }

        var extremes = [getItem(xIndices[0]),getItem(xIndices[1]),getItem(xIndices[2]),getItem(xIndices[3])];
        var bbox = turf.convex(turf.featureCollection(extremes.map(i => turf.point(i))));
        var area = (turf.area(bbox) - turf.area(_geometry)) * turf.areaFactors.feet;

        rotatedAngle += minAngle;
        //area = width * height;
        /*
              Compare the new area to the current minArea.
        */
        if (!(minArea != null) || area < minArea)
        {
          /*
                  Update the minArea, keeping track of the rectangle determining the minimum.
          */
          minArea = area;
          minPairs = (function()
          {
            var _j, _results;
            _results = [];
            for (i = _j = 0; _j < 4; i = ++_j)
            {
              _results.push([getItem(xIndices[i]), calipers[i]]);
            }
            return _results;
          })();
          minWidth = width;
          minHeight = height;
        }
        /*
              Update the index of the extreme point with the minimum angle to the next point
              of the polygon.
        */
        xIndices[idx]++;
      }
      vertices = [this.intersection(minPairs[0][0], minPairs[0][1], minPairs[3][0], minPairs[3][1]), this.intersection(minPairs[3][0], minPairs[3][1], minPairs[1][0], minPairs[1][1]), this.intersection(minPairs[1][0], minPairs[1][1], minPairs[2][0], minPairs[2][1]), this.intersection(minPairs[2][0], minPairs[2][1], minPairs[0][0], minPairs[0][1])];
      return {
        vertices: vertices,
        width: minWidth,
        height: minHeight,
        area: minArea
      };
    };
    return RotatingCalipers;
  })();
}).call(this);

/*AM's min. area bounding rectangular. Hint: it has to be aligned with one of the sides of the convex polygon*/
function boundingbox(polygon)
{
  var convex = turf.convex(polygon),
      point = turf.explode(convex).features.slice(0,-1),
      line = turf.lineSegment(convex).features,
      area = Infinity,
      bbox = null;
  for (var i = 0; i < line.length; i++)
  {
    var rectangle = rectanglizeLine(line[i],point);
    if (turf.area(rectangle) < area)
    {
      area = turf.area(rectangle);
      bbox = rectangle;
    }
  }
  return bbox;
}

function extendLine(line)
{
  var point = turf.explode(line).features,
      midpoint = turf.midpoint(...point),
      bearing = point.map(i=>turf.rhumbBearing(midpoint,i));
  return turf.lineString(bearing.map(i=>turf.rhumbDestination(midpoint,1,i).geometry.coordinates));
}

function perpendicularIntersect(point,line)
{
  var bearing = turf.rhumbBearing(...turf.explode(line).features),
      perpendicular = perpendicularLine(point,line);
  return turf.lineIntersect(perpendicular,line).features[0];
}

function perpendicularLine(point,line)
{
  var bearing = turf.rhumbBearing(...turf.explode(line).features);
  return turf.lineString([bearing + 90,bearing - 90].map(i=>turf.rhumbDestination(point,1,i).geometry.coordinates));
}

function extremeIntersectsOnLine(point,line,startpoint)
{
  var max = -Infinity, extreme = [];
  var intersect = point.map(pt => perpendicularIntersect(pt,line));
  for (var i = 0; i < intersect.length; i++)
  {
    var start = typeof startpoint == "undefined"? intersect[i]: startpoint;  
    for (var j = i; j < intersect.length; j++)
    {
      var end = intersect[j],
          distance = turf.distance(start,end,{units:'feet'});
      if (distance > max)
      {
        max = distance;
        extreme = [start,end];
      }
    }
  }
  return extreme;
}

function rectanglizeLine(line,point)
{
  var extreme = extremeIntersectsOnLine(point,extendLine(line)),
      bearing = turf.rhumbBearing(...turf.explode(line).features),
      perpendicularExtendedLine = extreme.map(i=>extendLine(turf.lineString([i,turf.rhumbDestination(i,10,bearing+90,{units:'feet'})].map(i=>i.geometry.coordinates))));
  extreme = extreme.map((pt,i)=>extremeIntersectsOnLine(point,perpendicularExtendedLine[i],pt));
  return turf.convex(turf.featureCollection(extreme[0].concat(extreme[1])));
}