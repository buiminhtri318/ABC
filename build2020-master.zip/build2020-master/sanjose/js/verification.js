//Check all layers in draw
function checklayers(angle)
{
  var l = _leaflayers.draw._layers, buildingpresent = false;
  for (var i in l)
  {
    if (l[i] instanceof L.Polygon && l[i].options.className && l[i].options.className.indexOf('adu') != -1)
    {
      modlayer(l[i],angle);
    }
    else if (l[i] instanceof L.Polygon)
    {
      buildingpresent = true;
      syncmeasurements(l[i]);
    }
  } 
  var footprint = numberize(totalnonadufootprint());
  var current = numberize(compfindx("X",["existingfootprint","X"],lambda,library));
  if (_leaflets.maplayer.hasLayer(_leaflayers.draw) && buildingpresent && (isNaN(current) || Math.abs(footprint - numberize(current)) > 1))
  {
    fullreact(["select","existingfootprint",footprint + ""]);
  }
}
function modlayer(widget,angle)
{
  angle = typeof angle == "undefined"? null: angle;
  if (!(widget instanceof L.Polygon))
  {
    syncmeasurements(widget);
    return;
  }
  checkunit(widget,angle);
  syncmeasurements(widget);
}
//check if adu satisfies positional and size constraints
function checkunit(widget,angle)
{
  angle = typeof angle == "undefined"? null: angle;

  var detached = compfindx("detachedadu","detachedadu",lambda,library);
  var attached = compfindx("attachedadu","attachedadu",lambda,library);
  var singlefamily = compfindx("singlefamilyresidence","singlefamilyresidence",lambda,library);
  if (singlefamily && detached)
  {
    var backyardcover_exceeded = compfindx('backyardcover_exceeded','backyardcover_exceeded',lambda,library),
      backyard_status = hasbackyardcoverexceeded();
    if (backyard_status && !backyardcover_exceeded)
    {
      savefact("backyardcover_exceeded",lambda);
      populatesheet();
    }
    else if (!backyard_status && backyardcover_exceeded) 
    {
      dropfact("backyardcover_exceeded",lambda);
      populatesheet();
    }
    var largeryards_detached = compfindx('largeryards_detached','largeryards_detached',lambda,library),
      sideyard_status = issideyardlarger();
    if (sideyard_status && !largeryards_detached)
    {
      savefact("largeryards_detached",lambda);
      populatesheet();
    }
    else if (!sideyard_status && largeryards_detached) 
    {
      dropfact("largeryards_detached",lambda);
      populatesheet();
    }
  }

  var style = {};
  style.good = (detached || attached) && !compfindx("setback",["layer","setback"],lambda,library)? {fillColor: '#26C281', fillOpacity: 0.66}: {fillColor: 'white', fillOpacity: 0.4};
  style.alerts = {fillColor: '#ffcb05', fillOpacity: 0.66};
  style.bad = {fillColor: '#F03434', fillOpacity: 0.66};

  var poly = L.polygon(widget.getLatLngs(),{transform: true});

  poly.setStyle({color: 'transparent', weight: 0, opacity: 0});
  poly.addTo(_leaflayers['boundary']);

  if (angle)
  {
    poly.transform.rotate(angle);
  }
  poly.removeFrom(_leaflayers['boundary']);

  var polygon = standardizefeature(poly.toGeoJSON(13));

  var area = turf.area(polygon) * turf.areaFactors.feet;
  area = roundify(area,1);
  var areatxt = "<b>Footprint:</b> " + commaseparate(area) + " sq. ft.";

  var permittedadu = compfindx('permittedadu','permittedadu',lambda,library);
  if (!permittedadu || (!detached && !attached))
  {
    var edit = widget.editing.enabled()? "<a href='javascript:void(0)' onclick='doneediting();'><span class='fas fa-check'></span> Done Editing</a>": "<a href='javascript:void(0)' onclick='editbuilding();'>Edit building</a>";  
    areatxt += "<p style='margin: 20px 0px 0px'>" + edit + "</p><p style='margin: 5px 0px 0px'><a href='javascript:void(0)' onclick='deletebuilding();'>Delete building</a></p>";
    
    widget.setStyle(style.good);
    widget.setPopupContent(areatxt);
    return;
  }

  var warning = {}, warnings = [], buildableareacomputed = !compfindx("nobuildablearea","nobuildablearea",lambda,library);

  var separation = numberize(compfindx("X",["aduseparation","X"],lambda,library));
  if (!isNaN(separation))
  	warning.proximityAlert = "<i class='fas fa-exclamation-circle'></i> Within " + separation + " ft. of primary residence.";
  warning.separation = "<i class='fas fa-exclamation-circle'></i> Within 5 ft. of a building.";

  if (buildableareacomputed)
  {
    warning.setbackViolated = "<i class='fas fa-exclamation-circle'></i> Not adequately set back from lot lines.";
    warning.secondstory = "<i class='fas fa-exclamation-circle'></i> Any second story must be set back at least 4 ft. from the side and rear lot lines.";
  }

  warning.notAttached = "<i class='fas fa-exclamation-circle'></i> Not attached to primary residence.";
  warning.sameRoof = "<i class='fas fa-exclamation-circle'></i> Must share an integral roof structure with the primary residence.";

  warning.notDetached = "<i class='fas fa-exclamation-circle'></i> Not detached from primary residence.";
  
  warning.footprint = "<i class='fas fa-exclamation-circle'></i> Exceeds maximum square footage.";

  var polybuffer = turfAM.buffer(polygon,-4,{units: "inches"}),
  		primary = getprimary(),
      adu_10ft_buffer = turfAM.buffer(polygon,10,{units: "feet"}),
      adu_5ft_buffer = turfAM.buffer(polygon,5,{units: "feet"});
  
  var flag = {};

  warning.smalladu = "<i class='fas fa-exclamation-circle'></i> Must be at least 150 sq. ft.";
  flag.smalladu = area < 150;

  flag.proximityAlert = detached && primary && separation && isdisjoint(polygon,primary) && !isdisjoint(polygon,turfAM.buffer(primary,separation,{units:'feet'}));
  if (detached)
  {
    try
    {
      var nonadustructures = getnonadustructures();
      nonadustructures.sort(function(a,b){return turf.area(b) - turf.area(a)});
      if (!isNaN(separation))
        nonadustructures = nonadustructures.slice(1);
      flag.separation = nonadustructures.filter(i=>!isdisjoint(i,adu_5ft_buffer)).length;
    } catch(e){}
  }

  //flag.notAttached = attached && primary && isdisjoint(polygon,primary);
  flag.notAttached = attached && primary && isdisjoint(primary,adu_10ft_buffer);
  flag.sameRoof = attached && primary && isdisjoint(polygon,primary) && !isdisjoint(primary,adu_10ft_buffer);

  flag.notDetached = detached && primary && !isdisjoint(polygon,primary);

  flag.footprint = false;
  var y = compfindx('X',['aduarea','X'],lambda,library);
  try
  {
    y = numberize(y);
    if (area > roundify(y,1))
      flag.footprint = true;
  }
  catch(e){}

  if (buildableareacomputed)
  {
    var buildablearea = computebuildablearea();
    try
    {
      buildablearea = turf.union(computebuildablerearyard(),buildablearea);
      flag.setbackViolated = !turf.booleanWithin(polybuffer,buildablearea);
    } 
    catch (e) 
    {
      flag.setbackViolated = !turf.booleanWithin(polybuffer,buildablearea);
    }
    if (!flag.setbackViolated && detached)
    {
      var secondstorysetbackpoly = secondstory();
      if (secondstorysetbackpoly && !turf.booleanWithin(polybuffer,secondstorysetbackpoly))
      {
        flag.secondstory = true;
      }
    }
  }

  var badattrs = ['proximityAlert', 'setbackViolated', 'footprint', 'smalladu'];
  var alertattrs = ['notAttached', 'notDetached', 'secondstory', 'sameRoof', 'separation'];

  var badwarnings = [], alertwarnings = [];

  for (var i = 0; i < badattrs.length; i++)
  {
    if (flag[badattrs[i]])
    {
      badwarnings.push(warning[badattrs[i]]);
    }
  }

  for (var i = 0; i < alertattrs.length; i++)
  {
    if (flag[alertattrs[i]])
    {
      alertwarnings.push(warning[alertattrs[i]]);
    }
  }

  if (badwarnings.length)
    widget.setStyle(style.bad);
  else if (alertwarnings.length)
    widget.setStyle(style.alerts);
  else
    widget.setStyle(style.good);

  var reqs = [];
  if (buildableareacomputed && !flag.setbackViolated)
  {  
    reqs.push('setback');
  }

  var reqtext = smartjoin(reqs);
  var success = '<span class="far fa-check-circle"></span> Satisfies ' + reqtext + ' requirements.</span>';

  var popupcontent = areatxt + '<hr>';

  if (badwarnings.length)
    popupcontent += '<span style="color: #F03434">' + badwarnings.join("<br>") + '</span><div style="height:10px;"></div>';

  if (reqs.length)
  { 
    popupcontent += '<span style="color: #26C281">' + success + '</span>';
    if (flag.footprint)
      popupcontent += '<div style="height:10px;"></div>';
    else
      popupcontent += '<br>';
  }
  var successfootprint = '<span class="far fa-check-circle"></span> Does not exceed maximum square footage.</span>';
  if (!flag.footprint)
  {
    popupcontent += '<span style="color: #26C281">' + successfootprint + '</span>';
    if (alertwarnings.length)
      popupcontent += '<div style="height:10px;"></div>';
  }

  if (alertwarnings.length)
    popupcontent += '<span style="color: #e87e04">' + alertwarnings.join("<br>") + '</span>';

  var edit = widget.editing.enabled()? "<a href='javascript:void(0)' onclick='doneediting();'><span class='fas fa-check'></span> Done Editing</a>": "<a href='javascript:void(0)' onclick='editbuilding();'>Edit building</a>";  
  popupcontent += "<p style='margin: 20px 0px 0px'>" + edit + "</p><p style='margin: 5px 0px 0px'><a href='javascript:void(0)' onclick='deletebuilding();'>Delete building</a></p>";
  widget.setPopupContent(popupcontent);
  return;
}