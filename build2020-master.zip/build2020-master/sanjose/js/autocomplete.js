/*Autocompletion code*/
//key handler
_keyhandlers['autocomplete'] = function(e)
{
  if (e.target.getAttribute("id") == "locationtext")
  {
    modkeylocation(e);
  }
}

//action
function modautocomplete(e) 
{
  var a, b, i, val = e.target.value.trim();
  closeAllLists();
  if (!val)
    return modstring(document.querySelector("#locationtext"));
  _currentFocus = -1;

  a = document.createElement("DIV");
  a.setAttribute("type","autocomplete-list");
  a.setAttribute("class","autocomplete-items");

  e.target.parentNode.appendChild(a);
  
  var arr = locationsuggestion(val);
  var emptyresult = arr.addr.length + arr.apn.length == 0
  modstring(document.querySelector("#locationtext"));
  if (!emptyresult)
  {
    for (i = 0; i < arr.addr.length; i++) 
    {
      var c = arr.addr[i];
      b = document.createElement("DIV");
      b.innerHTML = "<strong>" + c.substr(0, val.length) + "</strong>";
      b.innerHTML += c.substr(val.length);
      b.setAttribute("data",c);
      b.addEventListener("click", 
        function(e)
        {
          document.querySelector("#locationtext").value = this.getAttribute("data");
          modstring(document.querySelector("#locationtext"));
          closeAllLists();
          asyncmodbutton(document.querySelector('#search'),function(){smoothscroll('content(zoning)',300,'top','sidebar');});
        }
      );
      a.appendChild(b);
    }
    for (i = 0; i < arr.apn.length; i++) 
    {
      var c = arr.apn[i];
      b = document.createElement("DIV");
      b.innerHTML = "<strong>Parcel Number: " + c.substr(0, val.length) + "</strong>";
      b.innerHTML += c.substr(val.length);
      b.setAttribute("data",c);
      b.addEventListener("click", 
        function(e)
        {
          document.querySelector("#locationtext").value = this.getAttribute("data");
          modstring(document.querySelector("#locationtext"));
          closeAllLists();
          asyncmodbutton(document.querySelector('#search'),function(){smoothscroll('content(zoning)',300,'top','sidebar');});
        }
      );
      a.appendChild(b);
    }
    _currentFocus = 0;
    addActive(document.querySelector("[type='autocomplete-list']").getElementsByTagName("div"));
  }
  else
  {
    insertfact("emptygeo",lambda);
    populatesheet();
    b = document.createElement("DIV");
    b.innerHTML = "No matching addresses";
    b.addEventListener("click", 
      function(e)
      {
        document.querySelector("#locationtext").value = "";
        modstring(document.querySelector("#locationtext"));
        closeAllLists();
      }
    );
    a.appendChild(b);
  }
}
//actions corresponding to keyboard input on autocompletion field
function modkeylocation(e)
{
  var x = document.querySelector("[type='autocomplete-list']");
  if (x) 
    x = x.getElementsByTagName("div");
  if (e.keyCode == 40)
  {
    _currentFocus++;
    addActive(x);
  }
  else if (e.keyCode == 38)
  {
    _currentFocus--;
    addActive(x);
  }
  else if (e.keyCode == 13)
  {
    e.preventDefault();
    if (_currentFocus > -1 && x)
    {
      x[_currentFocus].click();
      document.querySelector("#locationtext").blur();
    }
  }
}
//remove/add active elements
function removeActive(x) 
{
  for (var i = 0; i < x.length; i++)
    x[i].classList.remove("autocomplete-active");
}   
function addActive(x) 
{
  if (!x) 
    return false;
  removeActive(x);
  if (_currentFocus >= x.length) 
    _currentFocus = 0;
  if (_currentFocus < 0) 
    _currentFocus = x.length - 1;
  x[_currentFocus].classList.add("autocomplete-active");
}
//close autocompletion lists
function closeAllLists(elmnt) 
{
  var x = document.getElementsByClassName("autocomplete-items");
  for (var i = 0; i < x.length; i++)
    if (elmnt != x[i] && elmnt != document.querySelector("#locationtext"))
      x[i].parentNode.removeChild(x[i]);
}
//generate suggestions
function locationsuggestion(val)
{
  var url = _path + "address.php";
  var params = {loc: val.replace(/[^A-Za-z0-9\s]/g,' ').replace(/\s+/g,' ')};
  try
  {
    var a = JSON.parse(postvalues(url,params));
    if (a.length == 5)
      return {addr: a, apn:[]};

    url = _path + "apn.php";
    params = {apn: val};
    var b = JSON.parse(postvalues(url,params));
    return {addr: a, apn: b.slice(0,5-a.length)};
  }
  catch (e)
  {
    return {addr: [], apn: []};
  }
}