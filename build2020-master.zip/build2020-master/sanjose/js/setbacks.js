function computebuildablearea()
{
	var parcel = standardizefeature(_geometry),
			requiredyards = [];
	for (var yardtype in _lotlines[_apn])
	{
		var query = [yardtype + "setback","X"],
				yard = numberize(compfindx("X",query,lambda,library))||0,
				lotline = _lotlines[_apn][yardtype];
		if (Array.isArray(lotline))
		{
			for (var i = 0; i < lotline.length; i++)
			{
        if (yard)
				  requiredyards.push(turfAM.buffer(lotline[i],yard,{units:'feet'}));
			}
		}
		else if (yard)
			requiredyards.push(turfAM.buffer(lotline,yard,{units:'feet'}));
	}
  for (var i = 0; i < requiredyards.length; i++)
  {
    parcel = turf.difference(parcel,requiredyards[i]);
  }
	return parcel;
}

function computebuildablerearyard()
{
  var parcel = backyardareapolygon(),
      requiredyards = [];
  for (var yardtype in _lotlines[_apn])
  {
    if (yardtype != 'front')
    {
      var query = [yardtype + "setback","X"],
          yard = numberize(compfindx("X",query,lambda,library))||0,
          lotline = _lotlines[_apn][yardtype];
      if (Array.isArray(lotline))
      {
        for (var i = 0; i < lotline.length; i++)
        {
          if (yard)
            requiredyards.push(turfAM.buffer(lotline[i],yard,{units:'feet'}));
        }
      }
      else if (yard)
        requiredyards.push(turfAM.buffer(lotline,yard,{units:'feet'}));
    }
  }
  for (var i = 0; i < requiredyards.length; i++)
  {
    parcel = turf.difference(parcel,requiredyards[i]);
  }
  return parcel;
}

function lotlines()
{
	if (!(_apn in _lotlines))
	{
		var lines = getlotlines(_geometry);
		var address = _cache[_apn].report.address.split(", CA -")[0];
		try
		{
			var front = null, rear = null, side = [], streetside = [], frontlength = Infinity, frontindex = -1;
			var closestObject = [[null,null],[null,null]], streetfacing = [[false,false],[false,false]], length = [[Infinity,Infinity],[Infinity,Infinity]];
			for (var i = 0; i < 2; i++)
			{
				for (var j = 0; j < 2; j++)
				{
					closestObject[i][j] = nearestStreetAndParcel(lines[i][j],_geometry);
					var closestStreet = closestObject[i][j][0],
							closestParcel = closestObject[i][j][1],
							streetName = closestStreet[0];
					length[i][j] = turf.length(lines[i][j],{units:'feet'});
					if (closestStreet[2] < closestParcel[1]) //Street facing lot line
					{
						streetfacing[i][j] = true;
						if (address.indexOf(streetName) != -1) //Street Name in Address
						{
							if (length[i][j] < frontlength)
							{
								front = lines[i][j];
								frontindex = i * 2 + j;
							}
						}
					}
				}
			}
			if (!front)//front lot line has not yet been determined
			{
				var indices = [[0,0],[0,1],[1,0],[1,1]].filter(i=>streetfacing[i[0]][i[1]]);
				indices.sort(
					function(i,j)
					{
						length[i[0]][i[1]] - length[j[0]][j[1]];
					}
				);
				front = lines[indices[0][0]][indices[0][1]];
				frontindex = indices[0][0] * 2 + indices[0][1];
			}
			var j = frontindex%2,
						i = (frontindex-j)/2;
			rear = lines[i][1-j];
			if (streetfacing[i][1-j])
			{
				insertfact("throughlot",lambda); //is a through lot
			}
			for (var j = 0; j < 2; j++)
			{
				if (streetfacing[1-i][j])
					streetside.push(lines[1-i][j]);
				else
					side.push(lines[1-i][j]);
			}
			if (side.length)
			{
				insertfact("hasinteriorside",lambda); //has interior side
			}
			if (streetside.length)
			{
				insertfact("hasstreetside",lambda); //is corner lot
			}
			_lotlines[_apn] = {front: front, rear: rear, streetside: streetside, side: side};
		}
		catch(e)
		{
			_lotlines[_apn] = false;
		}
	}
	return _lotlines[_apn];
}

function nearestStreetAndParcel(lotline,lot,maxRowWidth)
{
	maxRowWidth = typeof maxRowWidth == "undefined"? _maxRowWidth: maxRowWidth;	
	var center = turf.center(lot),
			lineCoords = turf.coordAll(lotline),
			midPoint = turf.midpoint(lineCoords[0],lineCoords[lineCoords.length-1]),
			bearing = turf.rhumbBearing(center,midPoint),
			distance = turf.distance(center,midPoint,{units:'feet'}) + maxRowWidth,
			extrapolatedDestination = turf.rhumbDestination(center,distance,bearing,{units:'feet'}),
			extrapolatedLine = turf.lineString([center,extrapolatedDestination].map(i=>i.geometry.coordinates)),
			closestParcel = nearestParcel(midPoint,extrapolatedLine),
			closestStreet = nearestStreet(midPoint,extrapolatedLine);
	return [closestStreet,closestParcel];
}

function nearestStreet(point,line)
{
	var streets = getStreets(line);
	if (!streets.length)
		return [null,null,Infinity];

	streets = streets.map(i => {var d = turf.lineIntersect(i[1],line).features.map(i=>turf.distance(point,i,{units:'feet'})); d.sort(); return i.concat([d.length? d[0]: Infinity]);});
	streets.sort(
		function(i,j)
		{
			return i[2] - j[2];
		}
	);
	return streets[0];
}

function nearestParcel(point,line)
{
	var parcels = getParcels(line);
	if (!parcels.length)
		return [null,Infinity];

	parcels = parcels.map(i => {var d = turf.lineIntersect(i,line).features.map(i=>turf.distance(point,i,{units:'feet'})); d.sort(); return [i,d.length? d[0]: Infinity];});
	parcels.sort(
		function(i,j)
		{
			return i[1] - j[1];
		}
	);
	return parcels[0];
}

function getStreets(line)
{
	var url = _path + "nearbystreet.php",
			params = {select:"NAME", where: "ST_INTERSECTS(ST_GEOMFROMGEOJSON('" + JSON.stringify(line.geometry)  + "'),geom)"};
	try
	{
		return JSON.parse(postvalues(url,params)).map(i=>[i[0],standardizefeature(JSON.parse(i[1]))]);
	}
	catch(e)
	{
		return [];
	}
}

function getParcels(line)
{
	var url = _path + "nearbyparcel.php",
			params = {where: "APN <> '" + _apn + "' AND ST_INTERSECTS(ST_GEOMFROMGEOJSON('" + JSON.stringify(line.geometry)  + "'),geom)"};
	try
	{
		return JSON.parse(postvalues(url,params)).map(i=>standardizefeature(JSON.parse(i[0])));
	}
	catch(e)
	{
		return [];
	}
}