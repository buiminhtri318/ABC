/*Global variables*/
var _path = '../lib/sanjose/php/';
var _datapath = '../lib/sanjose/data/';
var _geometry = null;
var _cache = {}
var _apn = null;
var _tolerance = 0.1; //used for cleaning up polygons
var _asyncmintime = 500;//time to wait before invoking an async. call
var _setback_cache = {};
var _currentFocus;//which option of autocompletion input is focused on
var _keyhandlers = {};
var _infoset = false;//tracks if info for parcel has been collected.
var _maxRowWidth = 250;//used in setbacks.js usally 150 ft should work for smaller cities.

var _lotlines = {};
var frontlotline, rearlotline, sidelotline; //may remove this

var _legend;
_leaflets = {};
_leaflayers = {};
_leafcontrols = {};

var turfAM = {
  buffer: function(feature,length,unit,max)
  {
    max = typeof max == "undefined"? false: max;
    if (length < 0 || (unit && unit.units && unit.units == 'inches')) return turf.buffer(feature,length,unit);
    var b = turf.buffer(feature,length,unit),
        pts = turf.explode(feature).features,
        line = turf.polygonToLineString(b),
        actualdistance = max? maximum(pts.map(i=>turf.pointToLineDistance(i,line,unit))): minimum(pts.map(i=>turf.pointToLineDistance(i,line,unit))),
        correction = Math.abs(length / actualdistance);
    return turf.buffer(feature,length * correction,unit)
  }
};

/*Mapbox Layers*/
var _topourl = 'https://api.mapbox.com/styles/v1/abhijeetm/cjj8c60y40h1p2rpb1ip616ik/tiles/256/{z}/{x}/{y}?access_token=pk.eyJ1IjoiYWJoaWplZXRtIiwiYSI6ImNqajhieG13bDBqc20zd3AyOGQyenptd2UifQ.ixUsj_Nnu_mJlHxAs_wmjg';
var _topolayer = L.tileLayer(_topourl,{maxZoom: 22, maxNativeZoom: 20});

var _saturl = 'https://api.mapbox.com/styles/v1/abhijeetm/cjj8cx9lp0hx42qlmm8cszm7r/tiles/256/{z}/{x}/{y}?access_token=pk.eyJ1IjoiYWJoaWplZXRtIiwiYSI6ImNqajhieG13bDBqc20zd3AyOGQyenptd2UifQ.ixUsj_Nnu_mJlHxAs_wmjg';
var _satellitelayer = L.tileLayer(_saturl,{maxZoom: 22, maxNativeZoom: 20});

/*Built-ins*/

/*Generic Built-ins*/
//1000.2 => 1,000.2
builtins.push('commaseparate');
function commaseparate(x)
{
  return isNaN(x)? x: numberize(x).toLocaleString('en-US',{useGrouping:true});
}
//"hello world" => "Hellow World"
builtins.push('capitalizeone');
function capitalizeone(x)
{
  var y = stripquotes(x);
  var z = y.split(" ");
  for (var i = 0; i < z.length; i++)
  {
    z[i] = z[i][0].toUpperCase() + z[i].slice(1).toLowerCase();
  }
  return quotify(z.join(" "));
}
//["cat 1","cat 2"] => "cat 1 and cat 2"; ["cat 1","cat 2","cat3"] => "cat 1, cat 2 and cat 3"
builtins.push('smarjoinall');
function smartjoinall(x)
{
  try
  {
    return quotify(smartjoin(delistify(x).sort().map(i=>stripquotes(i))));
  }
  catch(e)
  {
    return false;
  }
}
function smartjoin(x)
{
  return x.length < 2? x.join(""): x.slice(0,x.length-1).join(", ") + " and " + x[x.length - 1];
}
//["cat 1","cat 2"] => "cat 1 or cat 2"; ["cat 1","cat 2","cat3"] => "cat 1, cat 2 or cat 3"
builtins.push('listappend');
function listappend(x)
{
  var exp='', args = delistify(x);
  if (!args) return '""';
  if (args.length < 2) return stringappend.apply(null,args);
  for (var i=0; i<args.length - 1; i++) exp += stripquotes(args[i]) + ', ';
  return '"' + exp.slice(0,exp.length - 2) + ' and ' + stripquotes(args[args.length - 1]) + '"';
}
//["cat 1","cat 2"] => "cat 1 or cat 2"; ["cat 1","cat 2","cat3"] => "cat 1, cat 2 or cat 3"
builtins.push('listappendor');
function listappendor(x)
{
  var exp='', args = delistify(x);
  if (!args) return '""';
  if (args.length < 2) return stringappend.apply(null,args);
  for (var i=0; i<args.length - 1; i++) exp += stripquotes(args[i]) + ', ';
  return '"' + exp.slice(0,exp.length - 2) + ' or ' + stripquotes(args[args.length - 1]) + '"';
}
builtins.push('totalfootprint'); //using the self-reported value for now
function totalfootprint()
{
  var structures = getallstructures(),
      footprint = structures.length? turf.area(turf.union(...structures)) * turf.areaFactors.feet: 0;
  return roundify(footprint,1) + "";
}
builtins.push('totalnonadufootprint');
function totalnonadufootprint()
{
  var structures = getnonadustructures(),
      footprint = structures.length? turf.area(turf.union(...structures)) * turf.areaFactors.feet: 0;
  return roundify(footprint,1) + "";
}

/*Data Transfer functions*/
/* Fetching functions */
function getvalues(url)
{
  var request = new XMLHttpRequest();
  request.open("GET",url,false);
  request.send();
  return request.responseText;
}
function curlpostvalues(url,params)
{
  params.url = url;
  var u = '../lib/php/post.php';
  return postvalues(u,params);
}
function postvalues(url,params,n)
{
  var data = [];
  n = typeof n == "undefined"? 2: n; 
  for (var v in params)
  {
    data.push(v + '=' + encodeURIComponent(params[v]));
  }
  data = data.join('&');
  var request = new XMLHttpRequest();
  request.open("POST",url,false);
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  try 
  {
    request.send(data); 
  } 
  catch (err)
  {
    return n == 0? false: postvalues(url,params,n-1);
  }
  return request.responseText;
}

/*General utilities*/
//name says it all
function checkIE()
{
  var ua = window.navigator.userAgent;
  if (/MSIE|Trident/.test(ua))
  {
    fullreact(seq('click','openiewarning'));
  }
}
//warn berfore exiting page
window.onbeforeunload = function (e) {
  var message = "Are you sure you'd like to exit Symbium Build?";
  var firefox = /Firefox[\/\s](\d+)/.test(navigator.userAgent);
  if (firefox) {
    //Firefox does not accept window.showModalDialog(), window.alert(), window.confirm(), and window.prompt() furthermore
    var dialog = document.createElement("div");
    document.body.appendChild(dialog);
    dialog.id = "dialog";
    dialog.style.visibility = "hidden";
    dialog.innerHTML = message; 
    var left = document.body.clientWidth / 2 - dialog.clientWidth / 2;
    dialog.style.left = left + "px";
    dialog.style.visibility = "visible";  
    var shadow = document.createElement("div");
    document.body.appendChild(shadow);
    shadow.id = "shadow";   
    setTimeout(
      function () 
      {
        document.body.removeChild(document.getElementById("dialog"));
        document.body.removeChild(document.getElementById("shadow"));
      }, 
    0);
  }
  return message;
}
//scroll DOM element {id} to {where: 'center'|''|'top'} of its parent (or window) in {duration} ms
function smoothscroll(id, duration, where, parentid) 
{
  var element = document.getElementById(id);
  var parent = typeof parentid == "undefined"? null: window.innerWidth <= 992? null: document.getElementById(parentid);
  var elementTop = element.getBoundingClientRect().top - (parent? parent.getBoundingClientRect().top + 40: 40);
  var amt = elementTop/100;
  var curTime = 0;
  if (duration == 0)
  {
    _movelement(elementTop,where,parent||window);
    return;
  }
  while (curTime <= duration) 
  {
    window.setTimeout(_movelement, curTime, amt, where, parent || window);
    curTime += duration/100;
  }
}
//scroll element {parent} by {amt} pixels.
function _movelement(amt, where, parent) 
{
  if (typeof document.body.scrollBy == "function")
    parent.scrollBy(0, where == "center" || where == ""? amt/2: amt);
  else
    parent.scrollTop += where == "center" || where == ""? amt/2: amt;
}
//asynchronically execute {fn}; min. timeout 500 ms. 
function asyncfn(fn,callback)
{
  document.querySelector(".loadingscreen").style.display="";
  setTimeout(
    function()
    {
      fn();
      if (typeof callback !== "undefined" && typeof callback === 'function')
      {
        callback.call();
      }
      document.querySelector(".loadingscreen").style.display="none";
    }, _asyncmintime); 
}
function asyncmodbutton(e,callback)
{
  asyncfn(
    function()
    {
      modbutton(e);
    },
    callback
  );
}
//select location from autocompletion input field -- depends on autocomplete.js
function locationsearch()
{
  var x = document.querySelector("[type='autocomplete-list']");
  if (x) 
  {
    x = x.getElementsByTagName("div");
    try
    {
      x[_currentFocus].click();
    }
    catch(e)
    {

    }
  }
}
//Key up handler of page -- use keyhandlers to add handlers for other key events
function modkey(e)
{
  if (e.keyCode == 27 && compfindx("disclaimer","disclaimer",lambda,library))
  {
    modbutton(document.querySelector("#closedisclaimer"));
  }
  else if (e.keyCode == 27 && compfindx("iewarning","iewarning",lambda,library))
  {
    modbutton(document.querySelector("#closeiewarning"));
  }
  else if (e.keyCode == 27)
  {
    var x = compfindx("X",["showhelp","X"],lambda,library);
    if (x)
      modbutton(document.getElementById(grind(["closehelp",x])));
  }
  for (var fn in _keyhandlers)
  {
    _keyhandlers[fn](e);
  }
}

/*App Specific Built-ins*/
builtins.push('getinfo');
//gets info about location x - can be an APN (property number) or ADDRESS
function getinfo(x)
{
  if (_infoset)
    return '1';

  _geometry = null, _apn = null, _infoset = false;

  if (stripquotes(x.toUpperCase()) in _cache)
  {
    x = stripquotes(x.toUpperCase())
    var report = _cache[x].report;
    _geometry = _cache[x].geom;
    _apn = report.apn;
    if (report)
      createparcel();
    setinfo(report);
    return report? '1': '0';
  }

  try
  {
    x = x.toUpperCase();
    var y = symbolize(stripquotes(x));
    if (!isNaN(symbolize(y)) || /^[0-9]+[a-z]?(\s*(-?)[0-9]+[a-z]?)*$/.test(stripquotes(x).toLowerCase()) || /^[0-9a-z\-]+$/.test(stripquotes(x).toLowerCase()))
      report = getinfobyapn(x);
    else report = getinfobyaddr();
    // var baseaddress = report.address.split(', CA')[0];
    // if (baseaddress.length)
    //   _cache[baseaddress] = {apn: _apn, geom: _geometry, report: report};
    // _cache[report.apn] = {apn: _apn, geom: _geometry, report: report};
    if (!report)
    {
      return '0';
    }
    else
    {
      createparcel();
      return '1';
    }
  }
  catch (err)
  {
    _cache[x] = null;
    return '0';
  }
}
//info by apn
function getinfobyapn(APN) 
{
  APN = stripquotes(APN).toUpperCase().replace(/[^A-Z0-9]/g,'');
  try
  {
    var url = _path + "parcel.php";
    var params = {where: "APN='" + APN + "'"};
    var response = postvalues(url,params);
    var result = JSON.parse(response);
    if (result.length)
    {
      return inforeport(result);
    }
  }
  catch (e) { }
  return false;
}
//info by address
function getinfobyaddr() 
{
  try
  {
    var addr = compfindx("X",["locationtext","X"],lambda,library);
    addr = stripquotes(addr);
    var url = _path + "parcel.php";
    var params = {where: "ADDRESS='" + addr + "'"};
    var response = postvalues(url,params);
    var result = JSON.parse(response);
    if (result.length)
    {
      return inforeport(result);
    }
  }
  catch (e) { }
  return false;
}
//Click on parcel to select it
function getparcellatlng()
{
  try
  {
    var url = _path + 'parcel.php';
    var pt = "'POINT(" + _leafcoord.x + " " + _leafcoord.y + ")'";
    var params = {
      select: "APN",
      where: "ST_WITHIN(ST_GeomFromText(" + pt + ",4326),geom)"
    };
    var result = JSON.parse(postvalues(url, params));
    if (!result.length)
    {
      var content = '<p style="color: #007bff;"><i class="fas fa-exclamation-circle"></i> No Parcel Found.</p>';
      L.popup().setLatLng(L.latLng(_leafcoord.y, _leafcoord.x)).setContent(content).openOn(_leaflets.maplayer);
      return false;
    }
    result = result[0];
    locatebyapn(result);;
    smoothscroll('content(zoning)',300,'top','sidebar');
  }
  catch (e)
  {
    var content = '<p style="color: #007bff;"><i class="fas fa-exclamation-circle"></i> No Parcel Found.</p>';
    L.popup().setLatLng(L.latLng(_leafcoord.y, _leafcoord.x)).setContent(content).openOn(_leaflets.maplayer);
    return false;
  }
}


/*General math functions*/
//Rounds x upto n digits
function roundify(x,n)
{
  if (typeof n == 'undefined')
    return x;
  var p = Math.pow(10,n);
  return Math.round(x * p)/p;
}
//initializing location if specified as an argument
function initloc()
{
  var args = location.href.split("?");
  if (args.length <=1) return false;
  var parts = args[1].split("&");
  for (var i=0; i<parts.length; i++)
  {
    if (parts[i].indexOf('apn=')===0)
    {
      apn = parts[i].slice(4);
      var url = _path + 'apn.php', params = {apn: apn};
      try
      {
        if (JSON.parse(postvalues(url,params)).length)
        {
          locatebyapn(apn);
        }
      } catch (e) {}
    } 
  }
}
//locatebyapn
function locatebyapn(apn)
{
  document.querySelector("#locationtext").value = apn;
  modstring(document.querySelector("#locationtext"));
  asyncmodbutton(document.querySelector('#search'));
}
//focus on search bar
function focusonsearch()
{
  document.querySelector('#locationtext').focus();
}

/*Geometry functions*/
//standardize feature -- multipolygons -> polygons; multilines to lines when possible.
function standardizefeature(x)
{
  return ArcgisToGeojsonUtils.arcgisToGeoJSON(ArcgisToGeojsonUtils.geojsonToArcGIS(x));
}
//Intersection of two polygons x and y - accounts for quirks in turf.js
function intersect(x,y)
{
  var result;
  try
  {
    result = turf.intersect(x,y);
  }
  catch (e)
  {
    try
    { 
     result = turf.intersect(turf.simplify(x,{highQuality: true}),y);
    }
    catch (e)
    {
      try
      {
        result = turf.intersect(x,turf.simplify(y,{highQuality: true}));
      }
      catch (e)
      {
        try
        {
          result = turf.intersect(turf.simplify(x,{highQuality: true}),turf.simplify(y,{highQuality: true}));
        }
        catch (e)
        {
          try
          {
            result = turf.intersect(turf.simplify(x),turf.simplify(y));
          }
          catch(e)
          {
            return false;
          }
        }
      }
    }
  }
  return result;
}
//Checks if x and y are disjoint; accounts for quirks in turf.js
function isdisjoint(x,y)
{
  try
  {
    return turf.intersect(x,y)? false: true;
  }
  catch (e1)
  {
    try
    {
      return turf.booleanDisjoint(x,y);
    }
    catch (e2) 
    {
      return false;
    }
  }
}
//Cleans up polygon - poly. 
//Tunable parameters: n (local) is # of decimal places in slope computation, and _tolerance (global)
function cleanupgon(poly,n)
{
  n = typeof n == 'undefined'? 2: n;
  var coord = poly.geometry.coordinates[0];
  var newcoord = [];
  var temp = coord.slice(0,-1);

  for (var i = 0; i < temp.length; i++)
  {
    var pt1 = temp[i];
    var pt0 = i == 0? temp[temp.length - 1]: temp[i - 1];
    var pt2 = i == temp.length - 1? temp[0]: temp[i + 1];

    var removept1 = Math.abs(slope(pt0,pt1,n) - slope(pt1,pt2,n)) <= _tolerance && Math.abs(slope(pt0,pt1,n) - slope(pt0,pt2,n)) <= _tolerance;

    if (!removept1)
    {
      newcoord.push(pt1);
    }
  }

  newcoord.push(newcoord[0]);

  return newcoord.length < coord.length? cleanupgon(turf.polygon([newcoord])): poly;
}
//calculate slope
function slope(x,y,n)
{
  var z = (x[1] - y[1]) / (x[0] - y[0]);
  return typeof n == 'undefined'? z: roundify(z,n);
}
//get areas
function getAreaEstimates()
{
  var structures = getnonadustructures(),
      primary = getprimary(structures);
  var totalarea = numberize(totalfootprint()), primaryarea = primary? turf.area(primary) * turf.areaFactors.feet: 0;
  //var totalarea = structures.map(i => turf.area(i) * turf.areaFactors.feet).reduce((i,x)=>x+i,0),
  //    primaryarea = primary? turf.area(primary) * turf.areaFactors.feet: 0;
  return [totalarea,primaryarea];
}
function getnonadustructures()
{
  var l = _leaflayers.draw._layers, output = [];
  for (var i in l)
  {
    if (l[i] instanceof L.Polygon && l[i].options.className && l[i].options.className.indexOf('building') != -1)
    { 
      var b = standardizefeature(L.polygon(l[i].getLatLngs()).toGeoJSON(13));
      output.push(b); 
    }
  }
  return output;
}
function getallstructures()
{
  var l = _leaflayers.draw._layers, output = [], abovegarage = compfindx("abovegarage","abovegarage",lambda,library);
  for (var i in l)
  {
    if (l[i] instanceof L.Polygon && !(abovegarage && l[i].options.className && l[i].options.className == 'adu'))
    { 
      var b = standardizefeature(L.polygon(l[i].getLatLngs()).toGeoJSON(13));
      output.push(b); 
    }
  }
  return output;
}

//get primary residence as polygon -- assumption that largest structure is primary residence
function getprimary(structures)
{
  structures = typeof structures == "undefined"? getnonadustructures(): structures;
  var maxarea = -Infinity, primary = null;
  for (var i = 0; i < structures.length; i++)
  {
    var area = turf.area(structures[i]);
    if (area > maxarea)
    {
      primary = structures[i];
      maxarea = area;
    }
  }
  return primary;
}
//get primary residence as polygon
function getadu()
{
  var l = _leaflayers.draw._layers;
  for (var i in l)
  {
    if (l[i] instanceof L.Polygon && !(l[i].options.className && l[i].options.className.indexOf('building') != -1))
    { 
      var b = standardizefeature(L.polygon(l[i].getLatLngs()).toGeoJSON(13));
      return b;
    }
  }
  return null;
}
function polygontolinedistance(polygon,line)
{
  var l2 = turf.polygonToLineString(polygon),
    m1 = turf.explode(polygon).features.map(i => turf.pointToLineDistance(i,line,{units:'feet'})).reduce((t,e)=>Math.min(t,e),Infinity),
    m2 = turf.explode(line).features.map(i => turf.pointToLineDistance(i,l2,{units:'feet'})).reduce((t,e)=>Math.min(t,e),Infinity)
  return Math.min(m1,m2);
}
function oldpolygontolinedistance(polygon,line)
{
  var a = turf.coordAll(polygon);
  var distance = Infinity;
  for (var i = 0; i < a.length; i++)
  {
    var d = turf.pointToLineDistance(turf.point(a[i]),line,{units:'feet'});
    if (d < distance)
    {
      distance = d;
    }
  }
  return distance;
}