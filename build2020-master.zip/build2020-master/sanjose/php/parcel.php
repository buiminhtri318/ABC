<?php
  if (isset($_REQUEST['where'])) 
  {
    $where = $_REQUEST['where'];
  }
  else
  {
    $where = "true";
  }
  if (isset($_REQUEST['select']) and $_REQUEST['select'] != '*')
  {
    $select = $_REQUEST['select'];
  }
  else
  {
    $select = "APN, ADDRESS, ZIP, ST_ASGEOJSON(GEOM)";
  }
  $config = parse_ini_file("/db/konfig.ini");
  $connection=mysqli_connect($config['host'],$config['user'],$config['pwd'],'sanjose');
  if (mysqli_connect_errno())
  {
    echo "0";
  }
  else
  {
    $query = "SELECT $select FROM parcel WHERE $where;";
    if ($result=mysqli_query($connection,$query))
    {
      $results = Array();
      if ($row = mysqli_fetch_row($result)) 
      {
        $results[] = $row;
      }
      mysqli_free_result($result);
    }
    mysqli_close($connection);

    header('Content-Type: application/json');
    echo json_encode($results);
  }
?>