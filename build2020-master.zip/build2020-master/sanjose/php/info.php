<?php
  $apn = $_REQUEST['apn'];
  $g = $_REQUEST['geom'];
  $z = $_REQUEST['zonebuffer'];
  $h = $_REQUEST['halfmilebuffer'];
  $config = parse_ini_file("/db/konfig.ini");
  $connection=mysqli_connect($config['host'],$config['user'],$config['pwd'],'sanjose');
  if (mysqli_connect_errno())
  {
    echo "0";
  }
  else
  {
    $query = "SET @g = ST_GeomFromGeoJSON('$g')"; 
    mysqli_query($connection,$query);

    $query = "SET @z = ST_GeomFromGeoJSON('$z')"; 
    mysqli_query($connection,$query);

    $query = "SET @h = ST_GeomFromGeoJSON('$h')"; 
    mysqli_query($connection,$query);

    /*Get Zones*/
    $query = "SELECT ZONE, ST_ASGEOJSON(ST_INTERSECTION(GEOM,@z)) FROM zone WHERE ST_INTERSECTS(GEOM,@z);";
    $zone = Array();
    if ($result=mysqli_query($connection,$query))
    {
      while ($row = mysqli_fetch_row($result)) 
      {
        $zone[] = $row;
      }
      mysqli_free_result($result);
    }
    /*Get Transit Stops*/
    /*Use appropriate data source - e.g. santaclaracounty.transitstops*/
    $transitstops = Array();
    $query = "SELECT NAME, TYPE, ST_ASGEOJSON(GEOM) FROM santaclaracounty.transitstops WHERE ST_WITHIN(GEOM,@h);";
    
    if ($result=mysqli_query($connection,$query))
    {
      while ($row = mysqli_fetch_row($result)) 
      {
        $transitstops[] = $row;
      }
      mysqli_free_result($result);
    }
    /*Get Transit Footprints*/
    /*First try OSM*/
    $footprint = Array();
    $query = "SELECT ST_ASGEOJSON(GEOM) FROM osm.california WHERE ST_INTERSECTS(GEOM,@g) AND ST_AREA(ST_INTERSECTION(GEOM,@g))/ST_AREA(GEOM) > 0.55;";
    if ($result=mysqli_query($connection,$query))
    {
      while ($row = mysqli_fetch_row($result)) 
      {
        $footprint[] = $row[0];
      }
      mysqli_free_result($result);
    }
    /*If no footprints, then try BING footprints*/
    if (count($footprint) == 0)
    {
      $query = "SELECT ST_ASGEOJSON(GEOM) FROM footprints.sanjose WHERE ST_INTERSECTS(GEOM,@g) AND ST_AREA(ST_INTERSECTION(GEOM,@g))/ST_AREA(GEOM) > 0.55;";
      if ($result=mysqli_query($connection,$query))
      {
        while ($row = mysqli_fetch_row($result)) 
        {
          $footprint[] = $row[0];
        }
        mysqli_free_result($result);
      }
    }
    /*Historic Info*/
    $query = "SELECT CR,CLD,CLS FROM historic WHERE APN = '$apn'";  
    $n = 0;
    if ($result=mysqli_query($connection,$query))
    {
      if ($row = mysqli_fetch_row($result))
      {
        $result = $row;
        $n = 1;
      }
      else
      {
        $result = [0,0,0];
      }
      mysqli_free_result($result);
    }
    $historic = array("ishistoric" => $n, "cr" => intval($result[0]), "cld" => intval($result[1]), "cls" => intval($result[2]));
    /*Flood Zone*/
    $query = "SELECT 1 FROM floodzone WHERE ST_INTERSECTS(GEOM,@z)";  
    $floodzone = 0;
    if ($result=mysqli_query($connection,$query))
    {
      if ($row = mysqli_fetch_row($result))
      {
        $floodzone = 1;
      }
      mysqli_free_result($result);
    }
    /*Geohazard Zone*/
    $query = "SELECT DISTINCT ZONE FROM geohazard WHERE ST_INTERSECTS(GEOM,@z)";  
    $geohazard = [];
    if ($result=mysqli_query($connection,$query))
    {
      while ($row = mysqli_fetch_row($result))
      {
        $geohazard[] = $row[0];
      }
      mysqli_free_result($result);
    }

    /*General Plan*/
    $query = "SELECT DISTINCT NAME, ST_ASGEOJSON(ST_INTERSECTION(GEOM,@z)) FROM generalplan WHERE ST_INTERSECTS(GEOM,@z)";  
    $generalplan = [];
    if ($result=mysqli_query($connection,$query))
    {
      while ($row = mysqli_fetch_row($result))
      {
        $generalplan[] = $row;
      }
      mysqli_free_result($result);
    }
    
    $output = array("zone" => $zone, "transitstops" => $transitstops, "footprint" => $footprint, "historic" => $historic, "floodzone" => $floodzone, "geohazard" => $geohazard, "generalplan" => $generalplan);

    mysqli_close($connection);

    header('Content-Type: application/json');
    echo json_encode($output);
  }
?>