<?php
  $where = $_REQUEST['where'];
  if (isset($_REQUEST['select']))
  {
    $select = $_REQUEST['select'] . ", "; 
  }
  else
  {
    $select = "";
  }
  /*Read streets from county database*/
  $config = parse_ini_file("/db/konfig.ini");
  $connection=mysqli_connect($config['host'],$config['user'],$config['pwd'],'santaclaracounty');
  if (mysqli_connect_errno())
  {
    echo "0";
  }
  else
  {
    $query = "SELECT $select ST_ASGEOJSON(GEOM) FROM streets WHERE $where;";
    if ($result=mysqli_query($connection,$query))
    {
      $results = Array();
      while ($row = mysqli_fetch_row($result)) 
      {
        if ($select != "")
        {
          $results[] = $row;
        }
        else
        {
          $results[] = $row[0];
        }
      }
      mysqli_free_result($result);
    }
    mysqli_close($connection);

    header('Content-Type: application/json');
    echo json_encode($results);
  }
?>