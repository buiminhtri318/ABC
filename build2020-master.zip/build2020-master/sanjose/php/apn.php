<?php
  $w = $_REQUEST['apn'];
  $w = preg_replace("/[^A-Za-z0-9]/","",$w);
  $config = parse_ini_file("/db/konfig.ini");
  $connection=mysqli_connect($config['host'],$config['user'],$config['pwd'],'sanjose');
  $results = Array();
  if (mysqli_connect_errno())
  {

  }
  else
  {
    $query = "SELECT DISTINCT APN from parcel where APN like '$w%' LIMIT 5";  
    if ($result=mysqli_query($connection,$query))
    {
      $results = Array();
      while ($row = mysqli_fetch_row($result)) 
      {
        $results[] = $row[0];
      }
      mysqli_free_result($result);
    }
    mysqli_close($connection);

    header('Content-Type: application/json');
    echo json_encode($results);
  }
?>