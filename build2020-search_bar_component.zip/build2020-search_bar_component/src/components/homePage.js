Vue.component('home-page', {
  template: `
    <div :style="container">
      <div :style="absoluteTop">
        <div :style="headLineContainer">
          <div :style="headLine">Discover what’s possible on your property.</div>
        </div>
        <search-bar :style="searchBar"></search-bar>
      </div>
    </div>
  `,
  // style: {
  //
  //
  //   :-ms-input-placeholder { /* Internet Explorer 10-11 */
  //     color: white;
  //   }
  //
  //   ::-ms-input-placeholder { /* Microsoft Edge */
  //     color: white;
  //   }
  // },
  computed: {
    container () {
      return {
        background: '#FAFBFF',
        'box-shadow': '0px 0px 10px rgba(95, 116, 254, 0.3)',
        height: '100%',
      }
    },
    absoluteTop () {
      return {
        top: 'calc(50% - 168px)',
        position: 'absolute',
        'text-align': 'center',
      }
    },
    headLine () {
      return {
        'font-style': 'normal',
        'font-weight': 'bold',
        'font-size': '72px',
        'line-height': '72px',
        'letter-spacing': '-1px',
        left: 'calc(50% - 400px)',
        color: '#5F74FE',
      }
    },
    headLineContainer () {
      return {
        padding: '0 calc(50% - 400px)',
      }
    },
    searchBar () {
      return {
        'margin-top': '6px'
      }
    }
  }
});
