Vue.component('search-bar', {
  template: `
    <div>
      <input v-model="searchTerm" v-on:keyup="searchBarKeyUp" />
      <div>
        <a href="property_overview.html">Search</a>
        <div v-show="!noSearchingInpgrogress">{{this.noSearchingInpgrogress}}</div>
        <div v-for="word in suggestList" v-on:click="setSearchTerm">
          {{word}}
        </div>
      </div>
    </div>
  `,
  data: function () {
    return {
      searchTerm: '',
      noSearchingInpgrogress: true,
      suggestList: [],
    }
  },
  methods: {
    searchBarKeyUp: _.debounce(function () {
      this.searchAddress();
    }, 500),
    searchAddress: function () {
      if (this.noSearchingInpgrogress && this.searchTerm.length > 0) {
        this.noSearchingInpgrogress = false;
        axios({
          method: 'GET',
          url: "https://my-json-server.typicode.com/buiminhtri318/stub_address/db",
          params: { term: this.searchTerm },
        }).then(this.parseResponse);
      }
    },
    parseResponse: function (response) {
      this.noSearchingInpgrogress = true;
      var data = response.data;
      if (_.isObject(data) && _.isArray(data.addr)) {
        this.suggestList = response.data.addr;
      }
    },
    setSearchTerm: function (event) {
      this.searchTerm = event.target.innerText;
      this.suggestList = [];
    }
  }
});
