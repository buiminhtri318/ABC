Vue.component('search-bar', {
  data: function () {
    return {
      searchTerm: '',
      noSearchingInpgrogress: true,
      suggestList: [],
      hover: false,
      typing: false,
    }
  },
  template: `
    <div @mouseover="hover = true" @mouseleave="hover = false">
      <div :style="seachHolder">
        <img :style="searchIcon" src="resources/icons/search.png"  >
        <input
          :style="searchInput"
          v-model="searchTerm"
          @keyup="searchBarKeyUp"
          @focus="typing = true"
          @blur="typing = false"
          placeholder="Search by Address"
        />
      </div>
      <div>
        <a href="property_overview.html">Search</a>
        <div v-show="!noSearchingInpgrogress">{{this.noSearchingInpgrogress}}</div>
        <div v-for="word in suggestList" v-on:click="setSearchTerm">
          {{word}}
        </div>
      </div>
    </div>
  `,
  computed: {
    seachHolder () {
      var backgroundColor = this.isActive() ? '#EFF1FF' : '#5F74FE';
      return {
        height: '80px',
        background: backgroundColor,
        display: 'flex',
        width: '800px',
        margin: 'auto',
        'align-items': 'center',
      }
    },
    searchIcon () {
      return {
        height: '32px',
        width: '32px',
        background: 'transparent',
        'margin-left': '24px',
      }
    },
    searchInput () {
      var fontColor = this.isActive() ? '#5F74FE' : 'white';
      return {
        flex: '1',
        border: '0',
        background: 'transparent',
        'font-size': '24px',
        'text-align': 'center',
        color: fontColor,
        '--placeholder-color': fontColor,
      }
    }
  },
  methods: {
    // Methods to control search logic
    searchBarKeyUp: _.debounce(function () {
      this.searchAddress();
    }, 500),
    searchAddress: function () {
      if (this.noSearchingInpgrogress && this.searchTermIsNotEmpty) {
        this.noSearchingInpgrogress = false;
        axios({
          method: 'GET',
          url: "https://my-json-server.typicode.com/buiminhtri318/stub_address/db",
          params: { term: this.searchTerm },
        }).then(this.parseResponse);
      }
    },
    parseResponse: function (response) {
      this.noSearchingInpgrogress = true;
      var data = response.data;
      if (_.isObject(data) && _.isArray(data.addr)) {
        this.suggestList = response.data.addr;
      }
    },
    setSearchTerm: function (event) {
      this.searchTerm = event.target.innerText;
      this.suggestList = [];
    },
    searchTermIsNotEmpty: function () {
      return this.searchTerm.length > 0
    },
    isActive: function () {
      return this.hover || this.typing || this.searchTermIsNotEmpty()
    }
  }
});
