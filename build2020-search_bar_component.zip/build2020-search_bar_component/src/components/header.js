Vue.component('header-bar', {
  template: `
    <div :style="container">
      <div :style="rightHeader">Symbium Build</div>
      <circle-shape
        title="P"
        background-color="#5F74FE"
      ></cirlce-shape>
    </div>
  `,
  computed: {
    container () {
      return {
        display: 'flex',
        background: 'white',
        padding: '25px',
      }
    },
    rightHeader () {
      return {
        'flex-grow': 1,
        color: '#5F74FE',
      }
    }
  }
});
