document.addEventListener("DOMContentLoaded", function(event) {
  new Vue({
    el: '#page'
  });
});
